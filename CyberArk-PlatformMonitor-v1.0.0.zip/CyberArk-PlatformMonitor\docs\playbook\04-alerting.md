# Alerting

## Enabling SMTP Alerting

SMTP alerting is disabled by default. The minimum configuration to enable it:

```json
{
    "alerting": {
        "enabled": true,
        "smtp": {
            "server": "smtp.corp.local",
            "port": 25,
            "from": "cyberark-monitor@corp.local"
        },
        "defaults": {
            "notifyTo": ["pam-team@corp.local"]
        }
    }
}
```

Three settings are required:

1. `alerting.enabled` must be `true`
2. `alerting.smtp.server` must be set to a reachable SMTP server
3. `alerting.defaults.notifyTo` must contain at least one email address (unless every requirement has its own `notification.notifyTo`)

> **Important**: The tool uses `System.Net.Mail.SmtpClient` (PS 5.1 compatible) with a 10-second timeout. No SMTP authentication is supported -- the tool relies on the SMTP relay accepting mail from the server's IP address. This is standard for internal monitoring tools.

## Alert Lifecycle

Each monitoring requirement is evaluated against its thresholds on every collection cycle (for the active tier). The alert state machine tracks the lifecycle of each alert using a dedup key: `{requirementId}::{metricPath}`.

```
State Transitions:

NOT_FIRING ----[threshold crossed]----> FIRING
    |                                      |
    |                                      |--- send alert email to notifyTo
    |                                      |--- record in state.activeAlerts
    |                                      |
    |                                 STILL FIRING
    |                                      |
    |                                      |--- cooldown elapsed? -> send reminder
    |                                      |--- escalation time elapsed? -> send to escalateTo
    |                                      |
    <----[threshold OK]--------------- RECOVERED
                                           |
                                           |--- send recovery email
                                           |--- move to state.alertHistory
```

### Alert States

| State | Condition | Actions |
|-------|-----------|---------|
| NOT_FIRING | Metric is within thresholds | No action |
| FIRING | Metric exceeds warning or critical threshold | Alert email sent, recorded in activeAlerts |
| STILL_FIRING | Alert continues to fire on subsequent checks | Cooldown check, escalation check |
| RECOVERED | Metric returns to normal after being in FIRING state | Recovery email, moved to alertHistory |

## Cooldown and Deduplication

Two settings prevent alert storms:

### suppressDuplicateMinutes

Controls the minimum time between the initial alert and the first reminder. Default: 15 minutes.

When a threshold is first crossed, an alert email is sent immediately. No additional emails are sent for the same alert until `suppressDuplicateMinutes` have elapsed.

### cooldownMinutes

Controls the interval between reminder notifications for an ongoing alert. Default: 30 minutes.

After the suppress window, if the alert is still firing, a reminder email is sent. Subsequent reminders follow the `cooldownMinutes` interval.

```json
{
    "alerting": {
        "rules": {
            "suppressDuplicateMinutes": 15,
            "cooldownMinutes": 30,
            "maxNotificationsPerAlert": 10
        }
    }
}
```

### maxNotificationsPerAlert

Caps the total number of emails (initial + reminders) for a single alert instance. Default: 10. After this limit, no more emails are sent until the alert recovers and fires again.

## Escalation

Alerts that persist beyond the `escalateAfterMinutes` threshold (default: 60 minutes) are automatically escalated.

### How Escalation Works

1. When an alert's `firstSeen` timestamp is more than `escalateAfterMinutes` ago, the alert is marked as escalated.
2. An escalation email is sent to the `escalateTo` recipients (from the requirement's notification config or the global `alerting.defaults.escalateTo`).
3. The escalation email has a red header and is sent with High priority.
4. Escalation happens once per alert instance -- it is not repeated.

### Configuring Escalation

```json
{
    "alerting": {
        "rules": {
            "escalateAfterMinutes": 60
        },
        "defaults": {
            "escalateTo": ["pam-lead@corp.local", "oncall-manager@corp.local"]
        }
    }
}
```

Per-requirement escalation targets override the defaults:

```json
{
    "id": "REQ-003",
    "name": "Vault Service Running",
    "notification": {
        "notifyTo": ["pam-team@corp.local"],
        "escalateTo": ["vault-admin@corp.local", "ciso@corp.local"]
    }
}
```

## Recovery Notifications

When a metric that was previously in FIRING state returns to normal, a recovery email is automatically sent to the same `notifyTo` recipients.

The recovery email includes:

- What recovered (requirement name and ID)
- Duration of the incident (minutes)
- Peak value during the incident
- Current (recovered) value
- Number of notifications sent during the incident

Recovery emails have a green header and Normal priority.

> **Note**: Recovery is only evaluated for requirements that were checked in the current tier's collection cycle. A Hot-tier alert is not recovered when only a Cool-tier collection runs.

## Daily Digest Email

The daily digest provides an overnight summary of the monitoring system's state.

### Enabling the Digest

```json
{
    "alerting": {
        "digest": {
            "enabled": true,
            "time": "07:00",
            "recipients": ["pam-team@corp.local"],
            "sendOnlyIfIssues": false
        }
    }
}
```

| Setting | Type | Default | Description |
|---------|------|---------|-------------|
| `digest.enabled` | bool | `false` | Enable daily digest |
| `digest.time` | string | `"07:00"` | Time to send (HH:MM, 24-hour format) |
| `digest.recipients` | array | `[]` | Email addresses; falls back to `defaults.notifyTo` if empty |
| `digest.sendOnlyIfIssues` | bool | `false` | When true, only send if there are active alerts |

### Digest Content

The daily digest email includes:

- **Summary cards**: Collections today, active alerts, resolved today, total history
- **Active alerts table**: Requirement ID, severity, current value, firing since
- **7-day trend sparklines**: CPU average, memory used, disk C: used -- with min/max/avg numbers
- **All-time peak records**: Highest recorded values with timestamps
- **Capacity forecast highlights**: Current values, days until limit, trend direction

### Digest Timing

The digest checks if it should fire on every scheduled collection cycle. It triggers when:

1. `digest.enabled` is true
2. The current hour matches the `digest.time` hour
3. The current minute is within 5 minutes of the target minute
4. The digest has not already been sent today (tracked in `state.digestLastSent`)

> **Tip**: The 5-minute window accommodates scheduled tasks that may not fire at the exact minute. If you have a Hot tier running every minute, the digest will trigger within 1-2 minutes of the target time.

## Per-Requirement Notification Routing

Different teams can receive alerts for different requirements. The routing priority is:

1. **Requirement-level** `notification.notifyTo` / `notification.escalateTo`
2. **Global defaults** `alerting.defaults.notifyTo` / `alerting.defaults.escalateTo`

### Example: Team-Based Routing

```json
[
    {
        "id": "REQ-001",
        "name": "CPU Utilization",
        "notification": {
            "notifyTo": ["infra-team@corp.local"],
            "escalateTo": ["infra-lead@corp.local"]
        }
    },
    {
        "id": "REQ-003",
        "name": "Vault Service Running",
        "notification": {
            "notifyTo": ["vault-team@corp.local"],
            "escalateTo": ["vault-lead@corp.local", "ciso@corp.local"]
        }
    },
    {
        "id": "REQ-005",
        "name": "Certificate Expiry",
        "notification": {
            "notifyTo": ["pki-team@corp.local"],
            "escalateTo": ["security-lead@corp.local"]
        }
    }
]
```

Requirements without their own notification addresses inherit from `alerting.defaults`.

## Testing Alerts

Two flags allow you to test the alerting pipeline without waiting for a real threshold breach.

### -TestAlert

Sends a single test email using the configured SMTP settings and exits:

```powershell
.\Invoke-CAPlatformMonitor.ps1 -TestAlert
```

This sends a Warning-severity alert email for the first default requirement (CPU Utilization) to the `alerting.defaults.notifyTo` addresses. Use this to verify:

- SMTP server is reachable
- Port 25 (or configured port) is open
- From address is accepted by the relay
- Email arrives at the configured recipients

Exit code: 0 if the email was sent, 1 if it failed.

### -DigestNow

Forces the daily digest email to be sent immediately:

```powershell
.\Invoke-CAPlatformMonitor.ps1 -DigestNow
```

This is useful for:

- Testing the digest email format
- Sending an ad-hoc summary during an incident
- Verifying digest recipients are correct

> **Note**: Both `-TestAlert` and `-DigestNow` exit after sending. They do not run collectors or update state.

## Alert Email Examples

### Alert Email

Alert emails include:

- **Header**: Red or amber gradient with severity badge, requirement name, server name, timestamp
- **Metric table**: Current value (color-coded), threshold
- **SLA text**: Business requirement statement
- **Runbook button**: Direct link to the relevant runbook (if configured)
- **7-day sparkline**: Visual trend of the metric from daily summaries

Subject line format: `[Critical] REQ-001 - Platform Monitor` or `REMINDER: [Warning] REQ-002 - Platform Monitor`

### Recovery Email

Recovery emails include:

- **Header**: Green gradient with "RECOVERED" label
- **Recovery details table**: Duration (minutes), peak value during incident, current value, notifications sent

Subject line format: `RECOVERED: REQ-001 - Platform Monitor`

### Escalation Email

Escalation emails are identical to alert emails but with:

- **Header**: Dark red gradient with "ESCALATION" label
- **Priority**: High (email client shows as high-priority)

Subject line format: `ESCALATION: [Critical] REQ-001 - Platform Monitor`

### Digest Email

The digest email has a blue gradient header and includes summary cards, active alerts table, sparkline charts, peak records, and capacity forecasts. It provides a complete operational overview in a single email.

Subject line format: `Daily Platform Monitor Digest - SERVERNAME - 2026-07-08`

## Concurrent Scheduled Task Safety

When three tier-based scheduled tasks are registered, multiple instances of the tool may run simultaneously (e.g., a Hot collection overlaps with a Cool collection).

### Mutex Protection

The tool uses a global named mutex (`Global\CyberArkPlatformMonitorState`) via `[System.Threading.Mutex]` for cross-process synchronization on the state file. The mutex acquisition timeout is 10 seconds.

### What Happens on Lock Failure

If a tier instance cannot acquire the mutex within 10 seconds:

- **JSONL writes still succeed** (JSONL uses file-append, not read-modify-write)
- **Collection still succeeds** (collectors are independent of state)
- **State update is skipped** (daily summaries and alert state are not updated for this cycle)
- **A warning is logged**: "Could not acquire state file lock after 10s, skipping state save"

The skipped state update will be picked up on the next cycle. This is a safe degradation -- no data is lost, and the next successful cycle will reconcile the state.

> **Tip**: In practice, mutex contention is extremely rare because Hot tier collections take less than 2 seconds and Cool tier collections take 5-10 seconds. The 10-second timeout provides ample headroom.
