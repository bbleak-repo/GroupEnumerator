# Deployment

## Quick Start

Deployment is a single-file copy. No installer, no modules, no dependencies.

1. Copy `Invoke-CAPlatformMonitor.ps1` to the target server (any directory).
2. Open an elevated PowerShell prompt.
3. Run with `-Help` to verify the script loads:

```powershell
.\Invoke-CAPlatformMonitor.ps1 -Help
```

4. Run your first health check:

```powershell
.\Invoke-CAPlatformMonitor.ps1
```

This creates a default `ca-platform-monitor.json` in the script directory, collects from all 8 collectors, and produces an HTML report.

> **Tip**: On a non-Windows machine (macOS/Linux), use `-UseMockData` to generate a sample report for review:
> `.\Invoke-CAPlatformMonitor.ps1 -Report -UseMockData`

## First Run Behavior

On the very first execution, the tool performs several setup tasks automatically:

1. **Config auto-creation**: If no `ca-platform-monitor.json` exists in the search path, the tool creates one with all default values at `$PSScriptRoot\ca-platform-monitor.json`. A banner is displayed directing you to edit it.

2. **Requirements auto-creation**: If no `monitoring-requirements.json` exists, the tool creates one with 5 default requirements (CPU, memory, Vault service, Vault connectivity, certificate expiry).

3. **Service baseline learning**: The tool records the current state of all discovered CyberArk services. On subsequent runs, it compares against this baseline and alerts on unexpected state changes.

4. **Directory creation**: The `Metrics/` and `Logs/` subdirectories are created automatically when the first JSONL record or log entry is written.

> **Important**: After first run, edit `ca-platform-monitor.json` to set your `VaultAddress` for connectivity tests and adjust thresholds for your environment.

## Deploying as Scheduled Tasks

The recommended deployment uses three tiered Windows scheduled tasks, each collecting at a different frequency:

| Task Name | Interval | Tier | Collectors |
|-----------|----------|------|-----------|
| CyberArk Monitor - Hot | Every 1 minute | Hot | SystemHealth, ServerCapacity |
| CyberArk Monitor - Warm | Every 5 minutes | Warm | ServiceStatus, Connectivity |
| CyberArk Monitor - Cool | Every 15 minutes | Cool | CPMHealth, PSMHealth, CertificateHealth, WebDriverHealth |

### Automatic Registration

The simplest approach -- run from an elevated prompt:

```powershell
.\Invoke-CAPlatformMonitor.ps1 -RegisterTasks
```

This creates all three tasks running as SYSTEM with Highest privileges. To remove them:

```powershell
.\Invoke-CAPlatformMonitor.ps1 -UnregisterTasks
```

### Manual Registration

If you need to customize the task configuration (different account, different schedule), register each task individually:

```powershell
# Hot tier -- every 1 minute (CPU, memory, disk, connections)
$action   = New-ScheduledTaskAction -Execute 'powershell.exe' `
              -Argument '-NoProfile -ExecutionPolicy Bypass -File "C:\CyberArk\Monitor\Invoke-CAPlatformMonitor.ps1" -Scheduled -Tier Hot'
$trigger  = New-ScheduledTaskTrigger -Once -At (Get-Date) `
              -RepetitionInterval (New-TimeSpan -Minutes 1)
$principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$settings  = New-ScheduledTaskSettingsSet -StartWhenAvailable -DontStopOnIdleEnd -AllowStartIfOnBatteries
Register-ScheduledTask -TaskName 'CyberArk Monitor - Hot' `
    -Action $action -Trigger $trigger -Principal $principal -Settings $settings `
    -Description 'CyberArk Platform Monitor - Hot tier (CPU/Memory/Disk every 1m)'
```

```powershell
# Warm tier -- every 5 minutes (services, connectivity)
$action   = New-ScheduledTaskAction -Execute 'powershell.exe' `
              -Argument '-NoProfile -ExecutionPolicy Bypass -File "C:\CyberArk\Monitor\Invoke-CAPlatformMonitor.ps1" -Scheduled -Tier Warm'
$trigger  = New-ScheduledTaskTrigger -Once -At (Get-Date) `
              -RepetitionInterval (New-TimeSpan -Minutes 5)
$principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$settings  = New-ScheduledTaskSettingsSet -StartWhenAvailable -DontStopOnIdleEnd -AllowStartIfOnBatteries
Register-ScheduledTask -TaskName 'CyberArk Monitor - Warm' `
    -Action $action -Trigger $trigger -Principal $principal -Settings $settings `
    -Description 'CyberArk Platform Monitor - Warm tier (Services/Connectivity every 5m)'
```

```powershell
# Cool tier -- every 15 minutes (CPM, PSM, certs, WebDriver)
$action   = New-ScheduledTaskAction -Execute 'powershell.exe' `
              -Argument '-NoProfile -ExecutionPolicy Bypass -File "C:\CyberArk\Monitor\Invoke-CAPlatformMonitor.ps1" -Scheduled -Tier Cool'
$trigger  = New-ScheduledTaskTrigger -Once -At (Get-Date) `
              -RepetitionInterval (New-TimeSpan -Minutes 15)
$principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$settings  = New-ScheduledTaskSettingsSet -StartWhenAvailable -DontStopOnIdleEnd -AllowStartIfOnBatteries
Register-ScheduledTask -TaskName 'CyberArk Monitor - Cool' `
    -Action $action -Trigger $trigger -Principal $principal -Settings $settings `
    -Description 'CyberArk Platform Monitor - Cool tier (CPM/PSM/Certs/WebDriver every 15m)'
```

### Legacy Single-Task Mode

If three tasks is too much overhead, run all collectors on a single schedule:

```powershell
$action  = New-ScheduledTaskAction -Execute 'powershell.exe' `
             -Argument '-NoProfile -ExecutionPolicy Bypass -File "C:\CyberArk\Monitor\Invoke-CAPlatformMonitor.ps1" -Scheduled'
$trigger = New-ScheduledTaskTrigger -Daily -At '06:00AM'
Register-ScheduledTask -TaskName 'CyberArk Platform Monitor' `
    -Action $action -Trigger $trigger `
    -Principal (New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest) `
    -Settings (New-ScheduledTaskSettingsSet -StartWhenAvailable -DontStopOnIdleEnd)
```

> **Important**: `-Scheduled` without `-Tier` runs all 8 collectors. This is backward compatible but does not benefit from tier-based frequency separation.

## Deployment by Server Role

The same script runs on all server roles. Customize the configuration for each role to skip irrelevant collectors.

### Vault Server

The Vault server runs PrivateArk Server and PrivateArk Database. CPM, PSM, and WebDriver checks are irrelevant.

```json
{
    "server": { "role": "Vault" }
}
```

Run with skip flags or set in config:

```powershell
.\Invoke-CAPlatformMonitor.ps1 -Scheduled -Tier Hot -SkipCPM -SkipPSM -SkipWebDrivers
```

### CPM Server (Active)

The active CPM server runs CyberArk Password Manager and CyberArk Central Policy Manager Scanner.

```json
{
    "server": { "role": "CPM" },
    "connectivity": { "vaultAddress": "vault01.corp.local" }
}
```

### CPM Server (Passive / DR)

A passive CPM has the services installed but stopped. Use the `expectedStates` config to tell the baseline that stopped is the correct state:

```json
{
    "server": { "role": "CPM" },
    "serviceBaseline": {
        "expectedStates": {
            "CyberArk Password Manager": "Stopped",
            "CyberArk Central Policy Manager Scanner": "Stopped"
        }
    }
}
```

### PSM Server

The PSM server runs CyberArk Privileged Session Manager. WebDriver checks are relevant here.

```json
{
    "server": { "role": "PSM" },
    "connectivity": { "vaultAddress": "vault01.corp.local" },
    "webDriver": {
        "psmComponentsPath": "C:\\Program Files (x86)\\CyberArk\\PSM\\Components"
    }
}
```

### PVWA Server

PVWA is a web application server. CPM, PSM, and WebDriver checks are irrelevant.

```powershell
.\Invoke-CAPlatformMonitor.ps1 -Scheduled -SkipCPM -SkipPSM -SkipWebDrivers
```

### All-in-One (Lab / PoC)

Run everything with default config:

```powershell
.\Invoke-CAPlatformMonitor.ps1 -RegisterTasks
```

## File Layout on Target Server

After deployment and first run, the directory structure looks like this:

```
C:\CyberArk\Monitor\
    Invoke-CAPlatformMonitor.ps1      # The script
    ca-platform-monitor.json           # Config (auto-created, admin-editable)
    monitoring-requirements.json       # Requirements (auto-created, admin-editable)
    platform-state.json                # State (tool-managed, do not edit)
    Metrics\
        platform-metrics-2026-07-08.jsonl   # Today's raw metrics
        platform-metrics-2026-07-07.jsonl   # Yesterday's raw metrics
        ...
    Logs\
        CA-PlatformMonitor-2026-07-08_060000.log
        ...
    PlatformHealthReport-2026-07-08_060000.html   # Report mode output
```

> **Note**: The script resolves all relative paths against `$PSScriptRoot` (the directory containing the script), not the current working directory. This is important when running as a scheduled task where the working directory may differ.

## Upgrading

To upgrade the tool:

1. Replace `Invoke-CAPlatformMonitor.ps1` with the new version.
2. The config file (`ca-platform-monitor.json`) is backward compatible -- new settings are merged with defaults.
3. The state file (`platform-state.json`) is preserved across upgrades.
4. The requirements file (`monitoring-requirements.json`) is also preserved.

> **Tip**: After upgrading, run a manual `-Report` to verify the new version works correctly before scheduled tasks pick it up.
