# Troubleshooting

## Log File Location

Log files are written to the `Logs` directory under the script directory (or the path specified by `logging.path` in config / `-LogPath` on the command line).

File naming pattern: `CA-PlatformMonitor-YYYY-MM-DD_HHmmss.log`

Each log file includes a header with the tool version, server name, operating mode, and correlation ID. Log entries are structured as `[timestamp] [Level] [Component] Message`.

### Log Levels

| Level | What It Captures |
|-------|-----------------|
| Debug | Everything including collector internals, metric values, path resolution |
| Info | Collection progress, status summaries, file locations (default) |
| Warn | Non-fatal errors, skipped collectors, threshold breaches |
| Error | Fatal errors that prevent collection completion |

To increase verbosity for troubleshooting:

```powershell
.\Invoke-CAPlatformMonitor.ps1 -Report -LogLevel Debug
```

Or set it in the config:

```json
{
    "logging": { "level": "Debug" }
}
```

## Common Issues

| Symptom | Cause | Solution |
|---------|-------|----------|
| All services show as Critical on first run | No baseline exists yet; if services are intentionally stopped, the baseline will flag them | Configure `serviceBaseline.expectedStates` in the config for intentionally stopped services, or run with `-Baseline` after confirming services are in the correct state |
| SMTP alerts not sending | Alerting disabled, SMTP server not set, or port blocked | Verify `alerting.enabled` is `true`, `smtp.server` is set, port 25 is open from this server. Test with `-TestAlert` |
| State file locked | Another scheduled task instance is running or a previous instance crashed without releasing the mutex | Check for stuck `powershell.exe` processes running the monitor script. The mutex uses a 10-second timeout; if it expires, the state update is skipped and retried next cycle |
| JSONL files growing too large | Hot tier at 1-minute intervals generates ~2,000 records/day | Check the `retentionDays` setting. Each daily file is typically 2-4 MB. If storage is a concern, increase the Hot tier interval to 2-3 minutes |
| Mock data in report | Running on non-Windows or with `-UseMockData` flag | Check platform detection. On Windows, remove `-UseMockData`. The tool auto-detects the platform and only uses real collectors on Windows |
| Performance counters slow | CPU sampling takes `cpuSampleCount * cpuSampleIntervalMs` | Reduce `collection.cpuSampleCount` from 5 to 2 or 3 for Hot tier. The default 5 samples at 1000ms = 5 seconds per collection |
| WebDriver checks failing | PSM Components folder not found at the expected path | Set `webDriver.psmComponentsPath` in config. Auto-detection uses the registry key `HKLM:\SOFTWARE\CyberArk\PSM\InstallLocation` |
| CPM logs not found | CPM log path not configured and auto-detection failed | Set `cpmHealth.logPath` in config. Auto-detection reads from `HKLM:\SOFTWARE\CyberArk\CentralPolicy Manager\Administration\AppInstallDirectory`. Default fallback: `C:\Program Files (x86)\CyberArk\Password Manager\Logs` |
| PSM logs not found | PSM log path not configured and auto-detection failed | Set `psmHealth.logPath` in config. Auto-detection reads from `HKLM:\SOFTWARE\CyberArk\PSM\InstallLocation`. Default fallback: `C:\Program Files (x86)\CyberArk\PSM\Logs` |
| Report file not created | Output path is a directory that does not exist | Create the output directory manually, or let the tool create it by using a path within the script directory |
| Certificate checks show zero certs | No CyberArk-related certificates in LocalMachine stores | The tool scans `Cert:\LocalMachine\My` and `Cert:\LocalMachine\Root` for certificates with CyberArk-related subject names. If certs are in a different store, they will not be found |
| Exit code always 0 in scheduled mode | No thresholds are being breached | This is correct behavior. Verify with `-Report` mode to see the full HTML output |

## Debugging with -LogLevel Debug

Debug logging adds verbose output for every step of the pipeline. This is the first tool to reach for when something is not working as expected.

```powershell
.\Invoke-CAPlatformMonitor.ps1 -Report -LogLevel Debug 2>&1 | Out-File debug-output.txt
```

Key debug messages to look for:

- `Loaded X monitoring requirement(s) from:` -- confirms requirements file was found
- `Loaded platform state from:` -- confirms state file was found
- `Service baseline created:` -- shows first-time baseline learning
- `Service state change detected:` -- shows baseline deviation
- `Alert RECOVERED:` / `New alert FIRING:` / `Alert ESCALATED:` -- alert state transitions
- `Email sent:` / `SMTP send failed:` -- SMTP outcomes
- `Platform state saved to:` -- confirms state file was written
- `Rotated old metrics file:` -- confirms JSONL cleanup

## Checking State File Health

The state file is the most important diagnostic artifact. If alerting or trending seems wrong, inspect it directly.

### Read the State File

```powershell
$state = Get-Content "platform-state.json" | ConvertFrom-Json

# When was each tier last collected?
$state.lastCollection | Format-List

# How many daily summaries are stored?
$state.dailySummaries.PSObject.Properties.Count

# Any active alerts?
$state.activeAlerts.PSObject.Properties | ForEach-Object {
    [PSCustomObject]@{
        Key          = $_.Name
        Severity     = $_.Value.severity
        FirstSeen    = $_.Value.firstSeen
        Occurrences  = $_.Value.occurrences
        Escalated    = $_.Value.escalated
    }
} | Format-Table
```

### Verify Daily Summaries

```powershell
# Check today's CPU data
$today = (Get-Date).ToString('yyyy-MM-dd')
$state.dailySummaries.$today.cpuAverage | Format-List

# Expected output:
# min    : 12.3
# max    : 78.4
# avg    : 34.2
# sum    : 3420
# count  : 100
# peakAt : 2026-07-08T14:15:00.000Z
```

If `count` is lower than expected (e.g., 50 instead of ~1440 for Hot tier over 24 hours), check that scheduled tasks are running.

### Check Alert History

```powershell
# Recent resolved alerts
$state.alertHistory | Select-Object -Last 5 | ForEach-Object {
    [PSCustomObject]@{
        Requirement = $_.requirementId
        Severity    = $_.severity
        Duration    = "$($_.durationMinutes) min"
        Resolved    = $_.resolvedAt
    }
} | Format-Table
```

### Reset State File

If the state file is corrupted, simply delete it. The tool will create a fresh empty state on the next run:

```powershell
Remove-Item "platform-state.json"
.\Invoke-CAPlatformMonitor.ps1 -Report
```

> **Caution**: Deleting the state file loses all trend data, active alerts, alert history, and peak records. Only do this if the file is genuinely corrupted.

## PowerShell Snippets

### Read JSONL and Find Peak CPU

```powershell
$files = Get-ChildItem "Metrics\platform-metrics-*.jsonl" | Sort-Object Name -Descending | Select-Object -First 7
$cpuValues = foreach ($f in $files) {
    Get-Content $f.FullName | ForEach-Object {
        $record = $_ | ConvertFrom-Json
        if ($record.recordType -eq 'SystemHealth' -and $null -ne $record.CPU) {
            $record.CPU.Average
        }
    }
}
$peak = $cpuValues | Measure-Object -Maximum
Write-Host "Peak CPU (last 7 days): $($peak.Maximum)%"
```

### Query Trends from State

```powershell
$state = Get-Content "platform-state.json" | ConvertFrom-Json
$state.dailySummaries.PSObject.Properties |
    Sort-Object Name |
    ForEach-Object {
        $day = $_.Name
        $cpu = $_.Value.cpuAverage
        $mem = $_.Value.memoryUsed
        [PSCustomObject]@{
            Date    = $day
            CpuAvg  = if ($cpu) { [math]::Round($cpu.avg, 1) } else { 'N/A' }
            CpuPeak = if ($cpu) { [math]::Round($cpu.max, 1) } else { 'N/A' }
            MemAvg  = if ($mem) { [math]::Round($mem.avg, 1) } else { 'N/A' }
            MemPeak = if ($mem) { [math]::Round($mem.max, 1) } else { 'N/A' }
        }
    } | Format-Table
```

### Check Service Baseline

```powershell
$state = Get-Content "platform-state.json" | ConvertFrom-Json
$state.serviceBaseline.PSObject.Properties | ForEach-Object {
    [PSCustomObject]@{
        Service       = $_.Name
        ExpectedState = $_.Value.expectedState
        BaselinedAt   = $_.Value.baselinedAt
        Notes         = $_.Value.notes
    }
} | Format-Table -AutoSize
```

### Export Alert History to CSV

```powershell
$state = Get-Content "platform-state.json" | ConvertFrom-Json
$state.alertHistory | ForEach-Object {
    $entry = $_
    [PSCustomObject]@{
        Requirement = $entry.requirementId
        Severity    = $entry.severity
        FirstSeen   = $entry.firstSeen
        ResolvedAt  = $entry.resolvedAt
        Duration    = "$($entry.durationMinutes) min"
        Notifications = $entry.notificationsSent
    }
} | Export-Csv "alert-history.csv" -NoTypeInformation
```

## FAQ

### Can I monitor non-CyberArk services?

Yes. Add them to `serviceBaseline.additionalServices` in the config:

```json
{
    "serviceBaseline": {
        "additionalServices": ["W3SVC", "MSSQLSERVER", "CyberArkScheduledTasksService"]
    }
}
```

These services will be included in the service status collector alongside the CyberArk services.

### Does it need CyberArk API access?

No. The tool is entirely local. It reads WMI/CIM, Windows services, event logs, certificate stores, registry keys, log files, and TCP connectivity. No CyberArk REST API calls are made. No authentication tokens, client certificates, or API keys are needed.

### Can I run it on macOS or Linux?

Yes, with the `-UseMockData` flag for testing and report development. All Windows-specific calls (services, event logs, registry, performance counters) are gated behind platform detection. Mock data provides realistic sample values for all 8 collectors.

```powershell
pwsh -File Invoke-CAPlatformMonitor.ps1 -Report -UseMockData
```

### How do I see peak CPU from last month?

Two options:

**From the state file** (instant, recommended):

```powershell
$state = Get-Content "platform-state.json" | ConvertFrom-Json
$state.peaks.cpuAverage
# Output: @{value=94.2; timestamp=2026-07-05T03:15:00.000Z}
```

**From JSONL files** (slower, full audit trail):

```powershell
$files = Get-ChildItem "Metrics\platform-metrics-*.jsonl"
$peakCpu = 0
foreach ($f in $files) {
    Get-Content $f.FullName | ForEach-Object {
        $r = $_ | ConvertFrom-Json
        if ($r.recordType -eq 'SystemHealth' -and $r.CPU.Average -gt $peakCpu) {
            $peakCpu = $r.CPU.Average
        }
    }
}
Write-Host "Peak CPU: $peakCpu%"
```

### What happens during a CyberArk upgrade?

During the upgrade, services will stop and restart. The service baseline system will detect these state changes and may generate alerts. To prevent false positives:

1. **Before the upgrade**: Suppress alerting with `-NoAlerts` on scheduled tasks, or disable them temporarily.
2. **After the upgrade**: Run `-Baseline` to re-learn service states.

```powershell
.\Invoke-CAPlatformMonitor.ps1 -Baseline
```

This immediately sets the baseline to the current state of all services.

### How do I add a custom requirement?

Add a new entry to `monitoring-requirements.json`:

```json
{
    "id": "REQ-006",
    "name": "Disk Space - D Drive",
    "description": "D: drive usage must stay below thresholds",
    "enabled": true,
    "collector": "SystemHealth",
    "metricPath": "Disks.UsedPercent",
    "filter": { "field": "DriveLetter", "value": "D:" },
    "direction": "HigherIsBad",
    "warningThreshold": 75,
    "criticalThreshold": 90,
    "tier": "Hot",
    "sla": "Data drive usage below 75%",
    "runbookUrl": "",
    "notification": {
        "notifyTo": [],
        "escalateTo": []
    }
}
```

The tool re-reads the requirements file on each run, so changes take effect immediately.

### Can I use this with a centralized log collector?

Yes. JSONL files are designed to be ingested by any text-based log collector:

- **Splunk**: Configure a file monitor on `Metrics\platform-metrics-*.jsonl`
- **Elastic**: Use Filebeat with JSON parsing
- **Azure Log Analytics**: Use the Log Analytics agent with custom log collection

Each JSONL record is a single line of valid JSON with a `recordType` field for filtering.

### How do I disable a specific collector permanently?

Use the skip flags in the scheduled task arguments:

```powershell
# Skip WebDriver checks (PSM server with no web connectors)
-Argument '-NoProfile -ExecutionPolicy Bypass -File "...\Invoke-CAPlatformMonitor.ps1" -Scheduled -Tier Cool -SkipWebDrivers'
```

Or set the corresponding collector to an empty array in the tier config:

```json
{
    "tiers": {
        "cool": { "intervalMinutes": 15, "collectors": ["CPMHealth", "PSMHealth", "CertificateHealth"] }
    }
}
```
