#Requires -Version 5.1
<#
.SYNOPSIS
    CyberArk Platform Monitor v1.0.0 - Standalone Local Health Tool
.DESCRIPTION
    Single-file, zero-dependency tool for monitoring CyberArk platform health locally.
    Reads WMI/CIM, Windows services, event logs, certificate stores, registry, log files,
    and network connectivity. No CyberArk REST API calls. No authentication required.
    Runs under SYSTEM or any local admin account.

    Three operating modes:
      -Report      (default) One-shot health check. Produces HTML report + JSONL record.
      -Scheduled   Headless mode for scheduled tasks. JSONL append + log file. Exit code 0/1/2.
      -Interactive Live console dashboard with color-coded status. Optional JSONL.

    Storage: JSONL (one file per day: platform-metrics-YYYY-MM-DD.jsonl). Append-only.
    Configurable retention (default 30 days). Compatible with any text processor.

    Collectors (each isolated with try/catch - one failure does not stop others):
      - System Health   : CPU, memory, disk, uptime, installed components (WMI/CIM)
      - Service Status  : CyberArk service health, restart count, MTTR, availability (Get-Service + WinEvent)
      - Certificate Health: CyberArk certs in LocalMachine stores, expiry risk (Cert:\)
      - Server Capacity : Performance counters, disk I/O, network connections (Get-Counter)
      - CPM Health      : CPM pm_error.log parsing, error counts (registry + file)
      - PSM Health      : PSM service status, shadow user errors, categorized errors (PSMConsole.log)
      - Connectivity    : TCP port checks to Vault and PSM servers (TcpClient)
      - WebDriver Health: Browser/driver version detection and compatibility (registry + file system)

    Exit codes (Scheduled mode):
      0 = All healthy
      1 = Warnings detected
      2 = Critical conditions detected

    Requires PowerShell 5.1 or later (Windows PowerShell). No external modules.
.PARAMETER Report
    Run a one-shot health check and generate an HTML report. This is the default mode.
.PARAMETER Scheduled
    Headless mode for scheduled tasks. Appends to JSONL, writes log file.
    Exits with code 0 (OK), 1 (Warning), or 2 (Critical).
.PARAMETER Interactive
    Live console dashboard. Refreshes every -RefreshSeconds seconds (default: 5).
    Use -DashboardSimulation to run on non-Windows with mock data.
.PARAMETER SkipSystemHealth
    Skip the system health collector (CPU, memory, disk, uptime).
.PARAMETER SkipServices
    Skip the service resiliency collector.
.PARAMETER SkipCertificates
    Skip the certificate health collector.
.PARAMETER SkipCPM
    Skip the CPM health collector (CPM log parsing).
.PARAMETER SkipPSM
    Skip the PSM health collector (PSM log parsing and service check).
.PARAMETER SkipWebDrivers
    Skip the WebDriver compatibility collector.
.PARAMETER SkipPVWA
    Skip the PVWA/IIS health collector (W3SVC, PasswordVault app pool, recycles).
.PARAMETER SkipLogScan
    Skip the CyberArk log-code scanner (Vault ITALog, CPM CACPM, Connector Manager, PVWA log4net).
.PARAMETER SkipConnectivity
    Skip the network connectivity tests.
.PARAMETER SkipCapacity
    Skip the server capacity collector (performance counters).
.PARAMETER VaultAddress
    Vault server hostname or IP address(es) to test connectivity to port 1858.
    Overrides config file value.
.PARAMETER VaultPort
    Vault port number. Default: 1858.
.PARAMETER PSMServers
    Additional PSM server hostname(s) or IP(s) for connectivity testing.
.PARAMETER ConnectivityPorts
    Additional TCP ports to test beyond the default Vault port.
.PARAMETER FarmPeers
    Other CyberArk farm servers this box should watch, so each server can run this
    script independently and report when a peer goes down. Formats: 'host' (ICMP
    ping), 'host:3389' (TCP), 'host:1858,443' (multiple TCP ports).
    A peer-down alert only fires after the peer fails 2+ consecutive check-ins AND
    stays down past the grace window (default 150s) -- transient network errors
    and quick restarts do not alert. Overrides config connectivity.farmPeers.
.PARAMETER PeerGraceSeconds
    Grace window in seconds before a failing farm peer is confirmed Down.
    Default: 150 (2.5 minutes). Overrides config connectivity.peerDownGraceSeconds.
.PARAMETER CpuWarningPercent
    CPU usage warning threshold (percent). Overrides config.
.PARAMETER CpuCriticalPercent
    CPU usage critical threshold (percent). Overrides config.
.PARAMETER MemoryWarningPercent
    Memory usage warning threshold (percent). Overrides config.
.PARAMETER MemoryCriticalPercent
    Memory usage critical threshold (percent). Overrides config.
.PARAMETER DiskWarningPercent
    Disk usage warning threshold (percent). Overrides config.
.PARAMETER DiskCriticalPercent
    Disk usage critical threshold (percent). Overrides config.
.PARAMETER CertWarningDays
    Days before certificate expiry to trigger Warning. Overrides config.
.PARAMETER CertCriticalDays
    Days before certificate expiry to trigger Critical. Overrides config.
.PARAMETER OutputPath
    Path (directory or file) for the HTML report output. Overrides config.
.PARAMETER MetricsPath
    Directory for JSONL metrics files. Overrides config.
.PARAMETER RetentionDays
    Number of days to retain JSONL metrics files. Default: 30.
.PARAMETER RefreshSeconds
    Dashboard refresh interval in seconds (Interactive mode). Default: 5.
.PARAMETER DashboardSimulation
    Run the dashboard with mock data. Useful for testing on non-Windows systems.
.PARAMETER DashboardIterations
    Maximum dashboard refresh cycles before exiting (Interactive mode).
    0 = run until Q is pressed (default). Useful for headless smoke tests.
.PARAMETER ConfigPath
    Explicit path to ca-platform-monitor.json configuration file.
    Search order: -ConfigPath > $PSScriptRoot\ca-platform-monitor.json > $env:USERPROFILE\.cyberark\ca-platform-monitor.json
.PARAMETER LogLevel
    Logging verbosity: Debug, Info, Warn, Error. Default: Info.
.PARAMETER LogPath
    Directory for log files. Overrides config.
.PARAMETER ForecastDays
    Number of days of JSONL history to use for capacity forecasting. Default: 30.
.PARAMETER UseMockData
    Force mock data for all collectors. Useful for testing on non-Windows systems.
.PARAMETER Tier
    Run only the collectors in the specified tier: Hot (1m), Warm (5m), or Cool (15m).
    When combined with -Scheduled, runs only that tier's collectors.
    Without -Tier, all collectors run (backward compatible).
.PARAMETER Monitor
    Continuous monitoring mode (4th operating mode). Manages per-tier timers internally.
    Press Q to exit. Useful for testing or ad-hoc monitoring.
.PARAMETER NoAlerts
    Suppress SMTP alerting for this run. Collection and state updates still occur.
.PARAMETER TestAlert
    Send a test email using the configured SMTP settings and exit.
.PARAMETER DigestNow
    Force the daily digest email to be sent immediately and exit.
.PARAMETER RequirementsPath
    Explicit path to monitoring-requirements.json. Search order when not specified:
    $PSScriptRoot\monitoring-requirements.json > $env:USERPROFILE\.cyberark\monitoring-requirements.json
.PARAMETER StatePath
    Explicit path to platform-state.json. Search order when not specified:
    $PSScriptRoot\platform-state.json
.PARAMETER RegisterTasks
    Register three tier-based Windows scheduled tasks (Hot/Warm/Cool) and exit.
.PARAMETER UnregisterTasks
    Remove the monitor scheduled task(s) and exit.
.PARAMETER DumpConfig
    Print the full effective configuration (all keys, defaults merged with the
    on-disk file) as JSON and exit.
.PARAMETER UpgradeConfig
    Rewrite the config file so every current default key is present, preserving
    your existing values (backs up the previous file to *.bak), then exit. Use
    after upgrading the script to pick up new settings without losing customizations.
.PARAMETER Help
    Display usage examples and exit.
.EXAMPLE
    .\Invoke-CAPlatformMonitor.ps1

    Default mode: one-shot health check with HTML report in script directory.
.EXAMPLE
    .\Invoke-CAPlatformMonitor.ps1 -Report -UseMockData

    Generate an HTML report using mock data (works on macOS/Linux for testing).
.EXAMPLE
    .\Invoke-CAPlatformMonitor.ps1 -Scheduled -VaultAddress "vault01.corp.local" -MetricsPath "C:\CyberArkMetrics"

    Headless scheduled task mode. Appends to JSONL, exits with 0/1/2.
.EXAMPLE
    .\Invoke-CAPlatformMonitor.ps1 -Interactive -RefreshSeconds 10

    Live dashboard, refreshes every 10 seconds.
.EXAMPLE
    .\Invoke-CAPlatformMonitor.ps1 -Interactive -DashboardSimulation

    Live dashboard with mock data (works on macOS/Linux for testing).
.EXAMPLE
    .\Invoke-CAPlatformMonitor.ps1 -Report -SkipCapacity -SkipWebDrivers -CpuWarningPercent 70

    Report mode, skip slow collectors, override CPU warning threshold.
.EXAMPLE
    .\Invoke-CAPlatformMonitor.ps1 -Report -ConfigPath "C:\Config\ca-platform-monitor.json"

    Use an explicit configuration file path.
.EXAMPLE
    .\Invoke-CAPlatformMonitor.ps1 -Help

    Display full usage help and exit.
#>

[CmdletBinding()]
param(
    # Operating mode (mutually exclusive)
    [switch]$Report,
    [switch]$Scheduled,
    [switch]$Interactive,

    # Skip individual collectors
    [switch]$SkipSystemHealth,
    [switch]$SkipServices,
    [switch]$SkipCertificates,
    [switch]$SkipCPM,
    [switch]$SkipPSM,
    [switch]$SkipWebDrivers,
    [switch]$SkipConnectivity,
    [switch]$SkipCapacity,
    [switch]$SkipPVWA,
    [switch]$SkipLogScan,

    # Network targets
    [string[]]$VaultAddress,
    [int]$VaultPort = 1858,
    [string[]]$PSMServers,
    [int[]]$ConnectivityPorts,
    [string[]]$FarmPeers,
    [ValidateRange(0, 3600)]
    [int]$PeerGraceSeconds,

    # Threshold overrides
    [int]$CpuWarningPercent,
    [int]$CpuCriticalPercent,
    [int]$MemoryWarningPercent,
    [int]$MemoryCriticalPercent,
    [int]$DiskWarningPercent,
    [int]$DiskCriticalPercent,
    [int]$CertWarningDays,
    [int]$CertCriticalDays,

    # Output / storage
    [string]$OutputPath,
    [string]$MetricsPath,
    [int]$RetentionDays = 30,

    # Scheduled-task repetition interval (minutes) for -RegisterTasks
    [int]$IntervalMinutes,

    # Dashboard
    [ValidateRange(1, 300)]
    [int]$RefreshSeconds = 5,
    [switch]$DashboardSimulation,
    [ValidateRange(0, 10000)]
    [int]$DashboardIterations = 0,

    # Config / logging
    [string]$ConfigPath,
    [ValidateSet('Debug', 'Info', 'Warn', 'Error')]
    [string]$LogLevel = 'Info',
    [string]$LogPath,

    # Forecasting
    [int]$ForecastDays = 30,

    # Misc
    [switch]$UseMockData,
    [Alias('h')]
    [switch]$Help,

    # Tier-aware scheduled execution
    [ValidateSet('Hot','Warm','Cool')]
    [string]$Tier,

    # Continuous monitoring mode (4th operating mode)
    [switch]$Monitor,

    # Alerting control
    [switch]$NoAlerts,
    [switch]$TestAlert,
    [switch]$DigestNow,

    # File paths for monitoring subsystem
    [string]$RequirementsPath,
    [string]$StatePath,

    # Task registration
    [switch]$RegisterTasks,
    [switch]$UnregisterTasks,

    # Config utilities
    [switch]$DumpConfig,
    [switch]$UpgradeConfig,

    # Service baseline
    [switch]$Baseline
)

#region Help / First-Run Banner

function Show-Help {
    $c = 'Cyan'; $y = 'Yellow'; $g = 'Gray'
    Write-Host ""
    Write-Host "  Invoke-CAPlatformMonitor.ps1 v1.0.0" -ForegroundColor $c
    Write-Host "  CyberArk Platform Health Monitor - standalone, local-only (no REST/auth)" -ForegroundColor $c
    Write-Host "  =======================================================================" -ForegroundColor $c
    Write-Host ""
    Write-Host "  USAGE:" -ForegroundColor $y
    Write-Host "    .\Invoke-CAPlatformMonitor.ps1 [mode] [options]      (help: -h | -Help | -?)"
    Write-Host ""
    Write-Host "  MODES (pick one; default is -Report):" -ForegroundColor $y
    Write-Host "    -Report                One-shot health check -> HTML report + JSONL, then exits (default)"
    Write-Host "    -Scheduled             One-shot headless run for a scheduled task; exit code 0/1/2"
    Write-Host "    -Monitor               CONTINUOUS: stays running, polls each tier on its own"
    Write-Host "                           interval (Hot 1m / Warm 5m / Cool 15m). Press Q to quit."
    Write-Host "    -Interactive           Live console dashboard (refreshes every -RefreshSeconds)"
    Write-Host "    -Tier <Hot|Warm|Cool>  With -Scheduled/-Monitor: run only that tier's collectors"
    Write-Host ""
    Write-Host "  SCHEDULED TASKS (run repeatedly via Windows Task Scheduler):" -ForegroundColor $y
    Write-Host "    -RegisterTasks         Install 3 tier tasks (Hot/Warm/Cool) as SYSTEM, then exit"
    Write-Host "    -UnregisterTasks       Remove the 3 tier tasks, then exit"
    Write-Host ""
    Write-Host "  ALERTING / EMAIL (SMTP; anonymous relay only -- see config alerting.*):" -ForegroundColor $y
    Write-Host "    -TestAlert             Send a test email via configured SMTP and exit (0=sent,1=failed)"
    Write-Host "    -DigestNow             Send the daily digest email now and exit"
    Write-Host "    -NoAlerts              Suppress all outbound email for this run"
    Write-Host ""
    Write-Host "  COLLECTOR SKIPS (all collectors run by default; each auto-skips if absent):" -ForegroundColor $y
    Write-Host "    -SkipSystemHealth  -SkipServices  -SkipCertificates  -SkipCapacity"
    Write-Host "    -SkipConnectivity  -SkipCPM  -SkipPSM  -SkipWebDrivers  -SkipPVWA  -SkipLogScan"
    Write-Host ""
    Write-Host "  NETWORK / CONNECTIVITY:" -ForegroundColor $y
    Write-Host "    -VaultAddress <host[,host2]>  Vault(s) for the 1858 connectivity test"
    Write-Host "    -VaultPort <n>               Vault port (default: 1858)"
    Write-Host "    -PSMServers <host,...>       PSM servers to test (RDP 3389)"
    Write-Host "    -ConnectivityPorts <n,...>   Extra TCP ports to test"
    Write-Host "    -FarmPeers <list>            Peers to watch: 'host' (ping), 'host:3389',"
    Write-Host "                                 'host:1858,443'; ';'-separated. Down alert only after"
    Write-Host "                                 2+ failed check-ins AND the grace window elapses."
    Write-Host "    -PeerGraceSeconds <n>        Peer-down grace window (default: 150)"
    Write-Host ""
    Write-Host "  THRESHOLD OVERRIDES:" -ForegroundColor $y
    Write-Host "    -CpuWarningPercent/-CpuCriticalPercent      -MemoryWarningPercent/-MemoryCriticalPercent"
    Write-Host "    -DiskWarningPercent/-DiskCriticalPercent    -CertWarningDays/-CertCriticalDays"
    Write-Host ""
    Write-Host "  OUTPUT / PATHS:" -ForegroundColor $y
    Write-Host "    -OutputPath <file|dir>   HTML report path (a .html file, or an existing dir)"
    Write-Host "    -MetricsPath <dir>       JSONL metrics directory"
    Write-Host "    -LogPath <dir>           Log directory"
    Write-Host "    -ConfigPath <file>       Config file (search: -ConfigPath > script dir > %USERPROFILE%\.cyberark)"
    Write-Host "    -DumpConfig              Print the full effective config (every key) and exit"
    Write-Host "    -UpgradeConfig           Add any missing keys to your config file (keeps your values, .bak backup) and exit"
    Write-Host "    -RequirementsPath <file> monitoring-requirements.json path"
    Write-Host "    -StatePath <file>        platform-state.json path"
    Write-Host "    -RetentionDays <n>       JSONL retention (default: 30)"
    Write-Host ""
    Write-Host "  DASHBOARD / MISC:" -ForegroundColor $y
    Write-Host "    -RefreshSeconds <n>      Dashboard refresh (default: 5)"
    Write-Host "    -DashboardSimulation     Dashboard with mock data;  -DashboardIterations <n>  cap cycles"
    Write-Host "    -Baseline                Re-learn all service baselines from current state"
    Write-Host "    -LogLevel <lvl>          Debug|Info|Warn|Error (default: Info)"
    Write-Host "    -ForecastDays <n>        History days for capacity forecasting (default: 30)"
    Write-Host "    -UseMockData             Mock data for all collectors (offline testing)"
    Write-Host "    -Help | -h | -?          Show this help"
    Write-Host ""
    Write-Host "  EXAMPLES:" -ForegroundColor $y
    Write-Host "    .\Invoke-CAPlatformMonitor.ps1                              # one-shot report"
    Write-Host "    .\Invoke-CAPlatformMonitor.ps1 -Monitor                     # continuous poller (Q to quit)"
    Write-Host "    .\Invoke-CAPlatformMonitor.ps1 -RegisterTasks               # install Hot/Warm/Cool schtasks"
    Write-Host "    .\Invoke-CAPlatformMonitor.ps1 -Scheduled -Tier Warm        # single Warm-tier run (for a schtask)"
    Write-Host "    .\Invoke-CAPlatformMonitor.ps1 -TestAlert                   # send a test email and exit"
    Write-Host "    .\Invoke-CAPlatformMonitor.ps1 -Report -UseMockData         # render a report with mock data"
    Write-Host ""
    Write-Host "  CONFIG FILE:" -ForegroundColor $y
    Write-Host "    Auto-created next to the script (or at -ConfigPath) on first run: ca-platform-monitor.json" -ForegroundColor $g
    Write-Host "    Set services, thresholds, connectivity, tiers, alerting/SMTP, self-heal, log paths there." -ForegroundColor $g
    Write-Host ""
}

function Show-FirstRunBanner {
    param([string]$ConfigCreatedAt)
    Write-Host ""
    Write-Host "  *** First Run: Default Configuration Created ***" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  A default configuration file has been created at:" -ForegroundColor Gray
    Write-Host "    $ConfigCreatedAt" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  Edit the config file to set your environment specifics:" -ForegroundColor Gray
    Write-Host "    - VaultAddress (for connectivity tests)" -ForegroundColor Gray
    Write-Host "    - Thresholds (CPU/memory/disk/cert)" -ForegroundColor Gray
    Write-Host "    - MetricsPath (for JSONL storage)" -ForegroundColor Gray
    Write-Host "    - CPM/PSM log paths (if non-default)" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  Run with -Help for full usage information." -ForegroundColor Gray
    Write-Host ""
}

if ($Help) {
    Show-Help
    exit 0
}

#endregion

#region Strict Mode and Globals

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$script:ToolVersion    = '1.0.0'
$script:ToolName       = 'Invoke-CAPlatformMonitor'
$script:CorrelationID  = [guid]::NewGuid().ToString()

# Primary IPv4, resolved once per run. Stamped (with hostname) into every metric
# record so JSONL from many servers can be copied to one place and aggregated
# without name collisions or reverse-lookup guesswork.
$script:HostIp = ''
try {
    # Egress-interface IP via connected UDP socket (no packet is transmitted):
    # picks the adapter that actually routes, not a Hyper-V/WSL virtual NIC that
    # happens to sort first in the DNS list.
    $udp = $null
    try {
        $udp = New-Object System.Net.Sockets.UdpClient
        $udp.Connect('8.8.8.8', 53)
        $script:HostIp = "$($udp.Client.LocalEndPoint.Address)"
    }
    finally { if ($null -ne $udp) { $udp.Dispose() } }
}
catch { }
if ([string]::IsNullOrWhiteSpace($script:HostIp) -or $script:HostIp -eq '0.0.0.0') {
    try {
        $ipv4 = @([System.Net.Dns]::GetHostAddresses([System.Net.Dns]::GetHostName()) |
            Where-Object { $_.AddressFamily -eq [System.Net.Sockets.AddressFamily]::InterNetwork -and "$_" -ne '127.0.0.1' })
        if ($ipv4.Count -gt 0) { $script:HostIp = "$($ipv4[0])" } else { $script:HostIp = '' }
    }
    catch { $script:HostIp = '' }
}
$script:StartTime      = Get-Date
$script:Config         = $null
$script:LogFile        = $null
$script:LogLevel       = $LogLevel
$script:LogConsoleOut  = $true
$script:IsFirstRun     = $false
$script:OperatingMode  = 'Report'
$script:CurrentTier    = 'All'
$script:ExitCode       = 0

# Resolve operating mode
if ($Monitor) { $script:OperatingMode = 'Monitor' }
elseif ($Interactive) { $script:OperatingMode = 'Interactive' }
elseif ($Scheduled) { $script:OperatingMode = 'Scheduled' }
else { $script:OperatingMode = 'Report' }

# Resolve tier
$script:CurrentTier = if ($Tier) { $Tier } else { 'All' }

# Suppress console output in Scheduled mode by default (goes to log only)
if ($script:OperatingMode -eq 'Scheduled') { $script:LogConsoleOut = $false }

#endregion

#region Platform Detection

function Test-IsWindowsPlatform {
    <#
    .SYNOPSIS
        Returns $true when running on Windows, $false otherwise.
    #>
    [CmdletBinding()]
    [OutputType([bool])]
    param()

    if ($PSVersionTable.PSVersion.Major -ge 6) {
        if (Test-Path variable:global:IsWindows) {
            return $global:IsWindows
        }
        return $true
    }
    else {
        return [System.Environment]::OSVersion.Platform -eq [System.PlatformID]::Win32NT
    }
}

#endregion

#region Configuration

function Get-DefaultConfig {
    <#
    .SYNOPSIS
        Returns a hashtable with all default configuration values.
    #>
    return @{
        configVersion = '1.0'
        server = @{
            hostname    = ''
            environment = 'Production'
            role        = 'Auto'
        }
        collection = @{
            cpuSampleCount        = 5
            cpuSampleIntervalMs   = 1000
            eventLogLookbackDays  = 30
            logTailLines          = 1000
            logLookbackMinutes    = 60
            # Session usernames starting with any of these prefixes are counted
            # as PSM shadow users in the RDP session snapshot -- separates real
            # operator logons from PSM-brokered ones when correlating CPU/memory
            # with user count, and when hunting orphaned (disconnected) sessions.
            shadowUserPrefixes    = @('PSMShadowUser', 'PSM-')
            cyberArkServices      = @(
                'CyberArk Password Manager'
                'CyberArk Central Policy Manager Scanner'
                'CyberArk Privileged Session Manager'
                'CyberArk Application Password Provider'
                'PrivateArk Server'
                'PrivateArk Database'
                'CyberArk Vault Disaster Recovery'
                'CyberArk Event Notification Engine'
                'CyberArk Logic Container'
            )
        }
        # Recency framework: findings (service restarts/crashes, log errors) are
        # bucketed into these windows and ALERTS fire on the recent window, not the
        # all-time total -- so a burst last week that has since settled no longer
        # keeps a service/log flagged. Windows are in hours; alertWindowHours picks
        # which bucket drives restart/log alerts; crashLookbackDays is the window a
        # single unexpected termination / start failure alarms within.
        recency = @{
            dayHours         = 24
            weekHours        = 168
            monthHours       = 720
            alertWindowHours = 24
            crashLookbackDays = 7
        }
        connectivity = @{
            vaultAddress    = ''
            vaultPort       = 1858
            psmServers      = @()
            timeoutSeconds  = 5
            # Farm peer monitoring: other CyberArk servers this box watches so each
            # server independently reports a peer going down. Entries are strings
            # ('host', 'host:port', 'host:port1,port2' -- bare host = ICMP ping) or
            # objects: { "host": "psm01", "ports": [3389], "ping": true }.
            farmPeers            = @()
            # In-run retries per target: total attempts and delay between them.
            # Absorbs transient network errors within a single check-in.
            retryCount           = 2
            retryDelaySeconds    = 3
            # A peer must stay down for this long (AND fail 2+ consecutive
            # check-ins) before a Critical peer-down alert fires. Default 150s
            # (2.5 min) tolerates blips and restarts without paging.
            peerDownGraceSeconds = 150
        }
        thresholds = @{
            cpuWarningPercent      = 80
            cpuCriticalPercent     = 95
            memoryWarningPercent   = 85
            memoryCriticalPercent  = 95
            diskWarningPercent     = 80
            diskCriticalPercent    = 95
            certWarningDays        = 30
            certCriticalDays       = 7
            serviceRestartWarning  = 5
            serviceRestartCritical = 10
            # Warning when this many DISCONNECTED RDP sessions accumulate
            # (orphaned-logon indicator on PSM hosts). 0 = disabled.
            rdpDisconnectedWarning = 0
            cpmErrorWarning        = 1
            cpmErrorCritical       = 10
            psmSystemErrorWarning  = 1
            psmSystemErrorCritical = 10
        }
        serviceBaseline = @{
            stabilizationMinutes  = 30
            autoAdapt             = $true
            expectedStates        = @{}
            additionalServices    = @()
            # Self-heal master switch. Even when $true, NOTHING is restarted until
            # autoRestartServices below names the services explicitly -- automatic
            # remediation on privileged-access infrastructure must be opt-in per
            # service (an admin stopping the Vault/CPM/PSM for maintenance must
            # never be fought by the monitor).
            autoRestart           = $true
            # REQUIRED allowlist: ONLY services named here are ever auto-restarted.
            # EMPTY (default) = self-heal inactive. Naming a service here is the
            # explicit "keep this running at all costs" intent.
            autoRestartServices   = @()
            # OPTIONAL exclusions: monitored services that must NEVER be auto-restarted
            # (belt-and-suspenders alongside expectedStates for DR/passive nodes).
            autoRestartExclude    = @()
            # NMS-style escalating retry schedule (minutes between attempts while
            # the service stays down): first attempt immediately on detection,
            # then after 5, 15, 30, 60 minutes; once the list is exhausted the
            # LAST value repeats (hourly). The position resets when the service
            # is observed Running again. Attempt spacing also paces the outcome
            # emails. Mirrors Nagios retry_interval/notification escalation
            # practice: fast initial retries, then progressively quieter.
            restartBackoffMinutes = @(0, 5, 15, 30, 60)
            # Absolute per-service cap on restart attempts per calendar day --
            # the final flap-storm guard on top of the backoff schedule. 10
            # covers the full escalation ladder plus ~5 hourly steady-state
            # attempts; the cap-reached email sends once per day.
            maxRestartsPerDay     = 10
        }
        storage = @{
            metricsPath    = ''
            retentionDays  = 30
        }
        scheduling = @{
            # Interval (minutes) for the -RegisterTasks scheduled task, which runs
            # a full -Scheduled collection (all tests) each time it fires.
            intervalMinutes = 5
            taskName        = 'CyberArk Platform Monitor'
        }
        reporting = @{
            outputPath           = ''
            title                = 'CyberArk Platform Health Report'
            includeForecasting   = $true
            # Minimum span of collected history (hours) before a capacity forecast
            # is produced. Extrapolating a per-DAY growth rate from a few minutes
            # of samples turns normal jitter into absurd trends (e.g. a false
            # "URGENT: 2 days" from 30 min of flat memory). Default 24h.
            forecastMinSpanHours = 24
        }
        dashboard = @{
            refreshSeconds = 5
        }
        logging = @{
            level      = 'Info'
            path       = ''
            maxSizeMB  = 10     # roll (archive + zip) the daily log above this size
        }
        cpmHealth = @{
            logPath          = ''
            logFileName      = 'pm_error.log'
            tailLines        = 1000
            lookbackMinutes  = 60
            errorPatterns    = @('\[ERROR\]', 'Failure', 'Timeout', 'Exception', 'rotation failed')
            ignorePatterns   = @('Configuration refresh completed', 'ITAUTIL')
            registryPath     = 'HKLM:\SOFTWARE\CyberArk\CentralPolicy Manager\Administration'
            registryValue    = 'AppInstallDirectory'
            defaultLogPath   = 'C:\Program Files (x86)\CyberArk\Password Manager\Logs'
            # Plugin inventory sub-check ('' = auto: InstallPath\bin\Plugins)
            pluginsPath        = ''
        }
        psmHealth = @{
            logPath          = ''
            logFileName      = 'PSMConsole.log'
            tailLines        = 500
            lookbackMinutes  = 60
            serviceName      = 'CyberArk Privileged Session Manager'
            registryPath     = 'HKLM:\SOFTWARE\CyberArk\PSM'
            registryValue    = 'InstallLocation'
            defaultLogPath   = 'C:\Program Files (x86)\CyberArk\PSM\Logs'
            # Connection-component .ini validation ('' = auto: Components dir)
            componentsPath      = ''
            # Recording-storage backlog ('' = auto: InstallLocation\Recordings)
            recordingsPath      = ''
            recordingWarnGB     = 10
            recordingCriticalGB = 2
        }
        webDriver = @{
            strictVersionMatch    = $false
            knownChromePaths      = @(
                'C:\Program Files (x86)\Google\Chrome\Application\chrome.exe'
                'C:\Program Files\Google\Chrome\Application\chrome.exe'
            )
            knownEdgePaths        = @(
                'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'
                'C:\Program Files\Microsoft\Edge\Application\msedge.exe'
            )
            psmComponentsPath     = ''
        }
        pvwaHealth = @{
            appPoolName      = 'PasswordVault'
            siteName         = 'PasswordVault'
            installPath      = 'C:\inetpub\wwwroot\PasswordVault'
            registryPath     = 'HKLM:\SOFTWARE\Wow6432Node\CyberArk\CyberArk Password Vault Web Access'
            iisServiceName   = 'W3SVC'
            recycleWarnCount = 3      # > N app-pool recycles in 24h -> Warning
            memoryWarnMB     = 4096   # total w3wp working set warning (0 = off)
        }
        logScan = @{
            # Generic CyberArk log-code scanner. Counts ERROR/WARN severities in
            # the last `tailLines` lines of each source whose file exists (a source
            # with no file present is skipped). Recent-tail counts -- for deep,
            # time-windowed correlation use the CA.LogAnalysis module.
            tailLines     = 1000
            warnCount     = 1        # >= this many errors (any source) -> Warning
            criticalCount = 25       # >= this many errors in ONE source -> Critical
            sources = @(
                @{ name = 'Vault';            format = 'ITALog';   paths = @('C:\Program Files (x86)\PrivateArk\Server\Logs\ITALog.log','C:\CyberArk\Logs\ITALog.log') }
                @{ name = 'ConnectorManager'; format = 'BLService'; paths = @('C:\Program Files (x86)\CyberArk\Password Manager\Logs\BLServiceApp.log','C:\CyberArk\Logs\BLServiceApp.log') }
                @{ name = 'PVWA';             format = 'log4net';  paths = @('C:\inetpub\wwwroot\PasswordVault\Logs\CyberArk.WebApplication.log','C:\CyberArk\Logs\CyberArk.WebApplication.log') }
            )
        }
        tiers = @{
            hot  = @{ intervalMinutes = 1;  collectors = @('SystemHealth','ServerCapacity') }
            warm = @{ intervalMinutes = 5;  collectors = @('ServiceStatus','Connectivity') }
            cool = @{ intervalMinutes = 15; collectors = @('CPMHealth','PSMHealth','CertificateHealth','WebDriverHealth','PVWAHealth','LogScan') }
        }
        alerting = @{
            enabled = $false
            smtp = @{
                server = ''
                port   = 25
                from   = 'cyberark-monitor@corp.local'
                useTls = $false
            }
            rules = @{
                cooldownMinutes          = 30
                escalateAfterMinutes     = 60
                suppressDuplicateMinutes = 15
                maxNotificationsPerAlert = 10
            }
            digest = @{
                enabled          = $false
                time             = '07:00'
                recipients       = @()
                sendOnlyIfIssues = $false
            }
            defaults = @{
                notifyTo   = @()
                escalateTo = @()
            }
        }
    }
}

function Import-MonitorConfig {
    <#
    .SYNOPSIS
        Load configuration from JSON file with search-order fallback.
        Auto-creates default config at $PSScriptRoot if none found.
    #>
    [CmdletBinding()]
    param(
        [Parameter()]
        [string]$ExplicitPath
    )

    $script:ResolvedConfigPath = $null   # set to the file actually loaded/created
    $defaults = Get-DefaultConfig
    $searchPaths = @()

    if (-not [string]::IsNullOrWhiteSpace($ExplicitPath)) {
        $searchPaths += $ExplicitPath
    }

    $scriptDir = $PSScriptRoot
    if ([string]::IsNullOrWhiteSpace($scriptDir)) {
        $scriptDir = Split-Path -Parent $MyInvocation.ScriptName
    }

    $searchPaths += (Join-Path $scriptDir 'ca-platform-monitor.json')

    if ($env:USERPROFILE) {
        $searchPaths += (Join-Path (Join-Path $env:USERPROFILE '.cyberark') 'ca-platform-monitor.json')
    }

    $anyConfigFileFound = $false

    foreach ($candidate in $searchPaths) {
        if (Test-Path $candidate) {
            $anyConfigFileFound = $true
            try {
                $raw = Get-Content -Path $candidate -Raw | ConvertFrom-Json
                $merged = $defaults

                $sections = @('server','collection','connectivity','thresholds','serviceBaseline','storage','scheduling','reporting','dashboard','logging','cpmHealth','psmHealth','webDriver','pvwaHealth','logScan','tiers','alerting')
                foreach ($section in $sections) {
                    # Safe property read -- under StrictMode a dot-access on a key
                    # the user's JSON simply omits would throw, reject the whole
                    # config, and fall through to defaults.
                    $sectionObj = Get-PSPropertySafe -Object $raw -Name $section
                    if ($null -ne $sectionObj -and $null -ne $merged[$section]) {
                        Merge-JsonObjectIntoHashtable -Target $merged[$section] -Source $sectionObj
                    }
                }

                $rawVersion = Get-PSPropertySafe -Object $raw -Name 'configVersion'
                if ($null -ne $rawVersion) { $merged['configVersion'] = $rawVersion }

                $script:ResolvedConfigPath = $candidate
                return $merged
            }
            catch {
                Write-Warning "Failed to parse config file '$candidate': $($_.Exception.Message)"
            }
        }
    }

    # Create the default config ONLY when no config file exists anywhere --
    # never overwrite an existing (possibly just-corrupted) admin config file.
    # Honor an explicit -ConfigPath: the default belongs where the caller asked.
    if (-not $anyConfigFileFound) {
        $defaultPath = if (-not [string]::IsNullOrWhiteSpace($ExplicitPath)) { $ExplicitPath }
                       else { Join-Path $scriptDir 'ca-platform-monitor.json' }
        try {
            $jsonDefaults = $defaults | ConvertTo-Json -Depth 10
            [System.IO.File]::WriteAllText($defaultPath, $jsonDefaults, [System.Text.UTF8Encoding]::new($false))
            $script:IsFirstRun = $true
            $script:FirstRunConfigPath = $defaultPath
            $script:ResolvedConfigPath = $defaultPath
        }
        catch {
            # Non-fatal - continue with defaults
        }
    }
    else {
        Write-Warning 'Existing config file(s) could not be parsed -- running with built-in defaults (file NOT overwritten).'
    }

    return $defaults
}

function Merge-JsonObjectIntoHashtable {
    <#
    .SYNOPSIS
        Recursively merges a ConvertFrom-Json PSCustomObject into a defaults
        hashtable. Nested objects merge key-by-key so a user config specifying
        only SOME keys of a sub-object (e.g. alerting.smtp.server only) keeps
        the built-in defaults for the rest instead of dropping them.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][hashtable]$Target,
        [Parameter(Mandatory)]$Source
    )

    foreach ($prop in @($Source.PSObject.Properties)) {
        $name  = $prop.Name
        $value = $prop.Value
        if ($Target.ContainsKey($name) -and $Target[$name] -is [hashtable] -and
            $value -is [System.Management.Automation.PSCustomObject]) {
            Merge-JsonObjectIntoHashtable -Target $Target[$name] -Source $value
        }
        else {
            $Target[$name] = $value
        }
    }
}

function Merge-ConfigWithParams {
    <#
    .SYNOPSIS
        Override config values with explicitly provided CLI parameters.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$Config,

        # The CALLER's $PSBoundParameters. Must be passed in: inside this function
        # $PSBoundParameters reflects only this function's own parameters, so the
        # script-level CLI overrides would never be detected otherwise.
        [Parameter(Mandatory)]
        [hashtable]$BoundParameters
    )

    # Connectivity overrides.
    # Re-split array params on ',' -- powershell.exe -File (scheduled tasks)
    # binds "-VaultAddress v1,v2" as ONE string; hostnames cannot contain
    # commas, so splitting is always safe. (FarmPeers splits on ';' later --
    # ',' separates ports within one peer spec.)
    if ($BoundParameters.ContainsKey('VaultAddress') -and $VaultAddress) {
        $vaultList = @($VaultAddress | ForEach-Object { $_ -split ',' } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
        if ($vaultList.Count -gt 0) {
            $Config.connectivity.vaultAddress = $vaultList[0]
            if ($vaultList.Count -gt 1) {
                $Config.connectivity.psmServers = @($vaultList[1..($vaultList.Count - 1)])
            }
        }
    }
    if ($BoundParameters.ContainsKey('VaultPort'))        { $Config.connectivity.vaultPort            = $VaultPort }
    if ($BoundParameters.ContainsKey('PSMServers') -and $PSMServers) {
        $Config.connectivity.psmServers = @($PSMServers | ForEach-Object { $_ -split ',' } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    }
    if ($BoundParameters.ContainsKey('FarmPeers'))        { $Config.connectivity.farmPeers            = $FarmPeers }
    if ($BoundParameters.ContainsKey('PeerGraceSeconds')) { $Config.connectivity.peerDownGraceSeconds = $PeerGraceSeconds }

    # Threshold overrides
    if ($BoundParameters.ContainsKey('CpuWarningPercent'))      { $Config.thresholds.cpuWarningPercent     = $CpuWarningPercent }
    if ($BoundParameters.ContainsKey('CpuCriticalPercent'))     { $Config.thresholds.cpuCriticalPercent    = $CpuCriticalPercent }
    if ($BoundParameters.ContainsKey('MemoryWarningPercent'))   { $Config.thresholds.memoryWarningPercent  = $MemoryWarningPercent }
    if ($BoundParameters.ContainsKey('MemoryCriticalPercent'))  { $Config.thresholds.memoryCriticalPercent = $MemoryCriticalPercent }
    if ($BoundParameters.ContainsKey('DiskWarningPercent'))     { $Config.thresholds.diskWarningPercent    = $DiskWarningPercent }
    if ($BoundParameters.ContainsKey('DiskCriticalPercent'))    { $Config.thresholds.diskCriticalPercent   = $DiskCriticalPercent }
    if ($BoundParameters.ContainsKey('CertWarningDays'))        { $Config.thresholds.certWarningDays       = $CertWarningDays }
    if ($BoundParameters.ContainsKey('CertCriticalDays'))       { $Config.thresholds.certCriticalDays      = $CertCriticalDays }

    # Storage / output overrides
    if ($BoundParameters.ContainsKey('MetricsPath'))    { $Config.storage.metricsPath     = $MetricsPath }
    if ($BoundParameters.ContainsKey('RetentionDays'))  { $Config.storage.retentionDays   = $RetentionDays }
    if ($BoundParameters.ContainsKey('OutputPath'))     { $Config.reporting.outputPath    = $OutputPath }

    # Dashboard
    if ($BoundParameters.ContainsKey('RefreshSeconds')) { $Config.dashboard.refreshSeconds = $RefreshSeconds }

    # Logging
    if ($BoundParameters.ContainsKey('LogLevel'))  { $Config.logging.level = $LogLevel }
    if ($BoundParameters.ContainsKey('LogPath'))   { $Config.logging.path  = $LogPath }
}

#endregion

#region Monitoring Requirements

function Get-DefaultRequirements {
    <#
    .SYNOPSIS
        Returns an array of 5 default monitoring requirement objects.
        These serve as the initial monitoring-requirements.json content.
    #>
    [CmdletBinding()]
    [OutputType([array])]
    param()

    return @(
        [ordered]@{
            id          = 'REQ-001'
            name        = 'CPU Utilization'
            description = 'Average CPU usage must stay below warning/critical thresholds'
            enabled     = $true
            collector   = 'SystemHealth'
            metricPath  = 'CPU.Average'
            filter      = $null
            direction   = 'HigherIsBad'
            warningThreshold  = 80
            criticalThreshold = 95
            tier        = 'Hot'
            sla         = 'CPU average below 80% during business hours'
            runbookUrl  = ''
            notification = [ordered]@{
                notifyTo   = @()
                escalateTo = @()
            }
        }
        [ordered]@{
            id          = 'REQ-002'
            name        = 'Memory Utilization'
            description = 'Memory usage percentage must stay below warning/critical thresholds'
            enabled     = $true
            collector   = 'SystemHealth'
            metricPath  = 'Memory.UsedPercent'
            filter      = $null
            direction   = 'HigherIsBad'
            warningThreshold  = 85
            criticalThreshold = 95
            tier        = 'Hot'
            sla         = 'Memory usage below 85% sustained'
            runbookUrl  = ''
            notification = [ordered]@{
                notifyTo   = @()
                escalateTo = @()
            }
        }
        [ordered]@{
            id          = 'REQ-003'
            name        = 'Vault Service Running'
            description = 'PrivateArk Server service must be in Running state'
            enabled     = $true
            collector   = 'ServiceStatus'
            metricPath  = 'Services.Status'
            filter      = [ordered]@{ field = 'ServiceName'; value = 'PrivateArk Server' }
            direction   = 'Equals'
            warningThreshold  = $null
            criticalThreshold = 'Running'
            tier        = 'Warm'
            sla         = 'Vault service 99.9% uptime'
            runbookUrl  = ''
            notification = [ordered]@{
                notifyTo   = @()
                escalateTo = @()
            }
        }
        [ordered]@{
            id          = 'REQ-004'
            name        = 'Vault Connectivity'
            description = 'TCP connectivity to Vault port 1858 must succeed'
            enabled     = $true
            collector   = 'Connectivity'
            metricPath  = 'Reachable'
            filter      = [ordered]@{ field = 'Port'; value = 1858 }
            direction   = 'Equals'
            warningThreshold  = $null
            criticalThreshold = 'True'
            tier        = 'Warm'
            sla         = 'Vault network path available 99.9%'
            runbookUrl  = ''
            notification = [ordered]@{
                notifyTo   = @()
                escalateTo = @()
            }
        }
        [ordered]@{
            id          = 'REQ-005'
            name        = 'Certificate Expiry'
            description = 'Minimum days to certificate expiry across all CyberArk certificates'
            enabled     = $true
            collector   = 'CertificateHealth'
            metricPath  = 'MinDaysToExpiry'
            filter      = $null
            direction   = 'LowerIsBad'
            warningThreshold  = 30
            criticalThreshold = 7
            tier        = 'Cool'
            sla         = 'No certificates expiring within 30 days without renewal plan'
            runbookUrl  = ''
            notification = [ordered]@{
                notifyTo   = @()
                escalateTo = @()
            }
        }
    )
}

function Import-MonitoringRequirements {
    <#
    .SYNOPSIS
        Load monitoring-requirements.json from: explicit path > $PSScriptRoot > $env:USERPROFILE\.cyberark.
        Auto-creates with defaults if missing. Returns array of requirement PSCustomObjects.
    #>
    [CmdletBinding()]
    [OutputType([array])]
    param(
        [Parameter()]
        [string]$ExplicitPath
    )

    $searchPaths = @()

    if (-not [string]::IsNullOrWhiteSpace($ExplicitPath)) {
        $searchPaths += $ExplicitPath
    }

    $scriptDir = $PSScriptRoot
    if ([string]::IsNullOrWhiteSpace($scriptDir)) {
        $scriptDir = Split-Path -Parent $MyInvocation.ScriptName
    }
    if ([string]::IsNullOrWhiteSpace($scriptDir)) {
        $scriptDir = $PWD.Path
    }

    $searchPaths += (Join-Path $scriptDir 'monitoring-requirements.json')

    if ($env:USERPROFILE) {
        $searchPaths += (Join-Path (Join-Path $env:USERPROFILE '.cyberark') 'monitoring-requirements.json')
    }

    $anyRequirementsFileFound = $false

    foreach ($candidate in $searchPaths) {
        if (Test-Path $candidate) {
            $anyRequirementsFileFound = $true
            try {
                $raw = Get-Content -Path $candidate -Raw | ConvertFrom-Json
                # Convert to array of PSCustomObjects
                $requirements = @()
                foreach ($item in $raw) {
                    $requirements += $item
                }
                Write-Log -Message "Loaded $($requirements.Count) monitoring requirement(s) from: $candidate" -Level Info -Color Gray
                return $requirements
            }
            catch {
                Write-Log -Message "Failed to parse requirements file '$candidate': $($_.Exception.Message)" -Level Warn -Color Yellow
            }
        }
    }

    $defaults = Get-DefaultRequirements

    # Create the default file ONLY when none exists -- a malformed existing file
    # must never be silently overwritten (it may hold customized thresholds).
    if (-not $anyRequirementsFileFound) {
        # Honor an explicit -RequirementsPath for auto-creation (matches
        # Import-MonitorConfig); otherwise the default lands beside the script.
        $defaultPath = if (-not [string]::IsNullOrWhiteSpace($ExplicitPath)) { $ExplicitPath }
                       else { Join-Path $scriptDir 'monitoring-requirements.json' }
        try {
            $jsonDefaults = $defaults | ConvertTo-Json -Depth 6
            [System.IO.File]::WriteAllText($defaultPath, $jsonDefaults, [System.Text.UTF8Encoding]::new($false))
            Write-Log -Message "Created default monitoring-requirements.json at: $defaultPath" -Level Info -Color Gray
        }
        catch {
            Write-Log -Message "Could not write default requirements file: $($_.Exception.Message)" -Level Warn -Color Yellow
        }
    }
    else {
        Write-Log -Message 'Existing requirements file could not be parsed -- using built-in defaults (file NOT overwritten)' -Level Warn -Color Yellow
    }

    # Convert ordered hashtables to PSCustomObjects for consistent downstream usage
    $result = @()
    foreach ($item in $defaults) {
        $result += [PSCustomObject]$item
    }
    return $result
}

#endregion

#region Platform State

function Get-EmptyState {
    <#
    .SYNOPSIS
        Returns a skeleton state hashtable with all keys initialized.
    #>
    [CmdletBinding()]
    [OutputType([hashtable])]
    param()

    return [ordered]@{
        schemaVersion  = '1.0'
        lastModified   = (Get-Date).ToUniversalTime().ToString('o')
        lastCollection = [ordered]@{
            hot  = $null
            warm = $null
            cool = $null
        }
        dailySummaries  = [ordered]@{}
        activeAlerts    = [ordered]@{}
        alertHistory    = @()
        peaks           = [ordered]@{}
        digestLastSent  = $null
        serviceBaseline = [ordered]@{}
        peerStatus      = [ordered]@{}
        serviceRestarts = [ordered]@{}
    }
}

function Import-PlatformState {
    <#
    .SYNOPSIS
        Load platform-state.json. If missing or corrupt, return empty skeleton.
        Search order: explicit path > $PSScriptRoot.
    #>
    [CmdletBinding()]
    [OutputType([hashtable])]
    param(
        [Parameter()]
        [string]$ExplicitPath
    )

    $searchPaths = @()

    if (-not [string]::IsNullOrWhiteSpace($ExplicitPath)) {
        $searchPaths += $ExplicitPath
    }

    $scriptDir = $PSScriptRoot
    if ([string]::IsNullOrWhiteSpace($scriptDir)) {
        $scriptDir = Split-Path -Parent $MyInvocation.ScriptName
    }
    if ([string]::IsNullOrWhiteSpace($scriptDir)) {
        $scriptDir = $PWD.Path
    }

    $searchPaths += (Join-Path $scriptDir 'platform-state.json')

    # Take the same cross-process mutex Export-PlatformState uses so a read can
    # never race a concurrent tier task's replace and see a missing/partial file
    # (which would silently reset all state on this process's next save).
    $importMutex = $null
    $importMutexAcquired = $false
    try {
        $importMutex = [System.Threading.Mutex]::new($false, 'Global\CyberArkPlatformMonitorState')
        $importMutexAcquired = $importMutex.WaitOne(10000)
    }
    catch { }

    try {
    foreach ($candidate in $searchPaths) {
        if (Test-Path $candidate) {
            try {
                $raw = Get-Content -Path $candidate -Raw | ConvertFrom-Json
                # All reads via Get-PSPropertySafe: under StrictMode a dot-access
                # on a key missing from an older-schema state file would throw and
                # discard the ENTIRE accumulated state in favor of an empty one.
                $rawSchema   = Get-PSPropertySafe -Object $raw -Name 'schemaVersion'
                $rawModified = Get-PSPropertySafe -Object $raw -Name 'lastModified'
                # Convert PSCustomObject back to ordered hashtable for mutable access
                $state = [ordered]@{
                    schemaVersion  = if ($null -ne $rawSchema) { $rawSchema } else { '1.0' }
                    lastModified   = if ($null -ne $rawModified) { $rawModified } else { (Get-Date).ToUniversalTime().ToString('o') }
                    lastCollection = [ordered]@{
                        hot  = $null
                        warm = $null
                        cool = $null
                    }
                    dailySummaries = [ordered]@{}
                    activeAlerts   = [ordered]@{}
                    alertHistory   = @()
                    peaks          = [ordered]@{}
                    digestLastSent = Get-PSPropertySafe -Object $raw -Name 'digestLastSent'
                    serviceBaseline = [ordered]@{}
                    peerStatus      = [ordered]@{}
                    serviceRestarts = [ordered]@{}
                }

                # Restore lastCollection
                $rawLastCollection = Get-PSPropertySafe -Object $raw -Name 'lastCollection'
                if ($null -ne $rawLastCollection) {
                    foreach ($tierKey in @('hot','warm','cool')) {
                        $tierVal = Get-PSPropertySafe -Object $rawLastCollection -Name $tierKey
                        if ($null -ne $tierVal) {
                            $state.lastCollection[$tierKey] = $tierVal
                        }
                    }
                }

                # Restore dailySummaries
                $rawDaily = Get-PSPropertySafe -Object $raw -Name 'dailySummaries'
                if ($null -ne $rawDaily) {
                    foreach ($prop in ($rawDaily | Get-Member -MemberType NoteProperty -ErrorAction SilentlyContinue)) {
                        $dateKey = $prop.Name
                        $dayData = $rawDaily.$dateKey
                        $dayHash = [ordered]@{}
                        foreach ($metricProp in ($dayData | Get-Member -MemberType NoteProperty -ErrorAction SilentlyContinue)) {
                            $metricKey = $metricProp.Name
                            $metricVal = $dayData.$metricKey
                            # NOTE: assignments inside $() must NOT be wrapped in
                            # parentheses -- '($v = x)' EMITS the value, doubling
                            # the output into an array and corrupting the state.
                            $dayHash[$metricKey] = [ordered]@{
                                min    = $($v = Get-PSPropertySafe -Object $metricVal -Name 'min';    if ($null -ne $v) { $v } else { 0 })
                                max    = $($v = Get-PSPropertySafe -Object $metricVal -Name 'max';    if ($null -ne $v) { $v } else { 0 })
                                avg    = $($v = Get-PSPropertySafe -Object $metricVal -Name 'avg';    if ($null -ne $v) { $v } else { 0 })
                                sum    = $($v = Get-PSPropertySafe -Object $metricVal -Name 'sum';    if ($null -ne $v) { $v } else { 0 })
                                count  = $($v = Get-PSPropertySafe -Object $metricVal -Name 'count';  if ($null -ne $v) { $v } else { 0 })
                                peakAt = Get-PSPropertySafe -Object $metricVal -Name 'peakAt'
                            }
                        }
                        $state.dailySummaries[$dateKey] = $dayHash
                    }
                }

                # Restore activeAlerts
                $rawActive = Get-PSPropertySafe -Object $raw -Name 'activeAlerts'
                if ($null -ne $rawActive) {
                    foreach ($prop in ($rawActive | Get-Member -MemberType NoteProperty -ErrorAction SilentlyContinue)) {
                        $alertKey = $prop.Name
                        $alertVal = $rawActive.$alertKey
                        $state.activeAlerts[$alertKey] = [ordered]@{
                            requirementId     = Get-PSPropertySafe -Object $alertVal -Name 'requirementId'
                            severity          = Get-PSPropertySafe -Object $alertVal -Name 'severity'
                            firstSeen         = Get-PSPropertySafe -Object $alertVal -Name 'firstSeen'
                            lastSeen          = Get-PSPropertySafe -Object $alertVal -Name 'lastSeen'
                            lastValue         = Get-PSPropertySafe -Object $alertVal -Name 'lastValue'
                            occurrences       = $($v = Get-PSPropertySafe -Object $alertVal -Name 'occurrences'; if ($null -ne $v) { $v } else { 1 })
                            lastNotifiedAt    = Get-PSPropertySafe -Object $alertVal -Name 'lastNotifiedAt'
                            notificationsSent = $($v = Get-PSPropertySafe -Object $alertVal -Name 'notificationsSent'; if ($null -ne $v) { $v } else { 0 })
                            escalated         = $($v = Get-PSPropertySafe -Object $alertVal -Name 'escalated'; if ($null -ne $v) { $v } else { $false })
                        }
                    }
                }

                # Restore alertHistory
                $rawHistory = Get-PSPropertySafe -Object $raw -Name 'alertHistory'
                if ($null -ne $rawHistory) {
                    $state.alertHistory = @($rawHistory)
                }

                # Restore peaks
                $rawPeaks = Get-PSPropertySafe -Object $raw -Name 'peaks'
                if ($null -ne $rawPeaks) {
                    foreach ($prop in ($rawPeaks | Get-Member -MemberType NoteProperty -ErrorAction SilentlyContinue)) {
                        $peakKey = $prop.Name
                        $peakVal = $rawPeaks.$peakKey
                        $state.peaks[$peakKey] = [ordered]@{
                            value     = Get-PSPropertySafe -Object $peakVal -Name 'value'
                            timestamp = Get-PSPropertySafe -Object $peakVal -Name 'timestamp'
                        }
                    }
                }

                # Restore serviceBaseline -- without this every new process
                # re-baselines services to their CURRENT state, so an unexpected
                # stop is never detected across scheduled runs.
                if ($null -ne (Get-PSPropertySafe -Object $raw -Name 'serviceBaseline')) {
                    foreach ($prop in ($raw.serviceBaseline | Get-Member -MemberType NoteProperty -ErrorAction SilentlyContinue)) {
                        $svcKey = $prop.Name
                        $svcVal = $raw.serviceBaseline.$svcKey
                        $state.serviceBaseline[$svcKey] = [ordered]@{
                            expectedState  = Get-PSPropertySafe -Object $svcVal -Name 'expectedState'
                            baselinedAt    = Get-PSPropertySafe -Object $svcVal -Name 'baselinedAt'
                            stateChangedAt = (Get-PSPropertySafe -Object $svcVal -Name 'stateChangedAt')
                            previousState  = (Get-PSPropertySafe -Object $svcVal -Name 'previousState')
                            notes          = (Get-PSPropertySafe -Object $svcVal -Name 'notes')
                        }
                    }
                }

                # Restore peerStatus (farm peer down-grace tracking)
                if ($null -ne (Get-PSPropertySafe -Object $raw -Name 'peerStatus')) {
                    foreach ($prop in ($raw.peerStatus | Get-Member -MemberType NoteProperty -ErrorAction SilentlyContinue)) {
                        $peerKey = $prop.Name
                        $peerVal = $raw.peerStatus.$peerKey
                        $state.peerStatus[$peerKey] = [ordered]@{
                            firstFailedAt       = (Get-PSPropertySafe -Object $peerVal -Name 'firstFailedAt')
                            lastOkAt            = (Get-PSPropertySafe -Object $peerVal -Name 'lastOkAt')
                            consecutiveFailures = $($cf = Get-PSPropertySafe -Object $peerVal -Name 'consecutiveFailures'; if ($null -ne $cf) { [int]$cf } else { 0 })
                            confirmedDown       = $($cd = Get-PSPropertySafe -Object $peerVal -Name 'confirmedDown'; if ($null -ne $cd) { [bool]$cd } else { $false })
                            lastError           = (Get-PSPropertySafe -Object $peerVal -Name 'lastError')
                        }
                    }
                }

                # Restore serviceRestarts (self-heal per-service daily counters --
                # without this the daily cap resets on every process start).
                if ($null -ne (Get-PSPropertySafe -Object $raw -Name 'serviceRestarts')) {
                    foreach ($prop in ($raw.serviceRestarts | Get-Member -MemberType NoteProperty -ErrorAction SilentlyContinue)) {
                        $rsKey = $prop.Name
                        $rsVal = $raw.serviceRestarts.$rsKey
                        $state.serviceRestarts[$rsKey] = [ordered]@{
                            date            = (Get-PSPropertySafe -Object $rsVal -Name 'date')
                            count           = $($c = Get-PSPropertySafe -Object $rsVal -Name 'count'; if ($null -ne $c) { [int]$c } else { 0 })
                            lastAt          = (Get-PSPropertySafe -Object $rsVal -Name 'lastAt')
                            lastResult      = (Get-PSPropertySafe -Object $rsVal -Name 'lastResult')
                            lastError       = (Get-PSPropertySafe -Object $rsVal -Name 'lastError')
                            capNotifiedDate = (Get-PSPropertySafe -Object $rsVal -Name 'capNotifiedDate')
                            attemptIndex    = $($a = Get-PSPropertySafe -Object $rsVal -Name 'attemptIndex'; if ($null -ne $a) { [int]$a } else { 0 })
                        }
                    }
                }

                Write-Log -Message "Loaded platform state from: $candidate" -Level Debug -Color Gray
                return $state
            }
            catch {
                Write-Log -Message "Failed to parse state file '$candidate' (will use empty state): $($_.Exception.Message)" -Level Warn -Color Yellow
            }
        }
    }
    }
    finally {
        if ($null -ne $importMutex) {
            if ($importMutexAcquired) { try { $importMutex.ReleaseMutex() } catch { } }
            $importMutex.Dispose()
        }
    }

    # No file found or all failed -- return empty skeleton
    return (Get-EmptyState)
}

function Get-PSPropertySafe {
    <#
    .SYNOPSIS
        StrictMode-safe property read from a PSCustomObject: returns $null when
        the property does not exist instead of throwing PropertyNotFoundStrict.
    #>
    [CmdletBinding()]
    param(
        [Parameter()] $Object,
        [Parameter(Mandatory)] [string]$Name
    )

    if ($null -eq $Object) { return $null }
    $prop = $Object.PSObject.Properties.Match($Name)
    if ($prop.Count -gt 0) { return $prop[0].Value }
    return $null
}

function Export-PlatformState {
    <#
    .SYNOPSIS
        Atomic write of platform-state.json. Writes to .tmp then renames.
        Uses a global named mutex for cross-process synchronization.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$State,

        [Parameter()]
        [string]$FilePath
    )

    if ([string]::IsNullOrWhiteSpace($FilePath)) {
        $scriptDir = $PSScriptRoot
        if ([string]::IsNullOrWhiteSpace($scriptDir)) {
            $scriptDir = Split-Path -Parent $MyInvocation.ScriptName
        }
        if ([string]::IsNullOrWhiteSpace($scriptDir)) {
            $scriptDir = $PWD.Path
        }
        $FilePath = Join-Path $scriptDir 'platform-state.json'
    }

    # Update lastModified timestamp
    $State['lastModified'] = (Get-Date).ToUniversalTime().ToString('o')

    $mutex = $null
    try {
        $mutex = [System.Threading.Mutex]::new($false, 'Global\CyberArkPlatformMonitorState')
        $acquired = $mutex.WaitOne(10000)  # 10s timeout
        if (-not $acquired) {
            Write-Log -Message 'Could not acquire state file lock after 10s, skipping state save' -Level Warn -Color Yellow
            return
        }

        # Atomic write: write .tmp then swap. File.Replace is atomic on the same
        # volume; delete+move (the fallback for a not-yet-existing target) would
        # otherwise leave a window where a concurrent reader sees no file.
        $tmpPath = "$FilePath.tmp"
        $json = $State | ConvertTo-Json -Depth 10
        [System.IO.File]::WriteAllText($tmpPath, $json, [System.Text.UTF8Encoding]::new($false))

        if (Test-Path $FilePath) {
            try {
                [System.IO.File]::Replace($tmpPath, $FilePath, $null)
            }
            catch {
                # Replace is not supported on every volume type -- fall back to
                # delete+move. Safe: readers take the same mutex we hold here.
                [System.IO.File]::Delete($FilePath)
                [System.IO.File]::Move($tmpPath, $FilePath)
            }
        }
        else {
            [System.IO.File]::Move($tmpPath, $FilePath)
        }

        Write-Log -Message "Platform state saved to: $FilePath" -Level Debug -Color Gray
    }
    catch {
        Write-Log -Message "Failed to save platform state: $($_.Exception.Message)" -Level Warn -Color Yellow
        # Clean up tmp file if it exists
        $tmpPath = "$FilePath.tmp"
        if (Test-Path $tmpPath) {
            try { Remove-Item $tmpPath -Force -ErrorAction SilentlyContinue } catch {}
        }
    }
    finally {
        if ($null -ne $mutex) {
            try { $mutex.ReleaseMutex() } catch {}
            $mutex.Dispose()
        }
    }
}

#endregion

#region Tier Management

function Get-TierCollectors {
    <#
    .SYNOPSIS
        Returns the list of collector names for the specified tier.
        If tier is 'All', returns all 8 collectors.
    #>
    [CmdletBinding()]
    [OutputType([string[]])]
    param(
        [Parameter(Mandatory)]
        [string]$TierName
    )

    $allCollectors = @('SystemHealth','ServiceStatus','CertificateHealth','ServerCapacity','CPMHealth','PSMHealth','Connectivity','WebDriverHealth','PVWAHealth','LogScan')

    if ($TierName -eq 'All') {
        return $allCollectors
    }

    $tierLower = $TierName.ToLower()
    $tierConfig = $script:Config.tiers

    if ($null -eq $tierConfig) {
        Write-Log -Message "No tiers configuration found, returning all collectors" -Level Warn -Color Yellow
        return $allCollectors
    }

    # Handle both hashtable and PSCustomObject access
    $tierDef = $null
    if ($tierConfig -is [hashtable]) {
        $tierDef = $tierConfig[$tierLower]
    } else {
        $tierDef = $tierConfig.$tierLower
    }

    if ($null -eq $tierDef) {
        Write-Log -Message "Tier '$TierName' not found in configuration, returning all collectors" -Level Warn -Color Yellow
        return $allCollectors
    }

    # Access collectors from tier definition
    $collectors = $null
    if ($tierDef -is [hashtable]) {
        $collectors = $tierDef['collectors']
    } else {
        $collectors = $tierDef.collectors
    }

    if ($null -eq $collectors -or $collectors.Count -eq 0) {
        Write-Log -Message "Tier '$TierName' has no collectors defined, returning all collectors" -Level Warn -Color Yellow
        return $allCollectors
    }

    return @($collectors)
}

function Get-SkipFlagsForTier {
    <#
    .SYNOPSIS
        Sets script-scope $Skip* variables based on which collectors are NOT in the tier's list.
        This makes the existing orchestrator if (-not $SkipSystemHealth) checks tier-aware
        without rewriting them.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$TierName
    )

    $tierCollectors = Get-TierCollectors -TierName $TierName

    # Map collector names to their corresponding Skip parameter variables
    $collectorSkipMap = @{
        'SystemHealth'      = 'SkipSystemHealth'
        'ServiceStatus'     = 'SkipServices'
        'CertificateHealth' = 'SkipCertificates'
        'ServerCapacity'    = 'SkipCapacity'
        'CPMHealth'         = 'SkipCPM'
        'PSMHealth'         = 'SkipPSM'
        'Connectivity'      = 'SkipConnectivity'
        'WebDriverHealth'   = 'SkipWebDrivers'
        'PVWAHealth'        = 'SkipPVWA'
        'LogScan'           = 'SkipLogScan'
    }

    foreach ($collector in $collectorSkipMap.Keys) {
        $skipVar = $collectorSkipMap[$collector]
        if ($tierCollectors -notcontains $collector) {
            # Not in this tier -- set the skip flag
            Set-Variable -Name $skipVar -Value $true -Scope Script
        }
        elseif ($script:UserSkipFlags -notcontains $skipVar) {
            # In this tier and NOT explicitly skipped by the user on the CLI --
            # clear the flag. Without this reset a previous tier's skips latch,
            # and in -Monitor mode every tier after the first collects nothing.
            Set-Variable -Name $skipVar -Value $false -Scope Script
        }
        # Flags the user explicitly set via CLI parameters are never reset.
    }
}

function Test-TierDue {
    <#
    .SYNOPSIS
        Returns $true if the tier's interval has elapsed since the last collection.
    .PARAMETER TierName
        The tier to check: Hot, Warm, or Cool.
    .PARAMETER LastCollectionTimestamps
        The state.lastCollection ordered hashtable with ISO 8601 timestamps.
    #>
    [CmdletBinding()]
    [OutputType([bool])]
    param(
        [Parameter(Mandatory)]
        [string]$TierName,

        [Parameter()]
        [hashtable]$LastCollectionTimestamps
    )

    $tierLower = $TierName.ToLower()

    # If no timestamp exists, tier is due
    if ($null -eq $LastCollectionTimestamps -or $null -eq $LastCollectionTimestamps[$tierLower]) {
        return $true
    }

    $lastRunStr = $LastCollectionTimestamps[$tierLower]
    try {
        $lastRun = [datetime]::Parse($lastRunStr).ToUniversalTime()
    }
    catch {
        # Unparseable timestamp -- treat as due
        return $true
    }

    # Get tier interval from config
    $tierConfig = $script:Config.tiers
    $tierDef = $null
    if ($tierConfig -is [hashtable]) {
        $tierDef = $tierConfig[$tierLower]
    } else {
        $tierDef = $tierConfig.$tierLower
    }

    if ($null -eq $tierDef) {
        return $true
    }

    $intervalMinutes = 0
    if ($tierDef -is [hashtable]) {
        $intervalMinutes = $tierDef['intervalMinutes']
    } else {
        $intervalMinutes = $tierDef.intervalMinutes
    }

    if ($null -eq $intervalMinutes -or $intervalMinutes -le 0) {
        return $true
    }

    $elapsed = ((Get-Date).ToUniversalTime() - $lastRun).TotalMinutes
    return ($elapsed -ge $intervalMinutes)
}

#endregion

#region Structured Logger

$script:LogFile        = $null
$script:LogLevelInt    = 1   # Info

function Get-LogLevelInt {
    param([string]$Level)
    switch ($Level) {
        'Debug' { return 0 }
        'Info'  { return 1 }
        'Warn'  { return 2 }
        'Error' { return 3 }
        default { return 1 }
    }
}

function Initialize-Logger {
    <#
    .SYNOPSIS
        Create log directory and open log file with header.
    #>
    [CmdletBinding()]
    param(
        [string]$LogDir   = '.\Logs',
        [string]$Level    = 'Info',
        [bool]$ConsoleOut = $true,
        [int]$MaxSizeMB   = 10
    )

    $script:LogLevel    = $Level
    $script:LogLevelInt = Get-LogLevelInt $Level
    $script:LogConsoleOut = $ConsoleOut

    # Resolve log directory
    if ([string]::IsNullOrWhiteSpace($LogDir) -or $LogDir -eq '.\Logs') {
        $scriptDir = $PSScriptRoot
        if ([string]::IsNullOrWhiteSpace($scriptDir)) { $scriptDir = $PWD.Path }
        $LogDir = Join-Path $scriptDir 'Logs'
    }

    if (-not (Test-Path $LogDir)) {
        try { New-Item -Path $LogDir -ItemType Directory -Force | Out-Null } catch { }
    }

    # Daily log file: ONE file per calendar day, appended across runs (not a new
    # file every run). A new day naturally rolls to a new file name.
    $today = Get-Date -Format 'yyyy-MM-dd'
    $logFileName = "CA-PlatformMonitor-$today.log"
    $script:LogFile = Join-Path $LogDir $logFileName

    # Size rollover: if today's file already exceeds MaxSizeMB, archive it to a
    # timestamped name, zip it, and start a fresh file for the rest of the day.
    try {
        if (Test-Path $script:LogFile) {
            $cur = Get-Item $script:LogFile
            if (($cur.Length / 1MB) -ge $MaxSizeMB) {
                $archived = Join-Path $LogDir "CA-PlatformMonitor-${today}_$(Get-Date -Format 'HHmmss').log"
                Rename-Item $cur.FullName $archived -ErrorAction SilentlyContinue
                try {
                    Compress-Archive -Path $archived -DestinationPath "$archived.zip" -Force -ErrorAction Stop
                    Remove-Item $archived -Force -ErrorAction SilentlyContinue
                } catch { }
            }
        }
    }
    catch { }

    # Housekeeping: zip prior-day / already-rolled .log files (one .zip each) so
    # the folder keeps compressed history and stays small.
    try {
        Get-ChildItem -Path $LogDir -Filter 'CA-PlatformMonitor-*.log' -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -ne $logFileName } |
            ForEach-Object {
                try {
                    Compress-Archive -Path $_.FullName -DestinationPath ($_.FullName + '.zip') -Force -ErrorAction Stop
                    Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue
                } catch { }
            }
    }
    catch { }

    # Daemon-style: no banner block. One structured start line per run -- every
    # field an operator needs (host, mode, version, correlation) is already on
    # every line, so runs are grep-able by correlation id, not visual dividers.
    Write-Log -Message "Monitor run started: version=$($script:ToolVersion) mode=$($script:OperatingMode) tier=$($script:CurrentTier) pid=$PID" -Level Info -Color Cyan -LogOnly
}

function Write-Log {
    <#
    .SYNOPSIS
        Write a structured log entry to file and/or console.
    .DESCRIPTION
        File format (fixed field positions for ingestion; logs from many hosts
        can be concatenated and parsed by position or grepped by any token):

          <UTC ts>Z [<host>] [<LEVEL>] [<status>] [<correlationId>] [<component>] <message>

        - LEVEL:  DEBUG | INFO | WARN | ERROR
        - status: finding badge (OK/WARN/FAIL/INFO) or '-' for plain entries
        - correlationId: the run's GUID -- findstr it to isolate one run,
          and join against the same correlationId in the metrics JSONL.
    #>
    [CmdletBinding()]
    param(
        [Parameter()]
        [string]$Message = '',
        [Parameter()]
        [string]$Color   = 'White',
        [Parameter()]
        [ValidateSet('Debug','Info','Warn','Error')]
        [string]$Level   = 'Info',
        [Parameter()]
        [string]$Component = '',
        [Parameter()]
        [string]$Status = '-',
        [Parameter()]
        [switch]$ScreenOnly,
        [Parameter()]
        [switch]$LogOnly
    )

    $msgLevel = Get-LogLevelInt $Level
    if ($msgLevel -lt $script:LogLevelInt) { return }

    $ts     = (Get-Date).ToUniversalTime().ToString('yyyy-MM-dd HH:mm:ss')
    $comp   = if ($Component) { $Component } else { '-' }
    $badge  = if ($Status) { $Status } else { '-' }
    $line   = "${ts}Z [$($env:COMPUTERNAME)] [$($Level.ToUpper())] [$badge] [$($script:CorrelationID)] [$comp] $Message"

    if (-not $ScreenOnly -and $script:LogFile) {
        try { Add-Content -Path $script:LogFile -Value $line } catch { }
    }

    if (-not $LogOnly -and $script:LogConsoleOut) {
        # Console keeps the short human form; the badge is shown for findings.
        $consoleMsg = if ($badge -ne '-') { "  [$badge]".PadRight(9) + $Message } else { $Message }
        Write-Host $consoleMsg -ForegroundColor $Color
    }
}

function Write-Finding {
    <#
    .SYNOPSIS
        Write a structured finding line. The badge (OK/WARN/FAIL/INFO) lands in
        the fixed status field of the log line -- directly after [LEVEL] -- so
        `findstr "[FAIL]"` across merged multi-host logs is reliable.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateSet('OK','WARN','FAIL','INFO')]
        [string]$Status,
        [Parameter(Mandatory)]
        [string]$Message,
        [string]$Component = ''
    )

    $color = switch ($Status) {
        'OK'   { 'Green' }
        'WARN' { 'Yellow' }
        'FAIL' { 'Red' }
        'INFO' { 'Cyan' }
    }

    Write-Log -Message $Message -Color $color -Level 'Info' -Status $Status -Component $Component
}

function Write-Section {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Title)
    Write-Log -Message "===== $Title =====" -Color Cyan -Level Info
}

#endregion

#region JSONL Storage Engine

function Get-MetricsFilePath {
    <#
    .SYNOPSIS
        Returns the path to today's JSONL metrics file.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$MetricsDir
    )

    $dateStr = Get-Date -Format 'yyyy-MM-dd'
    return Join-Path $MetricsDir "platform-metrics-$dateStr.jsonl"
}

function Write-MetricRecord {
    <#
    .SYNOPSIS
        Appends a single metric record to the JSONL file.
        Uses StreamWriter (UTF-8 no-BOM, append). Each record is one compressed JSON line.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$MetricsDir,
        [Parameter(Mandatory)]
        [object]$Record
    )

    if ([string]::IsNullOrWhiteSpace($MetricsDir)) { return }

    try {
        if (-not (Test-Path $MetricsDir)) {
            New-Item -Path $MetricsDir -ItemType Directory -Force | Out-Null
        }

        $filePath = Get-MetricsFilePath -MetricsDir $MetricsDir
        $json     = $Record | ConvertTo-Json -Depth 6 -Compress
        $encoding = [System.Text.UTF8Encoding]::new($false)  # no BOM
        $writer   = [System.IO.StreamWriter]::new($filePath, $true, $encoding)  # append=true
        try {
            $writer.WriteLine($json)
        }
        finally {
            $writer.Dispose()
        }
    }
    catch {
        Write-Log -Message "Failed to write metric record: $($_.Exception.Message)" -Level Warn -Color Yellow
    }
}

function Write-SummaryOutputs {
    <#
    .SYNOPSIS
        Writes the two modstat/Nagios-style outputs from a flat summary record:
        - platform-status.json  : CURRENT state snapshot, atomically overwritten
          every run (Apache mod_status / Nagios status.dat analog). One small
          fixed-schema file any poller can read for "state right now".
        - platform-summary.jsonl: ONE append-only trend file containing ONLY
          summary rows -- identical schema on every line regardless of mode or
          tier. Point a trend parser here; no date globbing, no type filtering.
        Never throws.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$MetricsDir,
        [Parameter(Mandatory)]
        $Summary
    )

    if ([string]::IsNullOrWhiteSpace($MetricsDir)) { return }

    try {
        if (-not (Test-Path $MetricsDir)) {
            New-Item -Path $MetricsDir -ItemType Directory -Force | Out-Null
        }
        $enc = [System.Text.UTF8Encoding]::new($false)

        # 1) Append-only trend file (one flat line per run, all modes/tiers)
        $trendPath = Join-Path $MetricsDir 'platform-summary.jsonl'
        $line = $Summary | ConvertTo-Json -Depth 4 -Compress
        $writer = [System.IO.StreamWriter]::new($trendPath, $true, $enc)
        try { $writer.WriteLine($line) } finally { $writer.Dispose() }

        # 2) Current-status snapshot -- atomic overwrite so readers never see a
        #    partial file (Replace where the volume supports it, else swap).
        $statusPath = Join-Path $MetricsDir 'platform-status.json'
        $tmpPath = "$statusPath.tmp"
        [System.IO.File]::WriteAllText($tmpPath, ($Summary | ConvertTo-Json -Depth 4), $enc)
        if (Test-Path $statusPath) {
            try { [System.IO.File]::Replace($tmpPath, $statusPath, $null) }
            catch {
                [System.IO.File]::Delete($statusPath)
                [System.IO.File]::Move($tmpPath, $statusPath)
            }
        }
        else {
            [System.IO.File]::Move($tmpPath, $statusPath)
        }
    }
    catch {
        Write-Log -Message "Summary output write failed: $($_.Exception.Message)" -Level Warn -Color Yellow -Component 'Metrics'
    }
}

function Read-MetricRecords {
    <#
    .SYNOPSIS
        Reads JSONL file(s) in MetricsDir, filters by recordType, returns array.
        Uses StreamReader for memory-efficient reading.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$MetricsDir,
        [Parameter()]
        [string]$RecordType = '',
        [Parameter()]
        [int]$LookbackDays = 30
    )

    $results = [System.Collections.ArrayList]::new()

    if (-not (Test-Path $MetricsDir)) { return @() }

    $cutoff = (Get-Date).AddDays(-$LookbackDays).Date

    try {
        $files = Get-ChildItem -Path $MetricsDir -Filter 'platform-metrics-*.jsonl' -ErrorAction SilentlyContinue |
            Where-Object { $_.LastWriteTime.Date -ge $cutoff } |
            Sort-Object Name

        foreach ($file in $files) {
            $reader = [System.IO.StreamReader]::new($file.FullName, [System.Text.Encoding]::UTF8)
            try {
                while (-not $reader.EndOfStream) {
                    $line = $reader.ReadLine()
                    if ([string]::IsNullOrWhiteSpace($line)) { continue }
                    try {
                        $record = $line | ConvertFrom-Json
                        if ([string]::IsNullOrEmpty($RecordType) -or $record.recordType -eq $RecordType) {
                            $null = $results.Add($record)
                        }
                    }
                    catch { }
                }
            }
            finally {
                $reader.Dispose()
            }
        }
    }
    catch {
        Write-Log -Message "Error reading metric records: $($_.Exception.Message)" -Level Warn -Color Yellow
    }

    return @($results)
}

function Invoke-MetricsRotation {
    <#
    .SYNOPSIS
        Deletes JSONL files older than retention days from the metrics directory.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$MetricsDir,
        [Parameter()]
        [int]$RetentionDays = 30
    )

    if (-not (Test-Path $MetricsDir)) { return }

    $cutoff = (Get-Date).AddDays(-$RetentionDays)
    try {
        $oldFiles = Get-ChildItem -Path $MetricsDir -Filter 'platform-metrics-*.jsonl' -ErrorAction SilentlyContinue |
            Where-Object { $_.LastWriteTime -lt $cutoff }
        foreach ($f in $oldFiles) {
            try {
                Remove-Item $f.FullName -Force -ErrorAction SilentlyContinue
                Write-Log -Message "Rotated old metrics file: $($f.Name)" -Level Debug -Color Gray
            }
            catch { }
        }
    }
    catch {
        Write-Log -Message "Error during metrics rotation: $($_.Exception.Message)" -Level Warn -Color Yellow
    }

    # Trim aged rows from the single-file trend log (platform-summary.jsonl) so
    # it honors the same retention as the daily files without ever being deleted.
    try {
        $trendPath = Join-Path $MetricsDir 'platform-summary.jsonl'
        if (Test-Path $trendPath) {
            $cutoffUtc = (Get-Date).ToUniversalTime().AddDays(-$RetentionDays)
            $keep    = [System.Collections.Generic.List[string]]::new()
            $dropped = 0
            foreach ($ln in [System.IO.File]::ReadAllLines($trendPath)) {
                if ([string]::IsNullOrWhiteSpace($ln)) { continue }
                $ts = $null
                # Cheap regex extract beats a full JSON parse per line here.
                if ($ln -match '"timestamp":"([^"]+)"') {
                    try { $ts = [datetime]::Parse($Matches[1]).ToUniversalTime() } catch { }
                }
                if ($null -eq $ts -or $ts -ge $cutoffUtc) { $keep.Add($ln) } else { $dropped++ }
            }
            if ($dropped -gt 0) {
                $tmpPath = "$trendPath.tmp"
                [System.IO.File]::WriteAllLines($tmpPath, $keep, [System.Text.UTF8Encoding]::new($false))
                try { [System.IO.File]::Replace($tmpPath, $trendPath, $null) }
                catch {
                    [System.IO.File]::Delete($trendPath)
                    [System.IO.File]::Move($tmpPath, $trendPath)
                }
                Write-Log -Message "Trimmed $dropped aged row(s) from platform-summary.jsonl" -Level Debug -Color Gray
            }
        }
    }
    catch {
        Write-Log -Message "Error trimming platform-summary.jsonl: $($_.Exception.Message)" -Level Warn -Color Yellow
    }
}

#endregion

#region Threshold / Alert Engine

function Test-Threshold {
    <#
    .SYNOPSIS
        Evaluate a value against warning/critical thresholds.
        Returns $null if OK, or an Alert PSCustomObject if threshold breached.
    .PARAMETER Value
        The numeric value to evaluate.
    .PARAMETER Warning
        Warning threshold level.
    .PARAMETER Critical
        Critical threshold level.
    .PARAMETER HigherIsBad
        When $true (default), higher values are worse (CPU%, disk%).
        When $false, lower values are worse (available memory, cert days remaining).
    .PARAMETER Source
        Name of the metric source (for alert message).
    .PARAMETER MetricName
        Descriptive name of the metric.
    .PARAMETER Unit
        Unit label (%, GB, days, etc.).
    #>
    [CmdletBinding()]
    param(
        [Parameter()]
        $Value,
        [Parameter(Mandatory)]
        [double]$Warning,
        [Parameter(Mandatory)]
        [double]$Critical,
        [bool]$HigherIsBad    = $true,
        [string]$Source       = '',
        [string]$MetricName   = 'Metric',
        [string]$Unit         = ''
    )

    # Null / non-numeric value = nothing to evaluate. A typed [double] parameter
    # would throw a binding error at the CALL site and abort the caller's whole
    # try block, silently skipping the other threshold checks in that collector.
    if ($null -eq $Value) { return $null }
    try { $Value = [double]$Value } catch { return $null }

    $unitLabel = if ($Unit) { " $Unit" } else { '' }
    $severity  = $null

    if ($HigherIsBad) {
        if ($Value -ge $Critical) { $severity = 'Critical' }
        elseif ($Value -ge $Warning) { $severity = 'Warning' }
    }
    else {
        if ($Value -le $Critical) { $severity = 'Critical' }
        elseif ($Value -le $Warning) { $severity = 'Warning' }
    }

    if ($null -eq $severity) { return $null }

    $breached = if ($severity -eq 'Critical') { $Critical } else { $Warning }
    return New-Alert -Severity $severity -Source $Source -MetricName $MetricName `
        -Message "$MetricName is $Value$unitLabel ($severity threshold: $breached$unitLabel)" `
        -Value $Value -Threshold $breached
}

function New-Alert {
    <#
    .SYNOPSIS
        Creates an Alert record PSCustomObject.
    #>
    [CmdletBinding()]
    param(
        [ValidateSet('Warning','Critical')]
        [string]$Severity   = 'Warning',
        [string]$Source     = '',
        [string]$MetricName = '',
        [string]$Message    = '',
        [double]$Value      = 0,
        [double]$Threshold  = 0
    )

    return [PSCustomObject]@{
        recordType  = 'Alert'
        severity    = $Severity
        source      = $Source
        metricName  = $MetricName
        message     = $Message
        value       = $Value
        threshold   = $Threshold
        timestamp   = (Get-Date).ToUniversalTime().ToString('o')
    }
}

function Get-OverallHealthStatus {
    <#
    .SYNOPSIS
        Returns worst severity across all alerts: OK / Warning / Critical.
    #>
    [CmdletBinding()]
    param(
        [Parameter()]
        [object[]]$Alerts
    )

    if (-not $Alerts -or $Alerts.Count -eq 0) { return 'OK' }

    $hasCritical = $Alerts | Where-Object { $_.severity -eq 'Critical' }
    if ($hasCritical) { return 'Critical' }

    $hasWarning = $Alerts | Where-Object { $_.severity -eq 'Warning' }
    if ($hasWarning) { return 'Warning' }

    return 'OK'
}

#endregion

#region Requirements Evaluation Engine

function Resolve-MetricValue {
    <#
    .SYNOPSIS
        Given a collector name, metricPath string, optional filter, and collection results
        hashtable, navigate to the metric value. Supports dot notation, bracket filters,
        and computed paths.
    .DESCRIPTION
        Path types:
        - Dot notation: "CPU.Average" -> $results.SystemHealth.CPU.Average
        - Bracket filter: "Services.Status" with filter {field='ServiceName';value='PrivateArk Server'}
          -> find item in Services array where ServiceName matches, return .Status
        - Computed paths: "MinDaysToExpiry" -> min of Certificates[].DaysUntilExpiry
        - Connectivity filter: "Reachable" with filter {field='Port';value=1858}
          -> find connectivity result matching port, return .Reachable
    .PARAMETER CollectorName
        The collector key in the results hashtable (e.g., SystemHealth, ServiceStatus).
    .PARAMETER MetricPath
        Dot-separated path to the metric value within the collector's result object.
    .PARAMETER Filter
        Optional filter object with 'field' and 'value' properties for array element selection.
    .PARAMETER CollectionResults
        The full collection results hashtable from Invoke-MetricsCollection.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$CollectorName,

        [Parameter(Mandatory)]
        [string]$MetricPath,

        [Parameter()]
        $Filter,

        [Parameter(Mandatory)]
        [hashtable]$CollectionResults
    )

    # Get the collector data
    $collectorData = $CollectionResults[$CollectorName]
    if ($null -eq $collectorData) {
        return $null
    }

    # Handle computed paths
    if ($MetricPath -eq 'MinDaysToExpiry' -and $CollectorName -eq 'CertificateHealth') {
        # Compute minimum DaysUntilExpiry from Certificates array
        $certs = $null
        if ($collectorData -is [hashtable]) {
            $certs = $collectorData['Certificates']
        } else {
            $certs = $collectorData.Certificates
        }
        if ($null -eq $certs -or @($certs).Count -eq 0) {
            return $null
        }
        $minDays = $null
        foreach ($cert in $certs) {
            $days = $null
            if ($cert -is [hashtable]) {
                $days = $cert['DaysUntilExpiry']
            } else {
                $days = $cert.DaysUntilExpiry
            }
            if ($null -ne $days) {
                if ($null -eq $minDays -or $days -lt $minDays) {
                    $minDays = $days
                }
            }
        }
        return $minDays
    }

    # Handle Connectivity with filter (array of connection results)
    if ($CollectorName -eq 'Connectivity' -and $null -ne $Filter) {
        $filterField = $null
        $filterValue = $null
        if ($Filter -is [hashtable]) {
            $filterField = $Filter['field']
            $filterValue = $Filter['value']
        } else {
            $filterField = $Filter.field
            $filterValue = $Filter.value
        }

        # Connectivity results are an array at the top level
        $items = @($collectorData)
        foreach ($item in $items) {
            $fieldVal = $null
            if ($item -is [hashtable]) {
                $fieldVal = $item[$filterField]
            } else {
                $fieldVal = $item.$filterField
            }
            # Compare with string coercion for flexibility
            if ("$fieldVal" -eq "$filterValue") {
                # Navigate the remaining metricPath on this item
                return (Resolve-PropertyPath -Object $item -Path $MetricPath)
            }
        }
        return $null
    }

    # Handle ServiceStatus with filter (find service by name in Services array)
    if ($CollectorName -eq 'ServiceStatus' -and $null -ne $Filter) {
        $filterField = $null
        $filterValue = $null
        if ($Filter -is [hashtable]) {
            $filterField = $Filter['field']
            $filterValue = $Filter['value']
        } else {
            $filterField = $Filter.field
            $filterValue = $Filter.value
        }

        # Get the Services array from the collector data
        $services = $null
        if ($collectorData -is [hashtable]) {
            $services = $collectorData['Services']
        } else {
            $services = $collectorData.Services
        }

        if ($null -ne $services) {
            foreach ($svc in $services) {
                $fieldVal = $null
                if ($svc -is [hashtable]) {
                    $fieldVal = $svc[$filterField]
                } else {
                    $fieldVal = $svc.$filterField
                }
                if ("$fieldVal" -eq "$filterValue") {
                    # Get the property indicated by the last segment of metricPath
                    # metricPath is "Services.Status" -- we want .Status from the matched item
                    $segments = $MetricPath -split '\.'
                    $lastSegment = $segments[$segments.Count - 1]
                    return (Resolve-PropertyPath -Object $svc -Path $lastSegment)
                }
            }
        }
        return $null
    }

    # Standard dot-path navigation on collector data
    return (Resolve-PropertyPath -Object $collectorData -Path $MetricPath)
}

function Resolve-PropertyPath {
    <#
    .SYNOPSIS
        Navigate an object using dot-separated path segments.
        Supports both hashtable and PSCustomObject access.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        $Object,

        [Parameter(Mandatory)]
        [string]$Path
    )

    $current = $Object
    $segments = $Path -split '\.'

    foreach ($segment in $segments) {
        if ($null -eq $current) {
            return $null
        }

        if ($current -is [hashtable]) {
            if ($current.ContainsKey($segment)) {
                $current = $current[$segment]
            } else {
                return $null
            }
        } else {
            # PSCustomObject / regular object -- use property access
            $prop = $current.PSObject.Properties.Match($segment)
            if ($prop.Count -gt 0) {
                $current = $prop[0].Value
            } else {
                return $null
            }
        }
    }

    return $current
}

function Test-RequirementThreshold {
    <#
    .SYNOPSIS
        Evaluate a metric value against a requirement's thresholds.
        Returns a PSCustomObject with evaluation status.
    .PARAMETER RequirementId
        The requirement identifier (e.g., REQ-001).
    .PARAMETER Value
        The current metric value.
    .PARAMETER Direction
        Threshold direction: HigherIsBad, LowerIsBad, or Equals.
    .PARAMETER WarningThreshold
        Warning threshold value (numeric for HigherIsBad/LowerIsBad, unused for Equals).
    .PARAMETER CriticalThreshold
        Critical threshold value (numeric for HigherIsBad/LowerIsBad, string for Equals).
    .PARAMETER MetricPath
        The metric path string for identification purposes.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)]
        [string]$RequirementId,

        [Parameter()]
        $Value,

        [Parameter(Mandatory)]
        [ValidateSet('HigherIsBad','LowerIsBad','Equals')]
        [string]$Direction,

        [Parameter()]
        $WarningThreshold,

        [Parameter()]
        $CriticalThreshold,

        [Parameter()]
        [string]$MetricPath = ''
    )

    # If value is null, we cannot evaluate
    if ($null -eq $Value) {
        return [PSCustomObject]@{
            RequirementId = $RequirementId
            Status        = 'Unknown'
            CurrentValue  = $null
            Threshold     = $CriticalThreshold
            ConfiguredThreshold = $CriticalThreshold
            Direction     = $Direction
            MetricPath    = $MetricPath
        }
    }

    $status = 'OK'
    $threshold = $null

    switch ($Direction) {
        'HigherIsBad' {
            $numValue = [double]$Value
            if ($null -ne $CriticalThreshold -and $numValue -ge [double]$CriticalThreshold) {
                $status = 'Critical'
                $threshold = $CriticalThreshold
            }
            elseif ($null -ne $WarningThreshold -and $numValue -ge [double]$WarningThreshold) {
                $status = 'Warning'
                $threshold = $WarningThreshold
            }
        }
        'LowerIsBad' {
            $numValue = [double]$Value
            if ($null -ne $CriticalThreshold -and $numValue -le [double]$CriticalThreshold) {
                $status = 'Critical'
                $threshold = $CriticalThreshold
            }
            elseif ($null -ne $WarningThreshold -and $numValue -le [double]$WarningThreshold) {
                $status = 'Warning'
                $threshold = $WarningThreshold
            }
        }
        'Equals' {
            # Value must equal criticalThreshold string. If not, severity = Critical.
            if ("$Value" -ne "$CriticalThreshold") {
                $status = 'Critical'
                $threshold = $CriticalThreshold
            }
        }
    }

    return [PSCustomObject]@{
        RequirementId = $RequirementId
        Status        = $status
        CurrentValue  = $Value
        Threshold     = $threshold
        ConfiguredThreshold = $CriticalThreshold
        Direction     = $Direction
        MetricPath    = $MetricPath
    }
}

function Invoke-RequirementsEvaluation {
    <#
    .SYNOPSIS
        Evaluate all enabled requirements matching the current tier against collection results.
        Returns an array of evaluation result objects.
    .PARAMETER Requirements
        Array of requirement objects (from Import-MonitoringRequirements).
    .PARAMETER CollectionResults
        The collection results hashtable from Invoke-MetricsCollection.
    .PARAMETER TierName
        The current tier name to filter requirements. 'All' evaluates all requirements.
    #>
    [CmdletBinding()]
    [OutputType([array])]
    param(
        [Parameter(Mandatory)]
        [array]$Requirements,

        [Parameter(Mandatory)]
        [hashtable]$CollectionResults,

        [Parameter()]
        [string]$TierName = 'All'
    )

    $evaluations = [System.Collections.ArrayList]::new()

    foreach ($req in $Requirements) {
        # Skip disabled requirements
        $enabled = $true
        if ($req -is [hashtable]) {
            $enabled = $req['enabled']
        } else {
            $enabled = $req.enabled
        }
        if ($enabled -eq $false) { continue }

        # Filter by tier if a specific tier is active
        if ($TierName -ne 'All') {
            $reqTier = $null
            if ($req -is [hashtable]) {
                $reqTier = $req['tier']
            } else {
                $reqTier = $req.tier
            }
            if ($null -ne $reqTier -and $reqTier -ne $TierName) { continue }
        }

        # Extract requirement properties (support both hashtable and PSCustomObject)
        $reqId         = if ($req -is [hashtable]) { $req['id'] } else { $req.id }
        $collector     = if ($req -is [hashtable]) { $req['collector'] } else { $req.collector }
        $metricPath    = if ($req -is [hashtable]) { $req['metricPath'] } else { $req.metricPath }
        $filter        = if ($req -is [hashtable]) { $req['filter'] } else { $req.filter }
        $direction     = if ($req -is [hashtable]) { $req['direction'] } else { $req.direction }
        $warnThreshold = if ($req -is [hashtable]) { $req['warningThreshold'] } else { $req.warningThreshold }
        $critThreshold = if ($req -is [hashtable]) { $req['criticalThreshold'] } else { $req.criticalThreshold }

        # Resolve the metric value
        $value = Resolve-MetricValue -CollectorName $collector -MetricPath $metricPath `
            -Filter $filter -CollectionResults $CollectionResults

        # Evaluate against thresholds
        $result = Test-RequirementThreshold -RequirementId $reqId -Value $value `
            -Direction $direction -WarningThreshold $warnThreshold `
            -CriticalThreshold $critThreshold -MetricPath $metricPath

        $null = $evaluations.Add($result)
    }

    return @($evaluations)
}

#endregion

#region Alert State Machine

function Get-AlertKey {
    <#
    .SYNOPSIS
        Generate the dedup key for an alert: {requirementId}::{metricPath}
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory)]
        [string]$RequirementId,

        [Parameter(Mandatory)]
        [string]$MetricPath
    )

    return "${RequirementId}::${MetricPath}"
}

function Move-AlertToHistory {
    <#
    .SYNOPSIS
        Move an alert from activeAlerts to alertHistory.
        Calculates duration and caps history at 500 entries.
    .PARAMETER State
        The platform state hashtable (modified in-place).
    .PARAMETER AlertKey
        The key in state.activeAlerts to move.
    .PARAMETER RecoveryValue
        The current metric value at recovery time.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$State,

        [Parameter(Mandatory)]
        [string]$AlertKey,

        [Parameter()]
        $RecoveryValue = $null
    )

    if (-not $State.activeAlerts.Contains($AlertKey)) {
        return
    }

    $alert = $State.activeAlerts[$AlertKey]
    $now = (Get-Date).ToUniversalTime()

    # Calculate duration
    $durationMinutes = 0
    if ($null -ne $alert['firstSeen']) {
        try {
            $firstSeen = [datetime]::Parse($alert['firstSeen']).ToUniversalTime()
            $durationMinutes = [math]::Round(($now - $firstSeen).TotalMinutes, 1)
        }
        catch {}
    }

    # Create history entry
    $historyEntry = [ordered]@{
        requirementId     = $alert['requirementId']
        alertKey          = $AlertKey
        severity          = $alert['severity']
        firstSeen         = $alert['firstSeen']
        lastSeen          = $alert['lastSeen']
        resolvedAt        = $now.ToString('o')
        durationMinutes   = $durationMinutes
        peakValue         = $alert['lastValue']
        occurrences       = $alert['occurrences']
        notificationsSent = $alert['notificationsSent']
        recoveryValue     = $RecoveryValue
    }

    # Add to history
    $history = [System.Collections.ArrayList]::new()
    if ($null -ne $State.alertHistory) {
        foreach ($item in $State.alertHistory) {
            $null = $history.Add($item)
        }
    }
    $null = $history.Add($historyEntry)

    # Cap at 500 entries (FIFO -- remove oldest)
    while ($history.Count -gt 500) {
        $history.RemoveAt(0)
    }

    $State['alertHistory'] = @($history)

    # Remove from active alerts
    $State.activeAlerts.Remove($AlertKey)
}

function Update-AlertState {
    <#
    .SYNOPSIS
        Process evaluation results through the alert state machine.
        For each evaluation with Status != OK: create or update active alerts.
        For active alerts now OK: move to history (recovery).
        Returns a list of notification actions.
    .PARAMETER State
        The platform state hashtable (modified in-place).
    .PARAMETER Evaluations
        Array of evaluation results from Invoke-RequirementsEvaluation.
    .PARAMETER Requirements
        Array of requirement objects for metadata lookup.
    .PARAMETER AlertingConfig
        The alerting configuration hashtable from config.
    #>
    [CmdletBinding()]
    [OutputType([array])]
    param(
        [Parameter(Mandatory)]
        [hashtable]$State,

        [Parameter(Mandatory)]
        [array]$Evaluations,

        [Parameter()]
        [array]$Requirements = @(),

        [Parameter()]
        $AlertingConfig = $null
    )

    $now = (Get-Date).ToUniversalTime()
    $nowStr = $now.ToString('o')
    $notifications = [System.Collections.ArrayList]::new()

    # Get cooldown and escalation settings
    $cooldownMinutes = 30
    $escalateAfterMinutes = 60
    $maxNotifications = 10
    if ($null -ne $AlertingConfig) {
        $rules = $null
        if ($AlertingConfig -is [hashtable]) {
            $rules = $AlertingConfig['rules']
        } else {
            $rules = $AlertingConfig.rules
        }
        if ($null -ne $rules) {
            if ($rules -is [hashtable]) {
                if ($null -ne $rules['cooldownMinutes']) { $cooldownMinutes = $rules['cooldownMinutes'] }
                if ($null -ne $rules['escalateAfterMinutes']) { $escalateAfterMinutes = $rules['escalateAfterMinutes'] }
                if ($null -ne $rules['maxNotificationsPerAlert']) { $maxNotifications = $rules['maxNotificationsPerAlert'] }
            } else {
                if ($null -ne $rules.cooldownMinutes) { $cooldownMinutes = $rules.cooldownMinutes }
                if ($null -ne $rules.escalateAfterMinutes) { $escalateAfterMinutes = $rules.escalateAfterMinutes }
                if ($null -ne $rules.maxNotificationsPerAlert) { $maxNotifications = $rules.maxNotificationsPerAlert }
            }
        }
    }

    # Track which alert keys were evaluated (to detect recoveries)
    $evaluatedKeys = @{}

    foreach ($eval in $Evaluations) {
        if ($null -eq $eval) { continue }

        $alertKey = Get-AlertKey -RequirementId $eval.RequirementId -MetricPath $eval.MetricPath
        $evaluatedKeys[$alertKey] = $true

        if ($eval.Status -eq 'Unknown') {
            # Could not evaluate (collector failed / metric missing). Do NOT treat
            # as recovery -- closing a real alert on a transient collection error
            # resets the escalation clock and spams recovery/re-alert emails.
            continue
        }

        if ($eval.Status -eq 'OK') {
            # Check if this was previously firing -- if so, it is a recovery
            if ($State.activeAlerts.Contains($alertKey)) {
                # Recovery
                $recoveryAlert = $State.activeAlerts[$alertKey]
                Move-AlertToHistory -State $State -AlertKey $alertKey -RecoveryValue $eval.CurrentValue

                $null = $notifications.Add([PSCustomObject]@{
                    type          = 'Recovery'
                    requirementId = $eval.RequirementId
                    metricPath    = $eval.MetricPath
                    alertKey      = $alertKey
                    currentValue  = $eval.CurrentValue
                    alert         = $recoveryAlert
                })

                Write-Log -Message "Alert RECOVERED: $alertKey (value: $($eval.CurrentValue))" -Level Info -Color Green
            }
            continue
        }

        # Status is Warning or Critical
        if (-not $State.activeAlerts.Contains($alertKey)) {
            # New alert
            $State.activeAlerts[$alertKey] = [ordered]@{
                requirementId     = $eval.RequirementId
                severity          = $eval.Status
                firstSeen         = $nowStr
                lastSeen          = $nowStr
                lastValue         = $eval.CurrentValue
                occurrences       = 1
                lastNotifiedAt    = $null
                notificationsSent = 0
                escalated         = $false
            }

            $null = $notifications.Add([PSCustomObject]@{
                type          = 'NewAlert'
                requirementId = $eval.RequirementId
                metricPath    = $eval.MetricPath
                alertKey      = $alertKey
                currentValue  = $eval.CurrentValue
                severity      = $eval.Status
                alert         = $State.activeAlerts[$alertKey]
            })

            Write-Log -Message "New alert FIRING: $alertKey ($($eval.Status), value: $($eval.CurrentValue))" -Level Warn -Color Yellow
        }
        else {
            # Existing alert -- update
            $existing = $State.activeAlerts[$alertKey]
            $existing['lastSeen'] = $nowStr
            $existing['lastValue'] = $eval.CurrentValue
            $existing['occurrences'] = $existing['occurrences'] + 1

            # Update severity if it escalated (Warning -> Critical)
            if ($eval.Status -eq 'Critical' -and $existing['severity'] -ne 'Critical') {
                $existing['severity'] = 'Critical'
            }

            # Check for escalation (time-based)
            if (-not $existing['escalated']) {
                try {
                    $firstSeen = [datetime]::Parse($existing['firstSeen']).ToUniversalTime()
                    if (($now - $firstSeen).TotalMinutes -ge $escalateAfterMinutes) {
                        $existing['escalated'] = $true

                        $null = $notifications.Add([PSCustomObject]@{
                            type          = 'Escalation'
                            requirementId = $eval.RequirementId
                            metricPath    = $eval.MetricPath
                            alertKey      = $alertKey
                            currentValue  = $eval.CurrentValue
                            severity      = $existing['severity']
                            alert         = $existing
                        })

                        Write-Log -Message "Alert ESCALATED: $alertKey (firing for $([math]::Round(($now - $firstSeen).TotalMinutes, 0)) minutes)" -Level Warn -Color Red
                    }
                }
                catch {}
            }

            # Check cooldown for reminder
            if ($existing['notificationsSent'] -lt $maxNotifications) {
                $shouldRemind = $false
                if ($null -eq $existing['lastNotifiedAt']) {
                    $shouldRemind = $true
                } else {
                    try {
                        $lastNotified = [datetime]::Parse($existing['lastNotifiedAt']).ToUniversalTime()
                        if (($now - $lastNotified).TotalMinutes -ge $cooldownMinutes) {
                            $shouldRemind = $true
                        }
                    }
                    catch {
                        $shouldRemind = $true
                    }
                }

                if ($shouldRemind) {
                    $null = $notifications.Add([PSCustomObject]@{
                        type          = 'Reminder'
                        requirementId = $eval.RequirementId
                        metricPath    = $eval.MetricPath
                        alertKey      = $alertKey
                        currentValue  = $eval.CurrentValue
                        severity      = $existing['severity']
                        alert         = $existing
                    })
                }
            }
        }
    }

    # Check for recoveries of alerts that were NOT in the current evaluation
    # (This handles the case where a requirement's tier wasn't run this cycle --
    #  we do NOT recover those; only requirements that WERE evaluated and came back OK)
    # The recovery logic above already handles that in the evaluation loop.

    return @($notifications)
}

#endregion

#region Daily Summary Rollup

function Update-DailySummary {
    <#
    .SYNOPSIS
        Update the daily summary rollup in the state with data from the current collection.
        Incrementally updates min/max/avg/sum/count for each tracked metric.
    .PARAMETER State
        The platform state hashtable (modified in-place).
    .PARAMETER CollectionResults
        The collection results hashtable from Invoke-MetricsCollection.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$State,

        [Parameter(Mandatory)]
        [hashtable]$CollectionResults
    )

    $now = Get-Date
    $dateKey = $now.ToString('yyyy-MM-dd')
    $nowStr = $now.ToUniversalTime().ToString('o')

    # Ensure dailySummaries exists
    if ($null -eq $State['dailySummaries']) {
        $State['dailySummaries'] = [ordered]@{}
    }

    # Ensure today's entry exists
    if (-not $State.dailySummaries.Contains($dateKey)) {
        $State.dailySummaries[$dateKey] = [ordered]@{}
    }

    $today = $State.dailySummaries[$dateKey]

    # Helper to update a single metric
    $updateMetric = {
        param([string]$metricKey, $value, [string]$timestamp)
        if ($null -eq $value) { return }
        $numVal = [double]$value

        if (-not $today.Contains($metricKey)) {
            $today[$metricKey] = [ordered]@{
                min    = $numVal
                max    = $numVal
                avg    = $numVal
                sum    = $numVal
                count  = 1
                peakAt = $timestamp
            }
        } else {
            $entry = $today[$metricKey]
            # Coerce to scalar doubles -- a hand-edited or damaged state file
            # (e.g. array values) must not crash the whole collection run.
            $curCount = 0.0; $curSum = 0.0; $curMin = $numVal; $curMax = $numVal
            try { $curCount = [double]@($entry['count'])[0] } catch { }
            try { $curSum   = [double]@($entry['sum'])[0] }   catch { }
            try { $curMin   = [double]@($entry['min'])[0] }   catch { }
            try { $curMax   = [double]@($entry['max'])[0] }   catch { }
            $entry['count'] = $curCount + 1
            $entry['sum']   = $curSum + $numVal
            $entry['avg']   = $entry['sum'] / $entry['count']
            $entry['min']   = [math]::Min($curMin, $numVal)
            if ($numVal -gt $curMax) {
                $entry['max']    = $numVal
                $entry['peakAt'] = $timestamp
            }
            else {
                $entry['max']    = $curMax
            }
        }
    }

    # Extract metrics from SystemHealth
    $sh = $CollectionResults['SystemHealth']
    if ($null -ne $sh) {
        $cpuAvg = $null
        $cpuPeak = $null
        $memUsed = $null
        if ($sh -is [hashtable]) {
            if ($null -ne $sh['CPU']) {
                $cpuObj = $sh['CPU']
                $cpuAvg  = if ($cpuObj -is [hashtable]) { $cpuObj['Average'] } else { $cpuObj.Average }
                $cpuPeak = if ($cpuObj -is [hashtable]) { $cpuObj['Peak'] }    else { $cpuObj.Peak }
            }
            if ($null -ne $sh['Memory']) {
                $memObj = $sh['Memory']
                $memUsed = if ($memObj -is [hashtable]) { $memObj['UsedPercent'] } else { $memObj.UsedPercent }
            }
        } else {
            if ($null -ne $sh.CPU) { $cpuAvg = $sh.CPU.Average; $cpuPeak = $sh.CPU.Peak }
            if ($null -ne $sh.Memory) { $memUsed = $sh.Memory.UsedPercent }
        }
        & $updateMetric 'cpuAverage' $cpuAvg $nowStr
        # Roll up the true instantaneous peak too -- cpuAverage alone hides real
        # spikes (a 99% burst can average to ~59% within a sample window).
        & $updateMetric 'cpuPeak' $cpuPeak $nowStr
        & $updateMetric 'memoryUsed' $memUsed $nowStr

        # RDP session counts trend alongside CPU/memory so per-user load and
        # orphaned (disconnected) session growth are visible over time.
        $rdpObj = if ($sh -is [hashtable]) { $sh['RdpSessions'] } else { Get-PSPropertySafe -Object $sh -Name 'RdpSessions' }
        if ($null -ne $rdpObj) {
            $rdpAct  = if ($rdpObj -is [hashtable]) { $rdpObj['Active'] }       else { Get-PSPropertySafe -Object $rdpObj -Name 'Active' }
            $rdpDisc = if ($rdpObj -is [hashtable]) { $rdpObj['Disconnected'] } else { Get-PSPropertySafe -Object $rdpObj -Name 'Disconnected' }
            & $updateMetric 'rdpActive' $rdpAct $nowStr
            & $updateMetric 'rdpDisconnected' $rdpDisc $nowStr
        }

        # Disk metrics
        $disks = $null
        if ($sh -is [hashtable]) { $disks = $sh['Disks'] } else { $disks = $sh.Disks }
        if ($null -ne $disks) {
            foreach ($disk in $disks) {
                $driveLetter = if ($disk -is [hashtable]) { $disk['DriveLetter'] } else { $disk.DriveLetter }
                $usedPct     = if ($disk -is [hashtable]) { $disk['UsedPercent'] } else { $disk.UsedPercent }
                if ($null -ne $driveLetter -and $null -ne $usedPct) {
                    $diskKey = "disk$($driveLetter -replace ':','')"
                    & $updateMetric $diskKey $usedPct $nowStr
                }
            }
        }
    }

    # Extract metrics from Connectivity
    $conn = $CollectionResults['Connectivity']
    if ($null -ne $conn) {
        foreach ($c in @($conn)) {
            $port = $null
            $reachable = $null
            if ($c -is [hashtable]) {
                $port = $c['Port']
                $reachable = $c['Reachable']
            } else {
                $port = $c.Port
                $reachable = $c.Reachable
            }
            if ($null -ne $port) {
                $connKey = "connections$port"
                $connVal = if ($reachable) { 1 } else { 0 }
                & $updateMetric $connKey $connVal $nowStr
            }
        }
    }

    # Update peaks (all-time highs)
    if ($null -eq $State['peaks']) {
        $State['peaks'] = [ordered]@{}
    }
    foreach ($metricKey in @($today.Keys)) {
        $dayMax = $today[$metricKey]['max']
        if (-not $State.peaks.Contains($metricKey)) {
            $State.peaks[$metricKey] = [ordered]@{
                value     = $dayMax
                timestamp = $today[$metricKey]['peakAt']
            }
        } elseif ($dayMax -gt $State.peaks[$metricKey]['value']) {
            $State.peaks[$metricKey]['value']     = $dayMax
            $State.peaks[$metricKey]['timestamp'] = $today[$metricKey]['peakAt']
        }
    }

    # Prune old daily summaries
    Invoke-DailySummaryPrune -State $State
}

function Invoke-DailySummaryPrune {
    <#
    .SYNOPSIS
        Remove daily summary entries older than the configured retention period.
    .PARAMETER State
        The platform state hashtable (modified in-place).
    .PARAMETER RetentionDays
        Number of days to retain. Defaults to config storage.retentionDays or 30.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$State,

        [Parameter()]
        [int]$RetentionDays = 0
    )

    if ($RetentionDays -le 0) {
        if ($null -ne $script:Config -and $null -ne $script:Config.storage) {
            $retDays = 0
            if ($script:Config.storage -is [hashtable]) {
                $retDays = $script:Config.storage['retentionDays']
            } else {
                $retDays = $script:Config.storage.retentionDays
            }
            if ($null -ne $retDays -and $retDays -gt 0) {
                $RetentionDays = $retDays
            } else {
                $RetentionDays = 30
            }
        } else {
            $RetentionDays = 30
        }
    }

    if ($null -eq $State['dailySummaries']) { return }

    $cutoff = (Get-Date).AddDays(-$RetentionDays).ToString('yyyy-MM-dd')
    $keysToRemove = @()

    foreach ($dateKey in @($State.dailySummaries.Keys)) {
        if ($dateKey -lt $cutoff) {
            $keysToRemove += $dateKey
        }
    }

    foreach ($key in $keysToRemove) {
        $State.dailySummaries.Remove($key)
        Write-Log -Message "Pruned daily summary for: $key" -Level Debug -Color Gray
    }
}

function Get-TrendData {
    <#
    .SYNOPSIS
        Extract trend data for a given metric from daily summaries.
        Returns an array of date/avg/min/max objects for the requested day range.
    .PARAMETER State
        The platform state hashtable.
    .PARAMETER MetricKey
        The metric key in dailySummaries (e.g., cpuAverage, memoryUsed, diskC).
    .PARAMETER DayRange
        Number of days to look back. Default: 7.
    #>
    [CmdletBinding()]
    [OutputType([array])]
    param(
        [Parameter(Mandatory)]
        [hashtable]$State,

        [Parameter(Mandatory)]
        [string]$MetricKey,

        [Parameter()]
        [int]$DayRange = 7
    )

    $results = [System.Collections.ArrayList]::new()

    if ($null -eq $State['dailySummaries']) {
        return @()
    }

    $startDate = (Get-Date).AddDays(-$DayRange).Date

    for ($i = 0; $i -le $DayRange; $i++) {
        $dateKey = $startDate.AddDays($i).ToString('yyyy-MM-dd')
        if ($State.dailySummaries.Contains($dateKey)) {
            $dayData = $State.dailySummaries[$dateKey]
            if ($dayData.Contains($MetricKey)) {
                $metric = $dayData[$MetricKey]
                $null = $results.Add([PSCustomObject]@{
                    Date = $dateKey
                    Avg  = [math]::Round($metric['avg'], 1)
                    Min  = [math]::Round($metric['min'], 1)
                    Max  = [math]::Round($metric['max'], 1)
                })
            }
        }
    }

    return @($results)
}

function Get-SparklineHtml {
    <#
    .SYNOPSIS
        Generate a CSS-only sparkline from an array of numeric values.
        Each value becomes an inline-block div with proportional height,
        color-coded green/yellow/red based on optional thresholds.
    .PARAMETER Values
        Array of numeric values to visualize.
    .PARAMETER MaxHeight
        Maximum bar height in pixels. Default: 20.
    .PARAMETER WarningThreshold
        Value at or above which bars turn yellow (for HigherIsBad). Optional.
    .PARAMETER CriticalThreshold
        Value at or above which bars turn red (for HigherIsBad). Optional.
    .PARAMETER HigherIsBad
        When true (default), higher values are bad. When false, lower values are bad.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory)]
        [array]$Values,

        [Parameter()]
        [int]$MaxHeight = 20,

        [Parameter()]
        $WarningThreshold = $null,

        [Parameter()]
        $CriticalThreshold = $null,

        [Parameter()]
        [bool]$HigherIsBad = $true
    )

    if ($null -eq $Values -or $Values.Count -eq 0) {
        return '<span class="sparkline-empty">--</span>'
    }

    $numValues = @()
    foreach ($v in $Values) {
        try { $numValues += [double]$v } catch { $numValues += 0 }
    }

    # Thresholds come from user-editable requirement JSON -- a non-numeric value
    # must degrade to "no threshold coloring", not abort the whole email/digest.
    if ($null -ne $WarningThreshold)  { try { $WarningThreshold  = [double]$WarningThreshold }  catch { $WarningThreshold  = $null } }
    if ($null -ne $CriticalThreshold) { try { $CriticalThreshold = [double]$CriticalThreshold } catch { $CriticalThreshold = $null } }

    $maxVal = ($numValues | Measure-Object -Maximum).Maximum
    $minVal = ($numValues | Measure-Object -Minimum).Minimum
    $range = $maxVal - $minVal
    # A single point (or a dead-flat series) has no min/max spread to normalize
    # against, which collapses every bar to the 2px floor. Fall back to absolute
    # scaling (value as a percentage of 100) so one day of data still renders
    # proportionally instead of a flat line.
    $absoluteScale = (@($numValues).Count -le 1 -or $range -eq 0)
    if ($range -eq 0) { $range = 1 }

    $bars = [System.Text.StringBuilder]::new()
    $null = $bars.Append('<span class="sparkline" style="display:inline-flex;align-items:flex-end;gap:1px;">')

    foreach ($val in $numValues) {
        $heightPct = if ($absoluteScale) { [math]::Min(1.0, [math]::Max(0.0, $val / 100.0)) }
                     else { (($val - $minVal) / $range) }
        $heightPx = [math]::Max(2, [math]::Round($heightPct * $MaxHeight, 0))

        # Determine color (aligned with the report CSS palette)
        $color = '#3fb950'  # green
        if ($HigherIsBad) {
            if ($null -ne $CriticalThreshold -and $val -ge [double]$CriticalThreshold) {
                $color = '#f85149'  # red
            } elseif ($null -ne $WarningThreshold -and $val -ge [double]$WarningThreshold) {
                $color = '#d29922'  # amber
            }
        } else {
            if ($null -ne $CriticalThreshold -and $val -le [double]$CriticalThreshold) {
                $color = '#f85149'  # red
            } elseif ($null -ne $WarningThreshold -and $val -le [double]$WarningThreshold) {
                $color = '#d29922'  # amber
            }
        }

        $null = $bars.Append("<span style=`"display:inline-block;width:4px;height:${heightPx}px;background:${color};border-radius:1px;`" title=`"$val`"></span>")
    }

    $null = $bars.Append('</span>')
    return $bars.ToString()
}

#endregion

#region SMTP Email Engine

function Send-MonitorEmail {
    <#
    .SYNOPSIS
        Core SMTP send function using System.Net.Mail.SmtpClient.
        Port 25 default, no auth, optional TLS. 10-second timeout.
        Never throws -- returns $true/$false.
    #>
    [CmdletBinding()]
    [OutputType([bool])]
    param(
        [Parameter()]
        [AllowEmptyCollection()]
        [AllowNull()]
        [string[]]$To = @(),

        [Parameter()]
        [string[]]$Cc = @(),

        [Parameter(Mandatory)]
        [string]$Subject,

        [Parameter(Mandatory)]
        [string]$HtmlBody,

        [Parameter()]
        [ValidateSet('Normal','High','Low')]
        [string]$Priority = 'Normal'
    )

    $To = @($To | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    if ($To.Count -eq 0) {
        Write-Log -Message "Email NOT sent -- no recipients configured (subject: '$Subject'). Add addresses to alerting.defaults.notifyTo in ca-platform-monitor.json (or per-requirement notification.notifyTo)." -Level Warn -Color Yellow
        return $false
    }

    $smtpCfg = $null
    if ($null -ne $script:Config -and $null -ne $script:Config.alerting) {
        $alerting = $script:Config.alerting
        if ($alerting -is [hashtable]) { $smtpCfg = $alerting['smtp'] } else { $smtpCfg = $alerting.smtp }
    }

    $smtpServer = $null
    $smtpPort = 25
    $smtpFrom = 'cyberark-monitor@corp.local'
    $useTls = $false

    if ($null -ne $smtpCfg) {
        if ($smtpCfg -is [hashtable]) {
            $smtpServer = $smtpCfg['server']
            if ($null -ne $smtpCfg['port']) { $smtpPort = $smtpCfg['port'] }
            if ($null -ne $smtpCfg['from']) { $smtpFrom = $smtpCfg['from'] }
            if ($null -ne $smtpCfg['useTls']) { $useTls = [bool]$smtpCfg['useTls'] }
        } else {
            $smtpServer = $smtpCfg.server
            if ($null -ne $smtpCfg.port) { $smtpPort = $smtpCfg.port }
            if ($null -ne $smtpCfg.from) { $smtpFrom = $smtpCfg.from }
            if ($null -ne $smtpCfg.useTls) { $useTls = [bool]$smtpCfg.useTls }
        }
    }

    if ([string]::IsNullOrWhiteSpace($smtpServer)) {
        Write-Log -Message "Email NOT sent -- no SMTP server configured (subject: '$Subject'). Set alerting.smtp.server (plus port/from/useTls if needed) in ca-platform-monitor.json, then verify with: .\Invoke-CAPlatformMonitor.ps1 -TestAlert" -Level Warn -Color Yellow
        return $false
    }

    $msg = $null
    $client = $null
    try {
        $msg = [System.Net.Mail.MailMessage]::new()
        $msg.From = [System.Net.Mail.MailAddress]::new($smtpFrom)
        foreach ($recipient in $To) {
            if (-not [string]::IsNullOrWhiteSpace($recipient)) {
                $msg.To.Add($recipient)
            }
        }
        foreach ($ccAddr in $Cc) {
            if (-not [string]::IsNullOrWhiteSpace($ccAddr)) {
                $msg.CC.Add($ccAddr)
            }
        }
        $msg.Subject = $Subject
        $msg.Body = $HtmlBody
        $msg.IsBodyHtml = $true
        $msg.Priority = [System.Net.Mail.MailPriority]::$Priority

        $client = [System.Net.Mail.SmtpClient]::new($smtpServer, $smtpPort)
        $client.Timeout = 10000
        $client.EnableSsl = $useTls

        $client.Send($msg)
        Write-Log -Message "Email sent successfully: '$Subject' to $($To -join ', ') via ${smtpServer}:${smtpPort}" -Level Info -Color Green
        return $true
    }
    catch {
        Write-Log -Message "Email send FAILED via ${smtpServer}:${smtpPort} (subject: '$Subject', to: $($To -join ', ')): $($_.Exception.Message)" -Level Warn -Color Yellow
        return $false
    }
    finally {
        if ($null -ne $client) { try { $client.Dispose() } catch {} }
        if ($null -ne $msg)    { try { $msg.Dispose() } catch {} }
    }
}

function New-ServiceRestartEmailBody {
    <#
    .SYNOPSIS
        HTML body for a service self-heal (auto-restart) notification.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory)][string]$ServiceName,
        [Parameter(Mandatory)][string]$Outcome,
        [Parameter(Mandatory)][string]$Detail,
        [Parameter()][int]$AttemptsToday = 0
    )
    $enc = [System.Net.WebUtility]
    $color = if ($Outcome -eq 'SUCCESS') { '#3fb950' } else { '#f85149' }
    $hostName = $env:COMPUTERNAME
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $b = [System.Text.StringBuilder]::new()
    [void]$b.Append("<html><body style='font-family:Segoe UI,Arial,sans-serif;'>")
    [void]$b.Append("<h2 style='color:$color;margin:0 0 10px 0;'>Service Self-Heal: $($enc::HtmlEncode($Outcome))</h2>")
    [void]$b.Append("<table cellpadding='6' style='border-collapse:collapse;font-size:14px;'>")
    [void]$b.Append("<tr><td><b>Service</b></td><td>$($enc::HtmlEncode($ServiceName))</td></tr>")
    [void]$b.Append("<tr><td><b>Host</b></td><td>$($enc::HtmlEncode($hostName))</td></tr>")
    [void]$b.Append("<tr><td><b>Outcome</b></td><td style='color:$color;'><b>$($enc::HtmlEncode($Outcome))</b></td></tr>")
    [void]$b.Append("<tr><td><b>Restart attempts today</b></td><td>$AttemptsToday</td></tr>")
    [void]$b.Append("<tr><td><b>Time</b></td><td>$($enc::HtmlEncode($ts))</td></tr>")
    [void]$b.Append("</table>")
    [void]$b.Append("<p style='font-size:14px;'>$($enc::HtmlEncode($Detail))</p>")
    [void]$b.Append("<p style='color:#888;font-size:12px;'>Generated by Invoke-CAPlatformMonitor self-heal.</p>")
    [void]$b.Append("</body></html>")
    return $b.ToString()
}

function Invoke-ServiceAutoRestart {
    <#
    .SYNOPSIS
        Opt-in self-heal: restart allowlisted services found unexpectedly stopped,
        capped per day, emailing the outcome (success or failure). Never throws.
    .DESCRIPTION
        Gated entirely by config serviceBaseline.autoRestartServices (an explicit
        allowlist; EMPTY = feature inactive -- nothing is ever restarted without a
        per-service opt-in). An allowlisted service found Stopped is restarted,
        with three exemptions: serviceBaseline.autoRestartExclude, a config
        expectedStates entry declaring it Stopped, and a LEARNED adaptive-baseline
        expectedState of Stopped (protects passive/DR nodes sharing a farm-wide
        config; override with -Baseline or expectedStates if the learning is wrong).
        Honors a per-service per-day cap (maxRestartsPerDay) in state.serviceRestarts;
        the cap-reached email sends at most once per day per service.
        Runs in Scheduled/Monitor modes only -- never in read-only Report mode.
    #>
    [CmdletBinding()]
    [OutputType([array])]
    param(
        [Parameter(Mandatory)] $ServiceResult,
        [Parameter(Mandatory)] [hashtable]$State,
        [switch]$NoAlerts
    )

    $outcomes = @()

    # Remediation gate: NEVER issue real Start-Service calls driven by mock data
    # or on a non-Windows host. (The mock ServiceResiliency fixture happens to
    # contain only Running services today -- that must stay an extra safety, not
    # the only one: its names are REAL CyberArk service names.)
    if ($UseMockData -or -not (Test-IsWindowsPlatform)) {
        Write-Log -Message 'Self-heal skipped: mock data / non-Windows host' -Level Debug -Component 'AutoRestart'
        return $outcomes
    }

    # Self-heal is remediation, not collection -- a failure here must NEVER crash
    # the run (in Scheduled mode there is no per-tier catch, so it would trap to
    # FATAL/exit 2). Wrap the whole body: log the exact location and continue.
    try {
    # Resolve config. The allowlist IS the opt-in: only services explicitly named
    # in serviceBaseline.autoRestartServices are ever restarted; an empty list
    # deactivates self-heal entirely. autoRestart=$false is the master kill switch.
    $sbCfg = $null
    if ($null -ne $script:Config) {
        $sbCfg = if ($script:Config -is [hashtable]) { $script:Config['serviceBaseline'] } else { $script:Config.serviceBaseline }
    }
    $autoRestart = $true    # master switch; inert while the allowlist is empty
    $allowList   = @()      # REQUIRED opt-in: empty = self-heal inactive
    $excludeList = @()
    $maxPerDay   = 10
    $backoff     = @(0, 5, 15, 30, 60)   # minutes between attempts; last value repeats
    if ($null -ne $sbCfg) {
        if ($sbCfg -is [hashtable]) {
            if ($null -ne $sbCfg['autoRestart'])         { $autoRestart = [bool]$sbCfg['autoRestart'] }
            if ($null -ne $sbCfg['autoRestartServices']) { $allowList   = @($sbCfg['autoRestartServices']) }
            if ($null -ne $sbCfg['autoRestartExclude'])  { $excludeList = @($sbCfg['autoRestartExclude']) }
            if ($null -ne $sbCfg['maxRestartsPerDay'])   { $maxPerDay   = [int]$sbCfg['maxRestartsPerDay'] }
            if ($null -ne $sbCfg['restartBackoffMinutes']) { $backoff   = @($sbCfg['restartBackoffMinutes']) }
        } else {
            $ar = Get-PSPropertySafe -Object $sbCfg -Name 'autoRestart';         if ($null -ne $ar) { $autoRestart = [bool]$ar }
            $al = Get-PSPropertySafe -Object $sbCfg -Name 'autoRestartServices'; if ($null -ne $al) { $allowList   = @($al) }
            $ex = Get-PSPropertySafe -Object $sbCfg -Name 'autoRestartExclude';  if ($null -ne $ex) { $excludeList = @($ex) }
            $mx = Get-PSPropertySafe -Object $sbCfg -Name 'maxRestartsPerDay';   if ($null -ne $mx) { $maxPerDay   = [int]$mx }
            $bo = Get-PSPropertySafe -Object $sbCfg -Name 'restartBackoffMinutes'; if ($null -ne $bo) { $backoff  = @($bo) }
        }
    }
    # Sanitize the backoff schedule: numeric, non-negative; empty falls back.
    $backoff = @($backoff | ForEach-Object { try { [double]$_ } catch { $null } } | Where-Object { $null -ne $_ -and $_ -ge 0 })
    if ($backoff.Count -eq 0) { $backoff = @(0, 5, 15, 30, 60) }
    # Clean the two lists (drop blanks)
    $allowList   = @($allowList   | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    $excludeList = @($excludeList | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    # Config-declared expected states (a service the admin explicitly declared
    # should be Stopped -- e.g. a DR/passive node -- is never auto-restarted).
    $expectedStates = @{}
    if ($null -ne $sbCfg) {
        $es = if ($sbCfg -is [hashtable]) { $sbCfg['expectedStates'] } else { Get-PSPropertySafe -Object $sbCfg -Name 'expectedStates' }
        if ($null -ne $es) {
            if ($es -is [System.Collections.IDictionary]) { foreach ($k in $es.Keys) { $expectedStates["$k"] = "$($es[$k])" } }
            else { foreach ($p in @($es.PSObject.Properties)) { $expectedStates[$p.Name] = "$($p.Value)" } }
        }
    }

    if ($null -eq $ServiceResult) { return $outcomes }
    # NOTE: the @() MUST wrap the whole if-expression. `$x = if(...){ @() }` emits zero
    # objects and yields $null (not an empty array), so $svcList.Count would throw under
    # StrictMode when no monitored service is present (e.g. a non-CyberArk host).
    $svcList = @(if ($ServiceResult -is [hashtable]) { $ServiceResult['Services'] } else { $ServiceResult.Services })
    if ($svcList.Count -eq 0) { return $outcomes }

    $stoppedSvcs = @($svcList | Where-Object { "$(if ($_ -is [hashtable]) { $_['Status'] } else { $_.Status })" -eq 'Stopped' })

    if (-not $autoRestart) {
        # Feature explicitly disabled -- but if services are down, say why in the log.
        if ($stoppedSvcs.Count -gt 0) {
            Write-Log -Message "Self-heal is OFF: $($stoppedSvcs.Count) monitored service(s) stopped but serviceBaseline.autoRestart is false." -Level Info -Color Yellow -Component 'AutoRestart'
        }
        return $outcomes
    }
    if ($allowList.Count -eq 0) {
        # No allowlist = self-heal inactive. Automatic remediation on privileged
        # infrastructure must be an explicit per-service decision: an empty list
        # silently restarting the Vault/DR/CPM that an admin stopped for
        # maintenance is an incident generator, not a feature.
        if ($stoppedSvcs.Count -gt 0) {
            Write-Log -Message "Self-heal inactive: $($stoppedSvcs.Count) monitored service(s) stopped, but serviceBaseline.autoRestartServices is empty. Name services there to opt them into auto-restart." -Level Info -Color Yellow -Component 'AutoRestart'
        }
        return $outcomes
    }
    if ($stoppedSvcs.Count -gt 0) {
        Write-Log -Message "Self-heal ON (scope: $($allowList.Count) allowlisted service(s)): $($stoppedSvcs.Count) stopped service(s) to evaluate." -Level Debug -Component 'AutoRestart'
    }

    # Recipients for the self-heal email (alerting.defaults.notifyTo)
    $recips = @()
    try {
        $al2 = if ($script:Config -is [hashtable]) { $script:Config['alerting'] } else { $script:Config.alerting }
        if ($null -ne $al2) {
            $df = if ($al2 -is [hashtable]) { $al2['defaults'] } else { $al2.defaults }
            if ($null -ne $df) {
                $nt = if ($df -is [hashtable]) { $df['notifyTo'] } else { Get-PSPropertySafe -Object $df -Name 'notifyTo' }
                if ($null -ne $nt) { $recips = @($nt) }
            }
        }
    } catch { }

    if ($null -eq $State['serviceRestarts']) { $State['serviceRestarts'] = [ordered]@{} }
    $today = (Get-Date).ToString('yyyy-MM-dd')

    foreach ($svc in $svcList) {
        $name   = if ($svc -is [hashtable]) { $svc['ServiceName'] } else { $svc.ServiceName }
        $status = if ($svc -is [hashtable]) { $svc['Status'] }      else { $svc.Status }
        if ([string]::IsNullOrWhiteSpace($name)) { continue }
        if ("$status" -ne 'Stopped') {
            # Service is healthy: reset the escalation ladder so the NEXT outage
            # starts at an immediate attempt again. The daily count is kept --
            # maxRestartsPerDay is the flap-storm guard and must keep accumulating.
            if ("$status" -eq 'Running' -and $State.serviceRestarts.Contains($name)) {
                $recOk = $State.serviceRestarts[$name]
                if ($recOk -is [System.Collections.IDictionary] -and [int]"$(if ($null -ne $recOk['attemptIndex']) { $recOk['attemptIndex'] } else { 0 })" -gt 0) {
                    $recOk['attemptIndex'] = 0
                    Write-Log -Message "Self-heal: '$name' is Running again -- escalation ladder reset" -Level Debug -Component 'AutoRestart'
                }
            }
            continue
        }
        # Being monitored + Stopped is the trigger: keep it running. Scope/exempt:
        #  - if autoRestartServices is non-empty, restart ONLY those names
        #  - autoRestartExclude never restarts (belt-and-suspenders)
        #  - expectedStates declares a service that SHOULD be Stopped (DR/passive)
        if ($allowList.Count -gt 0 -and $allowList -notcontains $name) { continue }
        if ($excludeList -contains $name) {
            Write-Log -Message "Auto-restart SKIPPED for '$name': listed in serviceBaseline.autoRestartExclude" -Level Info -Color Gray -Component 'AutoRestart'
            continue
        }
        if ($expectedStates.ContainsKey($name) -and $expectedStates[$name] -eq 'Stopped') {
            Write-Log -Message "Auto-restart SKIPPED for '$name': serviceBaseline.expectedStates declares it Stopped" -Level Info -Color Gray -Component 'AutoRestart'
            continue
        }
        # Also honor the LEARNED baseline: if the adaptive baseline has stabilized
        # on Stopped for this service (passive CPM node, DR vault), auto-restart
        # would fight the baseline engine's own conclusion.
        $learnedExpected = $null
        if ($null -ne $State['serviceBaseline'] -and $State.serviceBaseline.Contains($name)) {
            $blEntry = $State.serviceBaseline[$name]
            $learnedExpected = if ($blEntry -is [System.Collections.IDictionary]) { $blEntry['expectedState'] } else { Get-PSPropertySafe -Object $blEntry -Name 'expectedState' }
        }
        if ("$learnedExpected" -eq 'Stopped') {
            Write-Log -Message "Auto-restart SKIPPED for '$name': adaptive baseline has learned Stopped as its expected state (override via expectedStates/-Baseline if wrong)" -Level Info -Color Gray -Component 'AutoRestart'
            continue
        }

        # Per-service daily cap (reset counter on date change) + escalation state
        $count = 0
        $capNotified = ''
        $attemptIndex = 0
        $lastAttemptAt = $null
        $rec = $State.serviceRestarts[$name]
        if ($null -ne $rec) {
            # State entries round-trip as [ordered] OrderedDictionary (an
            # IDictionary but NOT [hashtable]); index by key for both, or the
            # daily counter silently reads back null and the cap never engages.
            $recDate = if ($rec -is [System.Collections.IDictionary]) { $rec['date'] }  else { Get-PSPropertySafe -Object $rec -Name 'date' }
            $recCnt  = if ($rec -is [System.Collections.IDictionary]) { $rec['count'] } else { Get-PSPropertySafe -Object $rec -Name 'count' }
            if ("$recDate" -eq $today -and $null -ne $recCnt) { $count = [int]$recCnt }
            $cn = if ($rec -is [System.Collections.IDictionary]) { $rec['capNotifiedDate'] } else { Get-PSPropertySafe -Object $rec -Name 'capNotifiedDate' }
            if ($null -ne $cn) { $capNotified = "$cn" }
            $ai = if ($rec -is [System.Collections.IDictionary]) { $rec['attemptIndex'] } else { Get-PSPropertySafe -Object $rec -Name 'attemptIndex' }
            if ($null -ne $ai) { try { $attemptIndex = [int]$ai } catch { } }
            $la = if ($rec -is [System.Collections.IDictionary]) { $rec['lastAt'] } else { Get-PSPropertySafe -Object $rec -Name 'lastAt' }
            if ($null -ne $la) { try { $lastAttemptAt = [datetime]::Parse("$la").ToUniversalTime() } catch { } }
        }

        if ($count -ge $maxPerDay) {
            Write-Log -Message "Auto-restart SKIPPED for '$name': daily cap ($maxPerDay) reached" -Level Warn -Color Yellow -Component 'AutoRestart'
            $outcomes += [PSCustomObject]@{ ServiceName = $name; Action = 'Skipped'; Success = $false; Reason = "Daily restart cap ($maxPerDay) reached"; AttemptsToday = $count }
            # Send the cap-reached email ONCE per day -- on a 5-minute cadence a
            # still-down capped service would otherwise page ~288 times/day.
            if (-not $NoAlerts -and $capNotified -ne $today) {
                $body = New-ServiceRestartEmailBody -ServiceName $name -Outcome 'CAP REACHED' `
                    -Detail "Service '$name' is still unexpectedly stopped, but the daily restart cap of $maxPerDay has been reached. No further automatic restarts today -- manual intervention required." -AttemptsToday $count
                $sent = Send-MonitorEmail -To $recips -Subject "[Self-Heal] $name NOT restarted (cap reached) on $($env:COMPUTERNAME)" -HtmlBody $body -Priority 'High'
                if ($sent -and $null -ne $rec -and $rec -is [System.Collections.IDictionary]) {
                    $rec['capNotifiedDate'] = $today
                }
            }
            continue
        }

        # NMS-style escalating backoff: attempt N must wait backoff[N] minutes
        # after the previous attempt (last schedule entry repeats -- hourly by
        # default). Attempt 0 fires immediately on first detection.
        $stepIdx  = [math]::Min($attemptIndex, $backoff.Count - 1)
        $delayMin = [double]$backoff[$stepIdx]
        if ($attemptIndex -gt 0 -and $null -ne $lastAttemptAt) {
            $sinceMin = ((Get-Date).ToUniversalTime() - $lastAttemptAt).TotalMinutes
            if ($sinceMin -lt $delayMin) {
                Write-Log -Message "Auto-restart DEFERRED for '$name': backoff step $attemptIndex requires $delayMin min between attempts ($([math]::Round($delayMin - $sinceMin, 1)) min remaining)" -Level Info -Color Gray -Component 'AutoRestart'
                continue
            }
        }

        Write-Log -Message "Auto-restart: starting '$name' (attempt $($count + 1)/$maxPerDay today, backoff step $attemptIndex)" -Level Info -Color Cyan -Component 'AutoRestart'
        $success = $false
        $errMsg  = ''
        try {
            Start-Service -Name $name -ErrorAction Stop
            try { (Get-Service -Name $name -ErrorAction Stop).WaitForStatus('Running', [timespan]::FromSeconds(20)) } catch { }
            $cur = (Get-Service -Name $name -ErrorAction SilentlyContinue).Status
            $success = ("$cur" -eq 'Running')
            if (-not $success) { $errMsg = "Service did not reach Running (status: $cur)" }
        }
        catch {
            $success = $false
            $errMsg  = $_.Exception.Message
        }

        $count++
        $State.serviceRestarts[$name] = [ordered]@{
            date            = $today
            count           = $count
            lastAt          = (Get-Date).ToUniversalTime().ToString('o')
            lastResult      = if ($success) { 'Success' } else { 'Failed' }
            lastError       = $errMsg
            # Escalation position: advance on every attempt; reset to 0 when the
            # service is next observed Running (see the healthy branch above).
            attemptIndex    = $attemptIndex + 1
            capNotifiedDate = $(if ($capNotified) { $capNotified } else { $null })
        }

        if ($success) {
            Write-Log -Message "Auto-restart SUCCESS: '$name' is Running again" -Level Info -Color Green -Component 'AutoRestart'
        } else {
            Write-Log -Message "Auto-restart FAILED: '$name' -- $errMsg" -Level Error -Color Red -Component 'AutoRestart'
        }
        $outcomes += [PSCustomObject]@{ ServiceName = $name; Action = 'Restart'; Success = $success; Reason = $errMsg; AttemptsToday = $count }

        if (-not $NoAlerts) {
            $outcomeStr = if ($success) { 'SUCCESS' } else { 'FAILED' }
            $detail = if ($success) {
                "Service '$name' was found unexpectedly stopped and was restarted successfully; it is Running again."
            } else {
                "Service '$name' was found unexpectedly stopped; the automatic restart attempt FAILED: $errMsg"
            }
            $body = New-ServiceRestartEmailBody -ServiceName $name -Outcome $outcomeStr -Detail $detail -AttemptsToday $count
            $null = Send-MonitorEmail -To $recips -Subject "[Self-Heal] $name restart $outcomeStr on $($env:COMPUTERNAME)" -HtmlBody $body -Priority $(if ($success) { 'Normal' } else { 'High' })
        }
    }
    }
    catch {
        Write-Log -Message "Self-heal failed (non-fatal, run continues): $($_.Exception.Message)" -Level Error -Color Red -Component 'AutoRestart'
        Write-Log -Message "  at $($_.InvocationInfo.PositionMessage -replace '\r?\n',' | ')" -Level Warn -Color Yellow -Component 'AutoRestart'
    }

    return $outcomes
}

function New-AlertEmailBody {
    <#
    .SYNOPSIS
        Builds an HTML email body for an alert or escalation notification.
        Uses StringBuilder and Get-ReportCSS for styling.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory)]
        $Requirement,

        [Parameter(Mandatory)]
        $EvalResult,

        [Parameter()]
        [hashtable]$State = $null,

        [Parameter()]
        [switch]$IsEscalation
    )

    $E  = [System.Net.WebUtility]
    $sb = [System.Text.StringBuilder]::new(4096)
    $css = Get-ReportCSS

    # Extract requirement properties safely
    $reqName = if ($Requirement -is [hashtable]) { $Requirement['name'] } else { $Requirement.name }
    $reqId   = if ($Requirement -is [hashtable]) { $Requirement['id'] } else { $Requirement.id }
    $reqSla  = if ($Requirement -is [hashtable]) { $Requirement['sla'] } else { $Requirement.sla }
    $reqRunbook = if ($Requirement -is [hashtable]) { $Requirement['runbookUrl'] } else { $Requirement.runbookUrl }

    $severity   = if ($null -ne $EvalResult.Status) { $EvalResult.Status } else { 'Warning' }
    $sevColor   = if ($severity -eq 'Critical') { '#f85149' } else { '#d29922' }
    $sevBgColor = if ($severity -eq 'Critical') { '#3d1f1f' } else { '#3d2e0d' }
    $headerGradient = if ($IsEscalation) { 'linear-gradient(135deg, #7a1f1f 0%, #4f0d0d 100%)' } `
                      elseif ($severity -eq 'Critical') { 'linear-gradient(135deg, #7a1f1f 0%, #4f0d0d 100%)' } `
                      else { 'linear-gradient(135deg, #7a5a0d 0%, #4f3a0d 100%)' }

    $typeLabel = if ($IsEscalation) { 'ESCALATION' } else { 'ALERT' }

    $null = $sb.AppendLine('<!DOCTYPE html><html><head><meta charset="utf-8"><style>')
    $null = $sb.AppendLine($css)
    $null = $sb.AppendLine('</style></head><body style="background:#0d1117;padding:20px;">')
    $null = $sb.AppendLine('<div class="container" style="max-width:600px;">')

    # Header
    $null = $sb.AppendLine("<div style=`"background:$headerGradient;padding:24px;border-radius:12px;margin-bottom:20px;`">")
    $null = $sb.AppendLine("<h1 style=`"color:#fff;font-size:22px;margin:0;`">${typeLabel}: $($E::HtmlEncode($reqName))</h1>")
    $null = $sb.AppendLine("<p style=`"color:rgba(255,255,255,0.8);font-size:13px;margin-top:8px;`">Requirement: $($E::HtmlEncode($reqId)) | Server: $($E::HtmlEncode($env:COMPUTERNAME)) | $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</p>")
    $null = $sb.AppendLine('</div>')

    # Severity badge + metric details
    $null = $sb.AppendLine('<div class="section" style="margin-bottom:20px;">')
    $null = $sb.AppendLine("<p><span style=`"display:inline-block;padding:4px 12px;border-radius:12px;background:$sevBgColor;color:$sevColor;font-weight:700;font-size:14px;`">$($E::HtmlEncode($severity))</span></p>")
    $null = $sb.AppendLine("<table><tr><th>Metric</th><th>Current Value</th><th>Threshold</th></tr>")
    $curVal = if ($null -ne $EvalResult.CurrentValue) { $E::HtmlEncode("$($EvalResult.CurrentValue)") } else { 'N/A' }
    $thrVal = if ($null -ne $EvalResult.Threshold) { $E::HtmlEncode("$($EvalResult.Threshold)") } else { 'N/A' }
    $null = $sb.AppendLine("<tr><td>$($E::HtmlEncode($EvalResult.MetricPath))</td><td class=`"num`" style=`"color:$sevColor;font-weight:700;`">$curVal</td><td class=`"num`">$thrVal</td></tr>")
    $null = $sb.AppendLine('</table></div>')

    # SLA / requirement text
    if (-not [string]::IsNullOrWhiteSpace($reqSla)) {
        $null = $sb.AppendLine("<div class=`"section`" style=`"margin-bottom:20px;`"><h3>SLA Requirement</h3><p>$($E::HtmlEncode($reqSla))</p></div>")
    }

    # Runbook button
    if (-not [string]::IsNullOrWhiteSpace($reqRunbook)) {
        $null = $sb.AppendLine("<div style=`"text-align:center;margin-bottom:20px;`"><a href=`"$($E::HtmlEncode($reqRunbook))`" style=`"display:inline-block;padding:10px 24px;background:#58a6ff;color:#fff;border-radius:6px;text-decoration:none;font-weight:600;`">Open Runbook</a></div>")
    }

    # 7-day sparkline trend from state.dailySummaries
    if ($null -ne $State) {
        $metricKey = $null
        $metricPath = if ($null -ne $EvalResult.MetricPath) { $EvalResult.MetricPath } else { '' }
        # Map known metric paths to dailySummary keys
        if ($metricPath -eq 'CPU.Average') { $metricKey = 'cpuAverage' }
        elseif ($metricPath -eq 'Memory.UsedPercent') { $metricKey = 'memoryUsed' }
        elseif ($metricPath -eq 'MinDaysToExpiry') { $metricKey = 'certMinExpiry' }

        if ($null -ne $metricKey) {
            $trend = Get-TrendData -State $State -MetricKey $metricKey -DayRange 7
            if ($null -ne $trend -and @($trend).Count -gt 0) {
                $trendValues = @($trend | ForEach-Object { $_.Avg })
                $warnTh = if ($Requirement -is [hashtable]) { $Requirement['warningThreshold'] } else { $Requirement.warningThreshold }
                $critTh = if ($Requirement -is [hashtable]) { $Requirement['criticalThreshold'] } else { $Requirement.criticalThreshold }
                $sparkHtml = Get-SparklineHtml -Values $trendValues -WarningThreshold $warnTh -CriticalThreshold $critTh
                $null = $sb.AppendLine("<div class=`"section`" style=`"margin-bottom:20px;`"><h3>7-Day Trend</h3><p>$sparkHtml</p></div>")
            }
        }
    }

    # Footer
    $null = $sb.AppendLine("<div class=`"footer`">CyberArk Platform Monitor | $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</div>")
    $null = $sb.AppendLine('</div></body></html>')

    return $sb.ToString()
}

function New-RecoveryEmailBody {
    <#
    .SYNOPSIS
        Builds an HTML email body for a recovery notification.
        Green-tinted header. Shows what recovered, duration, peak, notification count.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory)]
        $Requirement,

        [Parameter(Mandatory)]
        [hashtable]$HistoryEntry
    )

    $E  = [System.Net.WebUtility]
    $sb = [System.Text.StringBuilder]::new(2048)
    $css = Get-ReportCSS

    $reqName = if ($Requirement -is [hashtable]) { $Requirement['name'] } else { $Requirement.name }
    $reqId   = if ($Requirement -is [hashtable]) { $Requirement['id'] } else { $Requirement.id }

    $duration = if ($null -ne $HistoryEntry['durationMinutes']) { $HistoryEntry['durationMinutes'] } else { 0 }
    $peakVal  = if ($null -ne $HistoryEntry['peakValue']) { $HistoryEntry['peakValue'] } else { 'N/A' }
    $notifCount = if ($null -ne $HistoryEntry['notificationsSent']) { $HistoryEntry['notificationsSent'] } else { 0 }
    $recoveryVal = if ($null -ne $HistoryEntry['recoveryValue']) { $HistoryEntry['recoveryValue'] } else { 'N/A' }

    $null = $sb.AppendLine('<!DOCTYPE html><html><head><meta charset="utf-8"><style>')
    $null = $sb.AppendLine($css)
    $null = $sb.AppendLine('</style></head><body style="background:#0d1117;padding:20px;">')
    $null = $sb.AppendLine('<div class="container" style="max-width:600px;">')

    # Green header
    $null = $sb.AppendLine('<div style="background:linear-gradient(135deg, #1f6f3a 0%, #0d3f1f 100%);padding:24px;border-radius:12px;margin-bottom:20px;">')
    $null = $sb.AppendLine("<h1 style=`"color:#fff;font-size:22px;margin:0;`">RECOVERED: $($E::HtmlEncode($reqName))</h1>")
    $null = $sb.AppendLine("<p style=`"color:rgba(255,255,255,0.8);font-size:13px;margin-top:8px;`">Requirement: $($E::HtmlEncode($reqId)) | Server: $($E::HtmlEncode($env:COMPUTERNAME)) | $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</p>")
    $null = $sb.AppendLine('</div>')

    # Recovery details table
    $null = $sb.AppendLine('<div class="section" style="margin-bottom:20px;">')
    $null = $sb.AppendLine('<h2 style="color:#3fb950;">Recovery Details</h2>')
    $null = $sb.AppendLine('<table>')
    $null = $sb.AppendLine('<tr><th>Detail</th><th>Value</th></tr>')
    $null = $sb.AppendLine("<tr><td>Duration</td><td>$duration minutes</td></tr>")
    $null = $sb.AppendLine("<tr><td>Peak Value During Incident</td><td>$($E::HtmlEncode("$peakVal"))</td></tr>")
    $null = $sb.AppendLine("<tr><td>Current Value</td><td style=`"color:#3fb950;font-weight:700;`">$($E::HtmlEncode("$recoveryVal"))</td></tr>")
    $null = $sb.AppendLine("<tr><td>Notifications Sent</td><td>$notifCount</td></tr>")
    $null = $sb.AppendLine('</table></div>')

    # Footer
    $null = $sb.AppendLine("<div class=`"footer`">CyberArk Platform Monitor | $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</div>")
    $null = $sb.AppendLine('</div></body></html>')

    return $sb.ToString()
}

function New-DigestEmailBody {
    <#
    .SYNOPSIS
        Builds a daily digest email with summary cards, active alerts table,
        7-day trend sparklines, peak records, and optional capacity forecasts.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory)]
        [hashtable]$State,

        [Parameter()]
        [object[]]$Forecasts = @()
    )

    $E  = [System.Net.WebUtility]
    $sb = [System.Text.StringBuilder]::new(8192)
    $css = Get-ReportCSS

    $activeCount = 0
    if ($null -ne $State['activeAlerts']) { $activeCount = $State.activeAlerts.Count }
    $historyCount = 0
    if ($null -ne $State['alertHistory']) { $historyCount = @($State.alertHistory).Count }
    $todayKey = (Get-Date).ToString('yyyy-MM-dd')
    $collectionsToday = 0
    if ($null -ne $State['dailySummaries'] -and $State.dailySummaries.Contains($todayKey)) {
        $todaySummary = $State.dailySummaries[$todayKey]
        # Use cpuAverage count as proxy for collections
        if ($todaySummary.Contains('cpuAverage')) { $collectionsToday = $todaySummary['cpuAverage']['count'] }
    }

    # Count resolved today
    $resolvedToday = 0
    if ($null -ne $State['alertHistory']) {
        foreach ($hist in $State.alertHistory) {
            $resolvedAt = $null
            if ($hist -is [hashtable]) { $resolvedAt = $hist['resolvedAt'] } else { $resolvedAt = $hist.resolvedAt }
            if ($null -ne $resolvedAt -and "$resolvedAt".StartsWith($todayKey)) { $resolvedToday++ }
        }
    }

    $null = $sb.AppendLine('<!DOCTYPE html><html><head><meta charset="utf-8"><style>')
    $null = $sb.AppendLine($css)
    $null = $sb.AppendLine('</style></head><body style="background:#0d1117;padding:20px;">')
    $null = $sb.AppendLine('<div class="container" style="max-width:700px;">')

    # Header
    $null = $sb.AppendLine('<div style="background:linear-gradient(135deg, #1a5f7a 0%, #0d3b4f 100%);padding:24px;border-radius:12px;margin-bottom:20px;">')
    $null = $sb.AppendLine("<h1 style=`"color:#fff;font-size:22px;margin:0;`">Daily Platform Monitor Digest</h1>")
    $null = $sb.AppendLine("<p style=`"color:rgba(255,255,255,0.8);font-size:13px;margin-top:8px;`">Server: $($E::HtmlEncode($env:COMPUTERNAME)) | $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</p>")
    $null = $sb.AppendLine('</div>')

    # Summary cards grid
    $null = $sb.AppendLine('<div class="card-grid" style="margin-bottom:20px;">')
    $null = $sb.AppendLine("<div class=`"card accent-primary`"><div class=`"value`">$collectionsToday</div><div class=`"label`">Collections Today</div></div>")

    $alertFiredClass = if ($activeCount -gt 0) { 'accent-danger' } else { 'accent-success' }
    $null = $sb.AppendLine("<div class=`"card $alertFiredClass`"><div class=`"value`">$activeCount</div><div class=`"label`">Active Alerts</div></div>")
    $null = $sb.AppendLine("<div class=`"card accent-success`"><div class=`"value`">$resolvedToday</div><div class=`"label`">Resolved Today</div></div>")
    $null = $sb.AppendLine("<div class=`"card accent-primary`"><div class=`"value`">$historyCount</div><div class=`"label`">Total History</div></div>")
    $null = $sb.AppendLine('</div>')

    # Active alerts table
    if ($activeCount -gt 0) {
        $null = $sb.AppendLine('<div class="section" style="margin-bottom:20px;">')
        $null = $sb.AppendLine('<h2>Active Alerts</h2>')
        $null = $sb.AppendLine('<table><tr><th>Requirement</th><th>Severity</th><th>Value</th><th>Since</th></tr>')
        foreach ($alertKey in @($State.activeAlerts.Keys)) {
            $alert = $State.activeAlerts[$alertKey]
            $reqId = $alert['requirementId']
            $sev = $alert['severity']
            $val = $alert['lastValue']
            $since = $alert['firstSeen']
            $sevBadge = Get-StatusBadgeHtml -Status $sev
            $null = $sb.AppendLine("<tr><td>$($E::HtmlEncode($reqId))</td><td>$sevBadge</td><td class=`"num`">$($E::HtmlEncode("$val"))</td><td>$($E::HtmlEncode("$since"))</td></tr>")
        }
        $null = $sb.AppendLine('</table></div>')
    }

    # 7-day trend sparklines for key metrics
    $trendMetrics = @(
        @{ Key = 'cpuAverage'; Label = 'CPU Average %'; WarnTh = 80; CritTh = 95 }
        @{ Key = 'memoryUsed'; Label = 'Memory Used %'; WarnTh = 85; CritTh = 95 }
        @{ Key = 'diskC';      Label = 'Disk C: Used %'; WarnTh = 80; CritTh = 95 }
    )

    $null = $sb.AppendLine('<div class="section" style="margin-bottom:20px;">')
    $null = $sb.AppendLine('<h2>7-Day Trends</h2>')
    $null = $sb.AppendLine('<table><tr><th>Metric</th><th>Sparkline</th><th class="num">Min</th><th class="num">Max</th><th class="num">Avg</th></tr>')

    foreach ($tm in $trendMetrics) {
        $trend = Get-TrendData -State $State -MetricKey $tm.Key -DayRange 7
        if ($null -ne $trend -and @($trend).Count -gt 0) {
            $trendValues = @($trend | ForEach-Object { $_.Avg })
            $sparkHtml = Get-SparklineHtml -Values $trendValues -WarningThreshold $tm.WarnTh -CriticalThreshold $tm.CritTh
            $allMins = ($trend | ForEach-Object { $_.Min } | Measure-Object -Minimum).Minimum
            $allMaxs = ($trend | ForEach-Object { $_.Max } | Measure-Object -Maximum).Maximum
            $allAvgs = [math]::Round(($trend | ForEach-Object { $_.Avg } | Measure-Object -Average).Average, 1)
            $null = $sb.AppendLine("<tr><td>$($E::HtmlEncode($tm.Label))</td><td>$sparkHtml</td><td class=`"num`">$allMins</td><td class=`"num`">$allMaxs</td><td class=`"num`">$allAvgs</td></tr>")
        } else {
            $null = $sb.AppendLine("<tr><td>$($E::HtmlEncode($tm.Label))</td><td>--</td><td class=`"num`">--</td><td class=`"num`">--</td><td class=`"num`">--</td></tr>")
        }
    }
    $null = $sb.AppendLine('</table></div>')

    # Peak records
    if ($null -ne $State['peaks'] -and $State.peaks.Count -gt 0) {
        $null = $sb.AppendLine('<div class="section" style="margin-bottom:20px;">')
        $null = $sb.AppendLine('<h2>All-Time Peak Records</h2>')
        $null = $sb.AppendLine('<table><tr><th>Metric</th><th class="num">Peak Value</th><th>When</th></tr>')
        foreach ($peakKey in @($State.peaks.Keys)) {
            $peak = $State.peaks[$peakKey]
            $pVal = $peak['value']
            $pTime = $peak['timestamp']
            $null = $sb.AppendLine("<tr><td>$($E::HtmlEncode($peakKey))</td><td class=`"num`">$pVal</td><td>$($E::HtmlEncode("$pTime"))</td></tr>")
        }
        $null = $sb.AppendLine('</table></div>')
    }

    # Capacity forecast excerpts
    if ($null -ne $Forecasts -and @($Forecasts).Count -gt 0) {
        $null = $sb.AppendLine('<div class="section" style="margin-bottom:20px;">')
        $null = $sb.AppendLine('<h2>Capacity Forecast Highlights</h2>')
        $null = $sb.AppendLine('<table><tr><th>Metric</th><th class="num">Current</th><th class="num">Days Until Limit</th><th>Trend</th></tr>')
        foreach ($fc in $Forecasts) {
            $fcName = $E::HtmlEncode($fc.MetricName)
            $fcCurrent = [math]::Round($fc.CurrentValue, 1)
            $fcDays = if ($fc.DaysUntilLimit -eq [int]::MaxValue) { 'N/A' } else { $fc.DaysUntilLimit }
            $fcTrend = $E::HtmlEncode($fc.TrendDirection)
            $null = $sb.AppendLine("<tr><td>$fcName</td><td class=`"num`">$fcCurrent</td><td class=`"num`">$fcDays</td><td>$fcTrend</td></tr>")
        }
        $null = $sb.AppendLine('</table></div>')
    }

    # Footer
    $null = $sb.AppendLine("<div class=`"footer`">CyberArk Platform Monitor Daily Digest | $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</div>")
    $null = $sb.AppendLine('</div></body></html>')

    return $sb.ToString()
}

function Send-AlertNotifications {
    <#
    .SYNOPSIS
        Processes notification actions from Update-AlertState and sends emails.
        Updates state only on successful send.
    #>
    [CmdletBinding()]
    param(
        # AllowEmptyCollection: on a normal run NO requirement alert fires, so
        # $Actions is @(). Without this, a Mandatory [array] rejects the empty
        # collection ("Cannot bind argument ... empty collection") and crashes the
        # whole notify path -- breaking emails/digest and, in Scheduled mode, the run.
        [Parameter(Mandatory)]
        [AllowEmptyCollection()]
        [array]$Actions,

        [Parameter(Mandatory)]
        [hashtable]$State,

        [Parameter(Mandatory)]
        [AllowEmptyCollection()]
        [array]$Requirements
    )

    if ($Actions.Count -eq 0) { return }

    # Build requirement lookup by ID
    $reqLookup = @{}
    foreach ($r in $Requirements) {
        $rId = if ($r -is [hashtable]) { $r['id'] } else { $r.id }
        if ($null -ne $rId) { $reqLookup[$rId] = $r }
    }

    # Get default recipients
    $defaultNotifyTo = @()
    $defaultEscalateTo = @()
    if ($null -ne $script:Config -and $null -ne $script:Config.alerting) {
        $alertDefaults = $null
        if ($script:Config.alerting -is [hashtable]) { $alertDefaults = $script:Config.alerting['defaults'] }
        else { $alertDefaults = $script:Config.alerting.defaults }
        if ($null -ne $alertDefaults) {
            if ($alertDefaults -is [hashtable]) {
                $defaultNotifyTo = @($alertDefaults['notifyTo'])
                $defaultEscalateTo = @($alertDefaults['escalateTo'])
            } else {
                $defaultNotifyTo = @($alertDefaults.notifyTo)
                $defaultEscalateTo = @($alertDefaults.escalateTo)
            }
        }
    }

    foreach ($action in $Actions) {
        $req = $reqLookup[$action.requirementId]
        if ($null -eq $req) { continue }

        # Determine recipients
        $reqNotification = if ($req -is [hashtable]) { $req['notification'] } else { $req.notification }
        $notifyTo = @()
        $escalateTo = @()
        if ($null -ne $reqNotification) {
            if ($reqNotification -is [hashtable]) {
                $notifyTo = @($reqNotification['notifyTo'])
                $escalateTo = @($reqNotification['escalateTo'])
            } else {
                $notifyTo = @($reqNotification.notifyTo)
                $escalateTo = @($reqNotification.escalateTo)
            }
        }
        # Fall back to defaults if empty
        $notifyTo = @($notifyTo | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
        $escalateTo = @($escalateTo | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
        if ($notifyTo.Count -eq 0) { $notifyTo = @($defaultNotifyTo | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }) }
        if ($escalateTo.Count -eq 0) { $escalateTo = @($defaultEscalateTo | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }) }

        switch ($action.type) {
            { $_ -in 'NewAlert','Reminder' } {
                if ($notifyTo.Count -eq 0) {
                    Write-Log -Message "No recipients for $($action.type) on $($action.alertKey) -- skipping" -Level Warn -Color Yellow
                    continue
                }
                $evalObj = [PSCustomObject]@{
                    RequirementId = $action.requirementId
                    Status        = $action.severity
                    CurrentValue  = $action.currentValue
                    Threshold     = $null
                    MetricPath    = $action.metricPath
                }
                $body = New-AlertEmailBody -Requirement $req -EvalResult $evalObj -State $State
                $prefix = if ($_ -eq 'Reminder') { 'REMINDER: ' } else { '' }
                $sent = Send-MonitorEmail -To $notifyTo -Subject "${prefix}[$($action.severity)] $($env:COMPUTERNAME): $($action.requirementId) - Platform Monitor" -HtmlBody $body -Priority $(if ($action.severity -eq 'Critical') { 'High' } else { 'Normal' })
                if ($sent -and $State.activeAlerts.Contains($action.alertKey)) {
                    $State.activeAlerts[$action.alertKey]['lastNotifiedAt'] = (Get-Date).ToUniversalTime().ToString('o')
                    $State.activeAlerts[$action.alertKey]['notificationsSent'] = $State.activeAlerts[$action.alertKey]['notificationsSent'] + 1
                }
            }
            'Escalation' {
                # @() MUST wrap the whole if-expression: `$x = if(...){ a } else { b }`
                # emits zero objects (=> $null, not an empty array) when the chosen
                # branch is empty, so $recipients.Count would throw under StrictMode.
                $recipients = @(if ($escalateTo.Count -gt 0) { $escalateTo } else { $notifyTo })
                if ($recipients.Count -eq 0) {
                    Write-Log -Message "No escalation recipients for $($action.alertKey) -- skipping" -Level Warn -Color Yellow
                    continue
                }
                $evalObj = [PSCustomObject]@{
                    RequirementId = $action.requirementId
                    Status        = $action.severity
                    CurrentValue  = $action.currentValue
                    Threshold     = $null
                    MetricPath    = $action.metricPath
                }
                $body = New-AlertEmailBody -Requirement $req -EvalResult $evalObj -State $State -IsEscalation
                $sent = Send-MonitorEmail -To $recipients -Subject "ESCALATION: [$($action.severity)] $($env:COMPUTERNAME): $($action.requirementId) - Platform Monitor" -HtmlBody $body -Priority 'High'
                if ($sent -and $State.activeAlerts.Contains($action.alertKey)) {
                    $State.activeAlerts[$action.alertKey]['lastNotifiedAt'] = (Get-Date).ToUniversalTime().ToString('o')
                    $State.activeAlerts[$action.alertKey]['notificationsSent'] = $State.activeAlerts[$action.alertKey]['notificationsSent'] + 1
                }
            }
            'Recovery' {
                if ($notifyTo.Count -eq 0) { continue }
                # Build history entry from the alert data
                $histEntry = [ordered]@{
                    requirementId     = $action.requirementId
                    durationMinutes   = 0
                    peakValue         = $null
                    notificationsSent = 0
                    recoveryValue     = $action.currentValue
                }
                if ($null -ne $action.alert) {
                    $a = $action.alert
                    if ($null -ne $a['firstSeen']) {
                        try {
                            $firstSeen = [datetime]::Parse($a['firstSeen']).ToUniversalTime()
                            $histEntry['durationMinutes'] = [math]::Round(((Get-Date).ToUniversalTime() - $firstSeen).TotalMinutes, 1)
                        } catch {}
                    }
                    if ($null -ne $a['lastValue']) { $histEntry['peakValue'] = $a['lastValue'] }
                    if ($null -ne $a['notificationsSent']) { $histEntry['notificationsSent'] = $a['notificationsSent'] }
                }
                $body = New-RecoveryEmailBody -Requirement $req -HistoryEntry $histEntry
                $null = Send-MonitorEmail -To $notifyTo -Subject "RECOVERED: $($env:COMPUTERNAME): $($action.requirementId) - Platform Monitor" -HtmlBody $body
            }
        }
    }
}

function Test-DigestDue {
    <#
    .SYNOPSIS
        Returns $true if the current time matches the digest schedule and digest has not been sent today.
    #>
    [CmdletBinding()]
    [OutputType([bool])]
    param(
        [Parameter(Mandatory)]
        [hashtable]$State
    )

    # Check if digest is enabled
    $digestEnabled = $false
    $digestTime = '07:00'
    if ($null -ne $script:Config -and $null -ne $script:Config.alerting) {
        $digest = $null
        if ($script:Config.alerting -is [hashtable]) { $digest = $script:Config.alerting['digest'] }
        else { $digest = $script:Config.alerting.digest }
        if ($null -ne $digest) {
            if ($digest -is [hashtable]) {
                $digestEnabled = [bool]$digest['enabled']
                if ($null -ne $digest['time']) { $digestTime = $digest['time'] }
            } else {
                $digestEnabled = [bool]$digest.enabled
                if ($null -ne $digest.time) { $digestTime = $digest.time }
            }
        }
    }

    if (-not $digestEnabled) { return $false }

    # Parse target hour:minute
    $parts = $digestTime -split ':'
    $targetHour = 7
    $targetMinute = 0
    try {
        $targetHour   = [int]$parts[0]
        $targetMinute = if ($parts.Count -gt 1) { [int]$parts[1] } else { 0 }
    }
    catch { }

    $now = Get-Date
    # Due once the target LOCAL time has passed today. A narrow +/- minute window
    # can be missed entirely by coarse polling cadences (and is unreachable
    # across an hour boundary); the sent-today guard below prevents re-sends.
    $targetToday = $now.Date.AddHours($targetHour).AddMinutes($targetMinute)
    if ($now -lt $targetToday) { return $false }

    # Check if already sent today. digestLastSent is stored as UTC ISO-8601 --
    # convert to LOCAL date before comparing, otherwise on UTC+N timezones the
    # guard never matches and the digest re-sends on every poll in the window.
    $todayKey = $now.ToString('yyyy-MM-dd')
    if ($null -ne $State['digestLastSent']) {
        $lastSentLocalDay = ''
        try {
            $lastSentLocalDay = [datetime]::Parse("$($State['digestLastSent'])").ToLocalTime().ToString('yyyy-MM-dd')
        }
        catch {
            $lastSentLocalDay = "$($State['digestLastSent'])".Substring(0, [math]::Min(10, "$($State['digestLastSent'])".Length))
        }
        if ($lastSentLocalDay -eq $todayKey) { return $false }
    }

    return $true
}

function Invoke-DailyDigest {
    <#
    .SYNOPSIS
        Build and send the daily digest email. Updates state.digestLastSent.
    #>
    [CmdletBinding()]
    param()

    $state = $script:PlatformState
    if ($null -eq $state) {
        Write-Log -Message 'No platform state available for digest' -Level Warn -Color Yellow
        return
    }

    # Get digest recipients
    $recipients = @()
    if ($null -ne $script:Config -and $null -ne $script:Config.alerting) {
        $digest = $null
        if ($script:Config.alerting -is [hashtable]) { $digest = $script:Config.alerting['digest'] }
        else { $digest = $script:Config.alerting.digest }
        if ($null -ne $digest) {
            $digestRecipients = $null
            if ($digest -is [hashtable]) { $digestRecipients = $digest['recipients'] }
            else { $digestRecipients = $digest.recipients }
            if ($null -ne $digestRecipients) { $recipients = @($digestRecipients | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }) }
        }
    }

    # Fall back to defaults
    if ($recipients.Count -eq 0) {
        $alertDefaults = $null
        if ($script:Config.alerting -is [hashtable]) { $alertDefaults = $script:Config.alerting['defaults'] }
        else { $alertDefaults = $script:Config.alerting.defaults }
        if ($null -ne $alertDefaults) {
            $defNotify = if ($alertDefaults -is [hashtable]) { $alertDefaults['notifyTo'] } else { $alertDefaults.notifyTo }
            if ($null -ne $defNotify) { $recipients = @($defNotify | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }) }
        }
    }

    if ($recipients.Count -eq 0) {
        Write-Log -Message 'No digest recipients configured -- skipping digest' -Level Warn -Color Yellow
        return
    }

    # Check sendOnlyIfIssues
    $sendOnlyIfIssues = $false
    if ($null -ne $script:Config.alerting) {
        $digest = $null
        if ($script:Config.alerting -is [hashtable]) { $digest = $script:Config.alerting['digest'] }
        else { $digest = $script:Config.alerting.digest }
        if ($null -ne $digest) {
            if ($digest -is [hashtable]) { $sendOnlyIfIssues = [bool]$digest['sendOnlyIfIssues'] }
            else { $sendOnlyIfIssues = [bool]$digest.sendOnlyIfIssues }
        }
    }

    $activeCount = 0
    if ($null -ne $state['activeAlerts']) { $activeCount = $state.activeAlerts.Count }
    if ($sendOnlyIfIssues -and $activeCount -eq 0) {
        Write-Log -Message 'No active alerts and sendOnlyIfIssues is true -- skipping digest' -Level Info -Color Gray
        $state['digestLastSent'] = (Get-Date).ToUniversalTime().ToString('o')
        return
    }

    $body = New-DigestEmailBody -State $state
    $sent = Send-MonitorEmail -To $recipients -Subject "Daily Platform Monitor Digest - $($env:COMPUTERNAME) - $(Get-Date -Format 'yyyy-MM-dd')" -HtmlBody $body

    if ($sent) {
        $state['digestLastSent'] = (Get-Date).ToUniversalTime().ToString('o')
        Write-Log -Message 'Daily digest sent successfully' -Level Info -Color Green
    } else {
        Write-Log -Message 'Daily digest send failed' -Level Warn -Color Yellow
    }
}

#endregion

#region Mock Data Generator

function Get-MockData {
    <#
    .SYNOPSIS
        Returns realistic mock data for testing on non-Windows platforms.
    .PARAMETER DataType
        Type of mock data: SystemHealth, ServiceResiliency, CertificateHealth, ServerCapacity,
        CPMHealth, PSMHealth, Connectivity, WebDriverHealth, MockRequirements, MockPlatformState
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)]
        [ValidateSet('SystemHealth','ServiceResiliency','CertificateHealth','ServerCapacity',
                     'CPMHealth','PSMHealth','Connectivity','WebDriverHealth','PVWAHealth','CALogScan',
                     'MockRequirements','MockPlatformState')]
        [string]$DataType
    )

    $timestamp  = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
    $serverName = if ($env:COMPUTERNAME) { $env:COMPUTERNAME } else { 'MOCK-SERVER' }

    switch ($DataType) {
        'SystemHealth' {
            return [PSCustomObject]@{
                Status     = 'OK'
                Hostname   = $serverName
                Domain     = 'MOCK.DOMAIN'
                OSVersion  = 'Windows Server 2022 Standard 10.0.20348'
                LastBootTime       = (Get-Date).AddDays(-15).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
                UptimeDays         = 15
                CPU = [PSCustomObject]@{
                    Current = 25.5
                    Average = 30.2
                    Peak    = 45.8
                    Status  = 'OK'
                }
                Memory = [PSCustomObject]@{
                    TotalGB     = 64.0
                    AvailableGB = 32.5
                    UsedPercent = 49.2
                    Status      = 'OK'
                }
                Disks = @(
                    [PSCustomObject]@{ DriveLetter = 'C:'; SizeGB = 500.0; FreeGB = 250.0; UsedPercent = 50.0; Status = 'OK' }
                    [PSCustomObject]@{ DriveLetter = 'D:'; SizeGB = 1000.0; FreeGB = 600.0; UsedPercent = 40.0; Status = 'OK' }
                )
                InstalledComponents = @(
                    [PSCustomObject]@{
                        ComponentName = 'CyberArk Password Vault'
                        Version       = '13.2.0.12'
                        InstallPath   = 'C:\Program Files (x86)\PrivateArk\Server'
                        ServiceName   = 'PrivateArk Server'
                        IsInstalled   = $true
                    }
                )
                RdpSessions = [PSCustomObject]@{
                    Total = 4; Active = 2; Disconnected = 2; Other = 0
                    ShadowUsers = 2; ShadowDisconnected = 1
                    Sessions = @(
                        [PSCustomObject]@{ UserName = 'admin.jones';      SessionName = 'rdp-tcp#12'; Id = '2'; State = 'Active';       IdleTime = '.';    LogonTime = '7/9/2026 8:02 AM'; IsShadowUser = $false; IsCurrent = $true }
                        [PSCustomObject]@{ UserName = 'PSMShadowUser01';  SessionName = 'rdp-tcp#13'; Id = '3'; State = 'Active';       IdleTime = '5';    LogonTime = '7/9/2026 9:15 AM'; IsShadowUser = $true;  IsCurrent = $false }
                        [PSCustomObject]@{ UserName = 'PSMShadowUser02';  SessionName = '';           Id = '4'; State = 'Disconnected'; IdleTime = '2+03:11'; LogonTime = '7/7/2026 1:40 PM'; IsShadowUser = $true;  IsCurrent = $false }
                        [PSCustomObject]@{ UserName = 'svc.deploy';       SessionName = '';           Id = '5'; State = 'Disconnected'; IdleTime = '9:26'; LogonTime = '7/9/2026 6:01 AM'; IsShadowUser = $false; IsCurrent = $false }
                    )
                    Error = $null
                }
                CheckedAt       = $timestamp
                ServerName      = $serverName
                CorrelationID   = $script:CorrelationID
                Duration        = '00:00:01.250'
                IsMockData      = $true
                ErrorMessage    = $null
            }
        }

        'ServiceResiliency' {
            return [PSCustomObject]@{
                Status           = 'OK'
                TotalServices    = 3
                HealthyServices  = 2
                DegradedServices = 1
                StoppedServices  = 0
                Services = @(
                    [PSCustomObject]@{
                        ServiceName         = 'PrivateArk Server'
                        DisplayName         = 'PrivateArk Server'
                        Status              = 'Running'
                        StartType           = 'Automatic'
                        PID                 = 1234
                        MemoryMB            = 512.5
                        CpuTimeSeconds      = 3600
                        RestartCount        = 2
                        LastStartTime       = (Get-Date).AddDays(-15).ToString('yyyy-MM-dd HH:mm:ss')
                        UptimeHours         = 360.5
                        MTTR                = 5.2
                        AvailabilityPercent = 99.95
                        StatusDetail        = 'Healthy'
                    }
                    [PSCustomObject]@{
                        ServiceName         = 'CyberArk Password Manager'
                        DisplayName         = 'CyberArk Password Manager'
                        Status              = 'Running'
                        StartType           = 'Automatic'
                        PID                 = 5678
                        MemoryMB            = 256.3
                        CpuTimeSeconds      = 1800
                        RestartCount        = 1
                        LastStartTime       = (Get-Date).AddDays(-10).ToString('yyyy-MM-dd HH:mm:ss')
                        UptimeHours         = 240.2
                        MTTR                = 3.5
                        AvailabilityPercent = 99.98
                        StatusDetail        = 'Healthy'
                    }
                    [PSCustomObject]@{
                        ServiceName         = 'CyberArk Central Policy Manager Scanner'
                        DisplayName         = 'CyberArk Central Policy Manager Scanner'
                        Status              = 'Running'
                        StartType           = 'Automatic'
                        PID                 = 9012
                        MemoryMB            = 128.7
                        CpuTimeSeconds      = 900
                        RestartCount        = 12
                        LastStartTime       = (Get-Date).AddDays(-5).ToString('yyyy-MM-dd HH:mm:ss')
                        UptimeHours         = 120.8
                        MTTR                = 8.3
                        AvailabilityPercent = 98.50
                        StatusDetail        = 'Degraded - High restart count'
                    }
                )
                CheckedAt       = $timestamp
                ServerName      = $serverName
                CorrelationID   = $script:CorrelationID
                Duration        = '00:00:02.100'
                IsMockData      = $true
                ErrorMessage    = $null
            }
        }

        'CertificateHealth' {
            return [PSCustomObject]@{
                Status            = 'Warning'
                TotalCertificates = 5
                ExpiredCount      = 0
                CriticalCount     = 1
                WarningCount      = 1
                OKCount           = 3
                Certificates = @(
                    [PSCustomObject]@{ Subject = 'CN=CyberArk Vault CA'; Issuer = 'CN=CyberArk Root CA'; Thumbprint = 'A1B2C3D4E5F6A1B2C3D4E5F6A1B2C3D4E5F6A1B2'; NotBefore = (Get-Date).AddYears(-2).ToString('yyyy-MM-dd'); NotAfter = (Get-Date).AddDays(90).ToString('yyyy-MM-dd'); DaysUntilExpiry = 90; RiskLevel = 'OK'; Store = 'LocalMachine\My' }
                    [PSCustomObject]@{ Subject = 'CN=PrivateArk Server'; Issuer = 'CN=CyberArk Vault CA'; Thumbprint = 'B2C3D4E5F6B2C3D4E5F6B2C3D4E5F6B2C3D4E5F6'; NotBefore = (Get-Date).AddYears(-1).ToString('yyyy-MM-dd'); NotAfter = (Get-Date).AddDays(25).ToString('yyyy-MM-dd'); DaysUntilExpiry = 25; RiskLevel = 'Warning'; Store = 'LocalMachine\My' }
                    [PSCustomObject]@{ Subject = 'CN=PVWA Server'; Issuer = 'CN=CyberArk Vault CA'; Thumbprint = 'C3D4E5F6C3D4E5F6C3D4E5F6C3D4E5F6C3D4E5F6'; NotBefore = (Get-Date).AddYears(-1).ToString('yyyy-MM-dd'); NotAfter = (Get-Date).AddDays(5).ToString('yyyy-MM-dd'); DaysUntilExpiry = 5; RiskLevel = 'Critical'; Store = 'LocalMachine\My' }
                    [PSCustomObject]@{ Subject = 'CN=CyberArk Root CA'; Issuer = 'CN=CyberArk Root CA'; Thumbprint = 'D4E5F6D4E5F6D4E5F6D4E5F6D4E5F6D4E5F6D4E5'; NotBefore = (Get-Date).AddYears(-3).ToString('yyyy-MM-dd'); NotAfter = (Get-Date).AddYears(2).ToString('yyyy-MM-dd'); DaysUntilExpiry = 730; RiskLevel = 'OK'; Store = 'LocalMachine\Root' }
                    [PSCustomObject]@{ Subject = 'CN=PSM Server'; Issuer = 'CN=CyberArk Vault CA'; Thumbprint = 'E5F6E5F6E5F6E5F6E5F6E5F6E5F6E5F6E5F6E5F6'; NotBefore = (Get-Date).AddYears(-1).ToString('yyyy-MM-dd'); NotAfter = (Get-Date).AddDays(180).ToString('yyyy-MM-dd'); DaysUntilExpiry = 180; RiskLevel = 'OK'; Store = 'LocalMachine\My' }
                )
                CheckedAt     = $timestamp
                ServerName    = $serverName
                CorrelationID = $script:CorrelationID
                Duration      = '00:00:00.800'
                IsMockData    = $true
                ErrorMessage  = $null
            }
        }

        'ServerCapacity' {
            return [PSCustomObject]@{
                Status = 'OK'
                CPU = [PSCustomObject]@{ Current = 35.2; Average = 38.5; Peak = 52.3; HeadroomPercent = 61.5 }
                Memory = [PSCustomObject]@{ TotalGB = 64.0; UsedGB = 28.5; UsedPercent = 44.5; HeadroomPercent = 55.5 }
                DiskIO = [PSCustomObject]@{ ReadBytesPerSec = 1048576.0; WriteBytesPerSec = 524288.0; QueueLength = 0.5 }
                NetworkConnections = @(
                    [PSCustomObject]@{ Port = 1858; Protocol = 'TCP'; Count = 15; Description = 'CyberArk Vault' }
                    [PSCustomObject]@{ Port = 443;  Protocol = 'TCP'; Count = 42; Description = 'HTTPS' }
                    [PSCustomObject]@{ Port = 3389; Protocol = 'TCP'; Count = 3;  Description = 'RDP' }
                )
                CheckedAt     = $timestamp
                ServerName    = $serverName
                CorrelationID = $script:CorrelationID
                Duration      = '00:00:03.500'
                IsMockData    = $true
                ErrorMessage  = $null
            }
        }

        'CPMHealth' {
            return [PSCustomObject]@{
                Status          = 'Healthy'
                Errors          = @()
                ErrorCount      = 0
                CheckedAt       = $timestamp
                LogPath         = 'C:\Program Files (x86)\CyberArk\Password Manager\Logs\pm_error.log'
                LogPathSource   = 'Mock'
                LookbackMinutes = 60
                ServerName      = $serverName
                CorrelationID   = $script:CorrelationID
                Duration        = '00:00:00.150'
                IsMockData      = $true
                ErrorMessage    = $null
                PluginTotal     = 214
                PluginUnhealthy = 0
                PluginPath      = 'C:\Program Files (x86)\CyberArk\Password Manager\bin\Plugins'
            }
        }

        'PSMHealth' {
            return [PSCustomObject]@{
                Status            = 'Healthy'
                CheckedAt         = $timestamp
                CorrelationID     = $script:CorrelationID
                ServerName        = $serverName
                Component         = 'PSM'
                ServiceStatus = [PSCustomObject]@{
                    Name        = 'CyberArk Privileged Session Manager'
                    DisplayName = 'CyberArk Privileged Session Manager'
                    Status      = 'Running'
                    StartType   = 'Automatic'
                    Found       = $true
                }
                VaultConnectivity = [PSCustomObject]@{
                    Address   = 'vault01.corp.local'
                    Port      = 1858
                    Reachable = $true
                    Latency   = '3ms'
                    Status    = 'Connected'
                }
                ShadowUserErrors  = @()
                CategorizedErrors = @()
                SystemErrorCount  = 0
                UserErrorCount    = 2
                ErrorCategories = [PSCustomObject]@{
                    Browser = 0
                    RDP     = 0
                    SSH     = 0
                    User    = 2
                    Unknown = 0
                }
                Duration      = '00:00:00.420'
                IsMockData    = $true
                ErrorMessage  = $null
                ConnComponentsTotal   = 6
                ConnComponentsInvalid = 0
                RecordingStatus       = 'OK'
                RecordingFreeGB       = 342.7
                RecordingPendingCount = 4
                RecordingOldestPendingHours = 0.6
            }
        }

        'Connectivity' {
            return @(
                [PSCustomObject]@{ Target = 'vault01.corp.local'; Port = 1858; Reachable = $true;  LatencyMs = 3;    Status = 'Connected';    Description = 'CyberArk Vault'; IsMockData = $true }
                [PSCustomObject]@{ Target = 'psm01.corp.local';   Port = 3389; Reachable = $true;  LatencyMs = 8;    Status = 'Connected';    Description = 'PSM RDP';        IsMockData = $true }
                [PSCustomObject]@{ Target = 'psm02.corp.local';   Port = 3389; Reachable = $false; LatencyMs = $null; Status = 'Unreachable'; Description = 'PSM RDP';        IsMockData = $true }
            )
        }

        'WebDriverHealth' {
            return @(
                [PSCustomObject]@{
                    Browser        = 'Chrome'
                    Compatible     = $true
                    BrowserVersion = '120.0.6099.224'
                    DriverVersion  = '120.0.6099.109'
                    DriverPath     = 'C:\Program Files (x86)\CyberArk\PSM\Components\chromedriver.exe'
                    DriverExists   = $true
                    HashMatch      = $true
                    Message        = 'Browser and driver major versions match: 120'
                    IsMockData     = $true
                }
                [PSCustomObject]@{
                    Browser        = 'Edge'
                    Compatible     = $false
                    BrowserVersion = '119.0.2151.97'
                    DriverVersion  = '118.0.2088.46'
                    DriverPath     = 'C:\Program Files (x86)\CyberArk\PSM\Components\msedgedriver.exe'
                    DriverExists   = $true
                    HashMatch      = $false
                    Message        = 'Browser major version (119) does not match driver major version (118)'
                    IsMockData     = $true
                }
            )
        }

        'PVWAHealth' {
            return [PSCustomObject]@{
                Status             = 'OK'
                IISServiceStatus   = 'Running'
                AppPoolStatus      = 'Started'
                WorkerProcessCount = 2
                MemoryUsageMB      = 1536.5
                RecentRecycleCount = 0
                BindingStatus      = 'OK'
                LogFileSizeMB      = 128.4
                FallbackMode       = $false
                CheckedAt          = $timestamp
                ServerName         = $serverName
                Component          = 'PVWA'
                CorrelationID      = $script:CorrelationID
                Duration           = '00:00:00.200'
                IsMockData         = $true
                ErrorMessage       = $null
            }
        }
        'CALogScan' {
            return [PSCustomObject]@{
                Status        = 'Warning'
                Sources       = @(
                    [PSCustomObject]@{ Name = 'Vault';            Format = 'ITALog';   Path = 'C:\Program Files (x86)\PrivateArk\Server\Logs\ITALog.log'; Found = $true; ErrorCount = 2; WarnCount = 5 }
                    [PSCustomObject]@{ Name = 'ConnectorManager'; Format = 'BLService'; Path = 'C:\Program Files (x86)\CyberArk\Password Manager\Logs\BLServiceApp.log'; Found = $true; ErrorCount = 0; WarnCount = 1 }
                    [PSCustomObject]@{ Name = 'PVWA';             Format = 'log4net';  Path = $null; Found = $false; ErrorCount = 0; WarnCount = 0 }
                )
                TotalErrors     = 2
                TotalWarnings   = 6
                MaxSourceErrors = 2
                CheckedAt     = $timestamp
                ServerName    = $serverName
                CorrelationID = $script:CorrelationID
                Duration      = '00:00:00.300'
                IsMockData    = $true
                ErrorMessage  = $null
            }
        }
        'MockRequirements' {
            # Returns the default requirements -- same as Get-DefaultRequirements
            # but ensures mock data testing can reference them
            return (Get-DefaultRequirements)
        }

        'MockPlatformState' {
            # Returns a populated state with 7 days of mock daily summaries, active alerts,
            # alert history, and peak records for testing email templates and report sections
            $mockState = Get-EmptyState
            $now = Get-Date

            # Generate 7 days of daily summaries with realistic data
            for ($d = 6; $d -ge 0; $d--) {
                $dateKey = $now.AddDays(-$d).ToString('yyyy-MM-dd')
                $baselineCpu = 25 + (Get-Random -Minimum 0 -Maximum 30)
                $baselineMem = 40 + (Get-Random -Minimum 0 -Maximum 25)
                $baselineDisk = 45 + (Get-Random -Minimum 0 -Maximum 15)

                $mockState.dailySummaries[$dateKey] = [ordered]@{
                    cpuAverage = [ordered]@{
                        min    = [math]::Round($baselineCpu * 0.6, 1)
                        max    = [math]::Round($baselineCpu * 1.8, 1)
                        avg    = [math]::Round($baselineCpu, 1)
                        sum    = [math]::Round($baselineCpu * 96, 1)
                        count  = 96
                        peakAt = $now.AddDays(-$d).AddHours(14).ToUniversalTime().ToString('o')
                    }
                    memoryUsed = [ordered]@{
                        min    = [math]::Round($baselineMem * 0.85, 1)
                        max    = [math]::Round($baselineMem * 1.3, 1)
                        avg    = [math]::Round($baselineMem, 1)
                        sum    = [math]::Round($baselineMem * 96, 1)
                        count  = 96
                        peakAt = $now.AddDays(-$d).AddHours(10).ToUniversalTime().ToString('o')
                    }
                    diskC = [ordered]@{
                        min    = [math]::Round($baselineDisk - 2, 1)
                        max    = [math]::Round($baselineDisk + 3, 1)
                        avg    = [math]::Round($baselineDisk, 1)
                        sum    = [math]::Round($baselineDisk * 96, 1)
                        count  = 96
                        peakAt = $now.AddDays(-$d).AddHours(16).ToUniversalTime().ToString('o')
                    }
                    connections1858 = [ordered]@{
                        min    = 1
                        max    = 1
                        avg    = 1.0
                        sum    = 96
                        count  = 96
                        peakAt = $now.AddDays(-$d).AddHours(8).ToUniversalTime().ToString('o')
                    }
                }
            }

            # Add one active alert (Warning on CPU)
            $alertFirstSeen = $now.AddHours(-2).ToUniversalTime().ToString('o')
            $mockState.activeAlerts['REQ-001::CPU.Average'] = [ordered]@{
                requirementId     = 'REQ-001'
                severity          = 'Warning'
                firstSeen         = $alertFirstSeen
                lastSeen          = $now.ToUniversalTime().ToString('o')
                lastValue         = 82.5
                occurrences       = 12
                lastNotifiedAt    = $now.AddMinutes(-45).ToUniversalTime().ToString('o')
                notificationsSent = 1
                escalated         = $false
            }

            # Add alert history (two resolved alerts)
            $mockState.alertHistory = @(
                [ordered]@{
                    requirementId     = 'REQ-002'
                    alertKey          = 'REQ-002::Memory.UsedPercent'
                    severity          = 'Warning'
                    firstSeen         = $now.AddDays(-3).AddHours(-4).ToUniversalTime().ToString('o')
                    lastSeen          = $now.AddDays(-3).AddHours(-1).ToUniversalTime().ToString('o')
                    resolvedAt        = $now.AddDays(-3).ToUniversalTime().ToString('o')
                    durationMinutes   = 240
                    peakValue         = 91.2
                    occurrences       = 48
                    notificationsSent = 3
                    recoveryValue     = 72.5
                }
                [ordered]@{
                    requirementId     = 'REQ-005'
                    alertKey          = 'REQ-005::MinDaysToExpiry'
                    severity          = 'Critical'
                    firstSeen         = $now.AddDays(-5).ToUniversalTime().ToString('o')
                    lastSeen          = $now.AddDays(-4).ToUniversalTime().ToString('o')
                    resolvedAt        = $now.AddDays(-4).ToUniversalTime().ToString('o')
                    durationMinutes   = 1440
                    peakValue         = 3
                    occurrences       = 96
                    notificationsSent = 5
                    recoveryValue     = 45
                }
            )

            # Set peaks
            $mockState.peaks = [ordered]@{
                cpuAverage = [ordered]@{
                    value     = 94.2
                    timestamp = $now.AddDays(-2).AddHours(14).ToUniversalTime().ToString('o')
                }
                memoryUsed = [ordered]@{
                    value     = 91.2
                    timestamp = $now.AddDays(-3).AddHours(10).ToUniversalTime().ToString('o')
                }
                diskC = [ordered]@{
                    value     = 62.3
                    timestamp = $now.AddDays(-1).AddHours(16).ToUniversalTime().ToString('o')
                }
            }

            # Set last collection timestamps
            $mockState.lastCollection = [ordered]@{
                hot  = $now.AddMinutes(-1).ToUniversalTime().ToString('o')
                warm = $now.AddMinutes(-3).ToUniversalTime().ToString('o')
                cool = $now.AddMinutes(-10).ToUniversalTime().ToString('o')
            }

            return $mockState
        }
    }
}

#endregion

#region Installed Components Detection

function Get-InstalledComponents {
    <#
    .SYNOPSIS
        Detects installed CyberArk components on the local server via registry and service discovery.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject[]])]
    param()

    $components = @()

    $componentMap = @{
        'PrivateArk Server' = @{
            Name         = 'CyberArk Password Vault'
            RegistryPath = 'HKLM:\SOFTWARE\Wow6432Node\PrivateArk\Server'
            ServiceName  = 'PrivateArk Server'
        }
        'PrivateArk Database' = @{
            Name         = 'CyberArk Vault Database'
            RegistryPath = 'HKLM:\SOFTWARE\Wow6432Node\PrivateArk\Server'
            ServiceName  = 'PrivateArk Database'
        }
        'CyberArk Password Manager' = @{
            Name         = 'CyberArk Password Manager (CPM)'
            RegistryPath = 'HKLM:\SOFTWARE\Wow6432Node\CyberArk\CyberArk Password Manager'
            ServiceName  = 'CyberArk Password Manager'
        }
        'CyberArk Central Policy Manager Scanner' = @{
            Name         = 'CyberArk CPM Scanner'
            RegistryPath = 'HKLM:\SOFTWARE\Wow6432Node\CyberArk\CyberArk Password Manager'
            ServiceName  = 'CyberArk Central Policy Manager Scanner'
        }
        'CyberArk Privileged Session Manager' = @{
            Name         = 'CyberArk PSM'
            RegistryPath = 'HKLM:\SOFTWARE\Wow6432Node\CyberArk\CyberArk Privileged Session Manager'
            ServiceName  = 'CyberArk Privileged Session Manager'
        }
        'CyberArk Application Password Provider' = @{
            Name         = 'CyberArk APP Provider'
            RegistryPath = 'HKLM:\SOFTWARE\Wow6432Node\AppProviderForCyberArk'
            ServiceName  = 'CyberArk Application Password Provider'
        }
        'CyberArk Vault Disaster Recovery' = @{
            Name         = 'CyberArk DR'
            RegistryPath = 'HKLM:\SOFTWARE\Wow6432Node\PrivateArk\Replicate'
            ServiceName  = 'CyberArk Vault Disaster Recovery'
        }
        'CyberArk Event Notification Engine' = @{
            Name         = 'CyberArk ENE'
            RegistryPath = 'HKLM:\SOFTWARE\Wow6432Node\CyberArk\CyberArk Event Notification Engine'
            ServiceName  = 'CyberArk Event Notification Engine'
        }
        'CyberArk Logic Container' = @{
            Name         = 'CyberArk Logic Container'
            RegistryPath = 'HKLM:\SOFTWARE\Wow6432Node\CyberArk\LogicContainer'
            ServiceName  = 'CyberArk Logic Container'
        }
    }

    foreach ($key in $componentMap.Keys) {
        $component   = $componentMap[$key]
        $isInstalled = $false
        $version     = 'Unknown'
        $installPath = 'Unknown'

        try {
            $service = Get-Service -Name $component.ServiceName -ErrorAction SilentlyContinue
            if ($service) {
                $isInstalled = $true

                if (Test-Path -Path $component.RegistryPath) {
                    $regKey = Get-ItemProperty -Path $component.RegistryPath -ErrorAction SilentlyContinue
                    if ($regKey) {
                        if ($regKey.Version)    { $version     = $regKey.Version }
                        if ($regKey.InstallDir) { $installPath = $regKey.InstallDir }
                        elseif ($regKey.Path)   { $installPath = $regKey.Path }
                    }
                }
            }
        }
        catch { continue }

        if ($isInstalled) {
            $components += [PSCustomObject]@{
                ComponentName = $component.Name
                Version       = $version
                InstallPath   = $installPath
                ServiceName   = $component.ServiceName
                IsInstalled   = $isInstalled
            }
        }
    }

    return $components
}

#endregion

#region System Health Collection

function Get-RdpSessionSnapshot {
    <#
    .SYNOPSIS
        Snapshot of interactive/RDP sessions via quser: Active/Disconnected
        counts, PSM shadow-user counts, and per-session detail (user, id, state,
        idle, logon time). Collected alongside CPU/memory in SystemHealth so
        resource usage can be correlated with user count at the same interval,
        and disconnected sessions can be trended to spot orphaned logons.
        Never throws; on failure returns zeros with Error populated.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param([string[]]$ShadowUserPrefixes = @('PSMShadowUser', 'PSM-'))

    $snap = [PSCustomObject]@{
        Total              = 0
        Active             = 0
        Disconnected       = 0
        Other              = 0
        ShadowUsers        = 0
        ShadowDisconnected = 0
        Sessions           = @()
        Error              = $null
    }

    try {
        # Via cmd so the stderr redirect cannot trip $ErrorActionPreference=Stop
        # (quser writes "No User exists..." to stderr and exits 1 when idle).
        $raw = @(cmd /c 'quser 2>nul')
        if ($raw.Count -le 1) { return $snap }

        foreach ($line in ($raw | Select-Object -Skip 1)) {
            if ([string]::IsNullOrWhiteSpace($line)) { continue }
            $isCurrent = $line.StartsWith('>')
            $l = $line.TrimStart('>', ' ')
            # Columns are space-padded; SESSIONNAME is EMPTY for disconnected
            # sessions, so split on 2+ spaces and branch on the field count.
            $parts = @($l -split '\s{2,}' | Where-Object { $_ -ne '' })
            if ($parts.Count -lt 4) { continue }
            $user = $parts[0]
            if ($parts.Count -ge 6) {
                $sessionName = $parts[1]; $id = $parts[2]; $state = $parts[3]; $idle = $parts[4]
                $logon = ($parts[5..($parts.Count - 1)] -join ' ')
            }
            else {
                $sessionName = ''; $id = $parts[1]; $state = $parts[2]; $idle = $parts[3]
                $logon = if ($parts.Count -ge 5) { ($parts[4..($parts.Count - 1)] -join ' ') } else { '' }
            }

            $isShadow = $false
            foreach ($p in $ShadowUserPrefixes) {
                if (-not [string]::IsNullOrWhiteSpace($p) -and $user -like "$p*") { $isShadow = $true; break }
            }

            $stateNorm = if ($state -match '^Active') { 'Active' }
                         elseif ($state -match '^Disc') { 'Disconnected' }
                         else { $state }

            $snap.Total++
            switch ($stateNorm) {
                'Active'       { $snap.Active++ }
                'Disconnected' { $snap.Disconnected++; if ($isShadow) { $snap.ShadowDisconnected++ } }
                default        { $snap.Other++ }
            }
            if ($isShadow) { $snap.ShadowUsers++ }

            $snap.Sessions += [PSCustomObject]@{
                UserName     = $user
                SessionName  = $sessionName
                Id           = $id
                State        = $stateNorm
                IdleTime     = $idle
                LogonTime    = $logon
                IsShadowUser = $isShadow
                IsCurrent    = $isCurrent
            }
        }
    }
    catch { $snap.Error = $_.Exception.Message }
    return $snap
}

function Collect-SystemHealth {
    <#
    .SYNOPSIS
        Collects CPU, memory, disk, uptime, and installed component metrics.
        Uses WMI/CIM on Windows. Returns mock data on non-Windows or when -UseMockData set.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param()

    $startTime = Get-Date
    Write-Log -Message 'Starting system health collection' -Level Debug -Component 'SystemHealth'

    if ($UseMockData -or -not (Test-IsWindowsPlatform)) {
        Write-Log -Message 'Using mock data for system health' -Level Debug -Component 'SystemHealth'
        return Get-MockData -DataType 'SystemHealth'
    }

    try {
        $cfg            = $script:Config
        $sampleCount    = $cfg.collection.cpuSampleCount
        $sampleInterval = $cfg.collection.cpuSampleIntervalMs
        $serverName     = $env:COMPUTERNAME
        $timestamp      = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')

        # OS info
        $osInfo      = Get-CimInstance -ClassName Win32_OperatingSystem
        $lastBoot    = $osInfo.LastBootUpTime
        $uptimeDays  = [math]::Round(((Get-Date) - $lastBoot).TotalDays, 2)

        # CPU samples -- isolated so a disabled/corrupt perf counter degrades CPU
        # to zeros instead of erroring the whole collector (memory/disk still count).
        $cpuSamples = @()
        try {
            for ($i = 0; $i -lt $sampleCount; $i++) {
                $counter     = Get-Counter -Counter '\Processor(_Total)\% Processor Time' -SampleInterval 1 -MaxSamples 1
                $cpuSamples += $counter.CounterSamples[0].CookedValue
                if ($i -lt ($sampleCount - 1)) {
                    Start-Sleep -Milliseconds $sampleInterval
                }
            }
        }
        catch {
            Write-Log -Message "CPU counter unavailable, reporting 0: $($_.Exception.Message)" -Level Warn -Color Yellow -Component 'SystemHealth'
        }
        if ($cpuSamples.Count -eq 0) { $cpuSamples = @(0) }

        $cpuCurrent = [math]::Round($cpuSamples[-1], 2)
        $cpuAverage = [math]::Round(($cpuSamples | Measure-Object -Average).Average, 2)
        $cpuPeak    = [math]::Round(($cpuSamples | Measure-Object -Maximum).Maximum, 2)

        $cpuStatus = 'OK'
        if ($cpuAverage -ge $cfg.thresholds.cpuCriticalPercent) { $cpuStatus = 'Critical' }
        elseif ($cpuAverage -ge $cfg.thresholds.cpuWarningPercent) { $cpuStatus = 'Warning' }

        # Memory
        $totalMemGB     = [math]::Round($osInfo.TotalVisibleMemorySize / 1MB, 2)
        $availMemGB     = [math]::Round($osInfo.FreePhysicalMemory / 1MB, 2)
        $usedMemPercent = if ($totalMemGB -gt 0) { [math]::Round((($totalMemGB - $availMemGB) / $totalMemGB) * 100, 2) } else { 0 }

        $memStatus = 'OK'
        if ($usedMemPercent -ge $cfg.thresholds.memoryCriticalPercent) { $memStatus = 'Critical' }
        elseif ($usedMemPercent -ge $cfg.thresholds.memoryWarningPercent) { $memStatus = 'Warning' }

        # Disks
        $disks      = @()
        $diskStatus = 'OK'
        $logicalDisks = Get-CimInstance -ClassName Win32_LogicalDisk -Filter 'DriveType=3'
        foreach ($disk in $logicalDisks) {
            if (-not $disk.Size -or $disk.Size -le 0) { continue }
            $sizeGB    = [math]::Round($disk.Size / 1GB, 2)
            $freeGB    = [math]::Round($disk.FreeSpace / 1GB, 2)
            $usedPct   = [math]::Round((($sizeGB - $freeGB) / $sizeGB) * 100, 2)
            $dStatus   = 'OK'
            if ($usedPct -ge $cfg.thresholds.diskCriticalPercent) {
                $dStatus    = 'Critical'
                $diskStatus = 'Critical'
            }
            elseif ($usedPct -ge $cfg.thresholds.diskWarningPercent) {
                $dStatus = 'Warning'
                if ($diskStatus -ne 'Critical') { $diskStatus = 'Warning' }
            }
            $disks += [PSCustomObject]@{
                DriveLetter = $disk.DeviceID
                SizeGB      = $sizeGB
                FreeGB      = $freeGB
                UsedPercent = $usedPct
                Status      = $dStatus
            }
        }

        # Installed components
        $installedComponents = Get-InstalledComponents

        # RDP / interactive session snapshot (same interval as CPU/memory so the
        # two can be correlated; disconnected counts feed orphan-session hunting)
        $shadowPrefixes = @('PSMShadowUser', 'PSM-')
        try {
            if ($null -ne $cfg.collection.shadowUserPrefixes) { $shadowPrefixes = @($cfg.collection.shadowUserPrefixes) }
        }
        catch { }
        $rdpSessions = Get-RdpSessionSnapshot -ShadowUserPrefixes $shadowPrefixes

        $overallStatus = 'OK'
        if ($cpuStatus -eq 'Critical' -or $memStatus -eq 'Critical' -or $diskStatus -eq 'Critical') {
            $overallStatus = 'Critical'
        }
        elseif ($cpuStatus -eq 'Warning' -or $memStatus -eq 'Warning' -or $diskStatus -eq 'Warning') {
            $overallStatus = 'Warning'
        }

        $computerSystem = Get-CimInstance -ClassName Win32_ComputerSystem
        $domain = $computerSystem.Domain
        if (-not $domain) { $domain = 'WORKGROUP' }

        # Surface the worst disk in the status line -- otherwise a disk-driven
        # Critical looks like a false alarm next to a low CPU/mem reading.
        $worstDisk = $disks | Sort-Object UsedPercent -Descending | Select-Object -First 1
        $diskStr   = if ($worstDisk) { "Disk:$($worstDisk.DriveLetter)$([math]::Round([double]$worstDisk.UsedPercent,0))%" } else { 'Disk:n/a' }
        Write-Log -Message "System health collected: $overallStatus (CPU:$cpuAverage% Mem:$usedMemPercent% $diskStr Sessions:$($rdpSessions.Active)A/$($rdpSessions.Disconnected)D shadow:$($rdpSessions.ShadowUsers))" -Level Info -Component 'SystemHealth'

        return [PSCustomObject]@{
            Status      = $overallStatus
            Hostname    = $serverName
            Domain      = $domain
            OSVersion   = $osInfo.Caption + ' ' + $osInfo.Version
            LastBootTime        = $lastBoot.ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
            UptimeDays          = $uptimeDays
            CPU = [PSCustomObject]@{
                Current = $cpuCurrent
                Average = $cpuAverage
                Peak    = $cpuPeak
                Status  = $cpuStatus
            }
            Memory = [PSCustomObject]@{
                TotalGB     = $totalMemGB
                AvailableGB = $availMemGB
                UsedPercent = $usedMemPercent
                Status      = $memStatus
            }
            Disks               = $disks
            InstalledComponents = $installedComponents
            RdpSessions         = $rdpSessions
            CheckedAt           = $timestamp
            ServerName          = $serverName
            CorrelationID       = $script:CorrelationID
            Duration            = ((Get-Date) - $startTime).ToString()
            IsMockData          = $false
            ErrorMessage        = $null
        }
    }
    catch {
        Write-Log -Message "System health collection failed: $($_.Exception.Message)" -Level Error -Color Red -Component 'SystemHealth'
        return [PSCustomObject]@{
            Status              = 'Error'
            Hostname            = $env:COMPUTERNAME
            Domain              = $null
            OSVersion           = $null
            LastBootTime        = $null
            UptimeDays          = 0
            CPU                 = $null
            Memory              = $null
            Disks               = @()
            InstalledComponents = @()
            RdpSessions         = $null
            CheckedAt           = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
            ServerName          = $env:COMPUTERNAME
            CorrelationID       = $script:CorrelationID
            Duration            = ((Get-Date) - $startTime).ToString()
            IsMockData          = $false
            ErrorMessage        = $_.Exception.Message
        }
    }
}

#endregion

#region Service Resiliency

function Get-RecencyProfile {
    <#
    .SYNOPSIS
        The core of the recency framework. Given a list of event timestamps (service
        restarts/crashes, log-error lines, ...) returns nested-window counts so callers
        can report "how often recently vs historically" and alert on the recent window.
    .DESCRIPTION
        $null entries (an unparseable/undated log line) are counted as 'undated' and are
        NEVER placed in a time window -- so an old or timestamp-less event can't keep an
        alert firing forever. Windows are nested: count7d includes count24h, count30d
        includes count7d. 'total' = dated + undated; 'lastAt' = newest dated event (UTC ISO).
    #>
    [CmdletBinding()]
    [OutputType([System.Collections.Specialized.OrderedDictionary])]
    param(
        # [object[]] not [datetime[]]: callers pass $null for undated/unparseable log
        # lines, which a typed [datetime[]] param would reject or coerce to MinValue.
        [AllowEmptyCollection()]
        [object[]]$Timestamps = @(),
        [datetime]$Now = (Get-Date),
        [int]$DayHours   = 24,
        [int]$WeekHours  = 168,
        [int]$MonthHours = 720
    )
    $dated = @($Timestamps | Where-Object { $_ -is [datetime] })
    $undated = @($Timestamps).Count - $dated.Count
    $c24 = 0; $c7 = 0; $c30 = 0; $last = $null
    $t24 = $Now.AddHours(-$DayHours); $t7 = $Now.AddHours(-$WeekHours); $t30 = $Now.AddHours(-$MonthHours)
    foreach ($ts in $dated) {
        if ($ts -ge $t30) { $c30++ }
        if ($ts -ge $t7)  { $c7++ }
        if ($ts -ge $t24) { $c24++ }
        if ($null -eq $last -or $ts -gt $last) { $last = $ts }
    }
    [ordered]@{
        count24h = $c24
        count7d  = $c7
        count30d = $c30
        total    = $dated.Count + $undated
        undated  = $undated
        lastAt   = $(if ($null -ne $last) { $last.ToUniversalTime().ToString('o') } else { $null })
    }
}

function Get-RecencyVerdict {
    <#
    .SYNOPSIS
        Turns a RecencyProfile into OK/Warning/Critical by comparing the chosen window's
        count against warn/crit thresholds. This is the behavioral shift of the framework:
        thresholds measure RECENT activity, not the all-time total.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory)]$Profile,
        [int]$Warn = 1,
        [int]$Critical = 10,
        [ValidateSet('24h','7d','30d')][string]$Window = '24h'
    )
    $key = "count$Window"
    $n = if ($Profile -is [System.Collections.IDictionary]) { [int]$Profile[$key] } else { [int]$Profile.$key }
    if ($Critical -gt 0 -and $n -ge $Critical) { 'Critical' }
    elseif ($Warn -gt 0 -and $n -ge $Warn)     { 'Warning' }
    else                                        { 'OK' }
}

function New-Finding {
    <#
    .SYNOPSIS
        Normalizes any recency signal (a service's restarts/crashes, a log source's
        errors) into one shape the orchestrator collects into $results.Findings and the
        report/JSONL render uniformly.
    #>
    [CmdletBinding()]
    [OutputType([System.Collections.Specialized.OrderedDictionary])]
    param(
        [Parameter(Mandatory)][string]$Source,
        [Parameter(Mandatory)][ValidateSet('ServiceRestart','ServiceCrash','ServiceStartFailure','LogError')][string]$Kind,
        [Parameter(Mandatory)][string]$Severity,
        [Parameter(Mandatory)]$Recency,
        [string]$Detail = ''
    )
    $g = { param($k) if ($Recency -is [System.Collections.IDictionary]) { $Recency[$k] } else { $Recency.$k } }
    [ordered]@{
        recordType = 'Finding'
        source     = $Source
        kind       = $Kind
        severity   = $Severity
        count24h   = [int](& $g 'count24h')
        count7d    = [int](& $g 'count7d')
        count30d   = [int](& $g 'count30d')
        lastAt     = (& $g 'lastAt')
        detail     = $Detail
        CorrelationID = $script:CorrelationID
        ServerName    = $env:COMPUTERNAME
    }
}

function Resolve-RecencyConfig {
    <#
    .SYNOPSIS
        Resolve the recency window config once, with the bucket key + label that the
        configured alertWindowHours maps to. Shared by the service and log collectors.
    #>
    [CmdletBinding()]
    param()
    $rec = $script:Config.recency
    $day   = if ($rec -and $rec.dayHours)   { [int]$rec.dayHours }   else { 24 }
    $week  = if ($rec -and $rec.weekHours)  { [int]$rec.weekHours }  else { 168 }
    $month = if ($rec -and $rec.monthHours) { [int]$rec.monthHours } else { 720 }
    $awin  = if ($rec -and $rec.alertWindowHours) { [int]$rec.alertWindowHours } else { 24 }
    $key   = if ($awin -le $day) { 'count24h' } elseif ($awin -le $week) { 'count7d' } else { 'count30d' }
    [pscustomobject]@{
        Day = $day; Week = $week; Month = $month
        AlertWindowHours = $awin
        CrashDays = if ($rec -and $rec.crashLookbackDays) { [int]$rec.crashLookbackDays } else { 7 }
        AlertKey = $key
        AlertLabel = switch ($key) { 'count24h' { '24h' } 'count7d' { '7d' } default { '30d' } }
    }
}

function Update-ServiceBaseline {
    <#
    .SYNOPSIS
        Adaptive service baseline manager.
        - First observation: baseline = current state (no alert)
        - State change: track change timestamp, alert if unexpected
        - Stable new state for stabilizationMinutes: auto-adapt baseline
        - -Baseline flag: force re-learn all services immediately
    .PARAMETER ServiceName
        The service name to evaluate.
    .PARAMETER CurrentStatus
        The current service status string (Running, Stopped, etc.).
    .PARAMETER ForceBaseline
        When set, immediately set baseline to current state.
    .OUTPUTS
        [PSCustomObject] with: IsExpected, BaselineState, Transition (None/StateChange/Stabilized/NewService)
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)]
        [string]$ServiceName,

        [Parameter(Mandatory)]
        [string]$CurrentStatus,

        [switch]$ForceBaseline
    )

    $state    = $script:PlatformState
    $cfg      = $script:Config.serviceBaseline
    $now      = (Get-Date).ToUniversalTime()
    $nowStr   = $now.ToString('o')

    # Ensure serviceBaseline section exists
    if ($null -eq $state.serviceBaseline) {
        $state.serviceBaseline = [ordered]@{}
    }

    # Force baseline mode
    if ($ForceBaseline) {
        $state.serviceBaseline[$ServiceName] = [ordered]@{
            expectedState = $CurrentStatus
            baselinedAt   = $nowStr
            stateChangedAt = $null
            previousState  = $null
            notes         = 'Manual baseline via -Baseline flag'
        }
        return [PSCustomObject]@{
            IsExpected     = $true
            BaselineState  = $CurrentStatus
            Transition     = 'Baselined'
        }
    }

    # First time seeing this service -- check config for pre-declared expected state
    if (-not $state.serviceBaseline.Contains($ServiceName)) {
        $declaredState = $null
        $cfgExpected   = $cfg.expectedStates
        if ($cfgExpected -and $cfgExpected.ContainsKey($ServiceName)) {
            $declaredState = $cfgExpected[$ServiceName]
        }
        elseif ($cfgExpected -is [PSCustomObject]) {
            $prop = $cfgExpected.PSObject.Properties[$ServiceName]
            if ($prop) { $declaredState = $prop.Value }
        }

        $baselineState = if ($declaredState) { $declaredState } else { $CurrentStatus }
        $notes = if ($declaredState) {
            "Config-declared expected state: $declaredState"
        } else {
            "Auto-baselined: first observation as $CurrentStatus"
        }

        $state.serviceBaseline[$ServiceName] = [ordered]@{
            expectedState  = $baselineState
            baselinedAt    = $nowStr
            stateChangedAt = $null
            previousState  = $null
            notes          = $notes
        }
        Write-Log -Message "Service baseline created: $ServiceName = $baselineState ($notes)" -Level Info -Component 'ServiceBaseline'

        # If config says it should be Running but it's Stopped, that IS unexpected from the start
        $isExpected = ($CurrentStatus -eq $baselineState)
        return [PSCustomObject]@{
            IsExpected     = $isExpected
            BaselineState  = $baselineState
            Transition     = if ($isExpected) { 'NewService' } else { 'StateChange' }
        }
    }

    $entry    = $state.serviceBaseline[$ServiceName]
    $expected = $entry.expectedState

    # State matches baseline -- healthy
    if ($CurrentStatus -eq $expected) {
        # Clear any pending state change tracking
        if ($entry.stateChangedAt) {
            $entry.stateChangedAt = $null
            $entry.previousState  = $null
        }
        return [PSCustomObject]@{
            IsExpected     = $true
            BaselineState  = $expected
            Transition     = 'None'
        }
    }

    # State differs from baseline
    $autoAdapt  = if ($null -ne $cfg.autoAdapt) { $cfg.autoAdapt } else { $true }
    $stabilizeMin = if ($cfg.stabilizationMinutes) { $cfg.stabilizationMinutes } else { 30 }

    if (-not $entry.stateChangedAt) {
        # First observation of the change
        $entry.stateChangedAt = $nowStr
        $entry.previousState  = $expected
        Write-Log -Message "Service state change detected: $ServiceName changed from $expected to $CurrentStatus" -Level Warn -Component 'ServiceBaseline'
        return [PSCustomObject]@{
            IsExpected     = $false
            BaselineState  = $expected
            Transition     = 'StateChange'
        }
    }

    # Change was already detected -- check stabilization
    # ToUniversalTime is required: Parse returns local-kind for the 'o' round-trip
    # string, and $now is UTC -- mixing kinds inflates elapsed by the UTC offset.
    $changedAt = [DateTime]::Parse($entry.stateChangedAt).ToUniversalTime()
    $elapsed   = ($now - $changedAt).TotalMinutes

    # Baseline PINNING for self-heal allowlisted services: allowlisting IS the
    # declaration that Stopped is never the expected state, so the baseline must
    # never "learn" Stopped just because restart attempts kept failing for
    # stabilizationMinutes -- that would silently disable self-heal after 30 min.
    # (A config expectedStates entry still wins; it is applied at first sight.)
    if ($CurrentStatus -ne 'Running') {
        $pinNames = @()
        try { if ($null -ne $cfg.autoRestartServices) { $pinNames = @($cfg.autoRestartServices) } } catch { }
        if ($pinNames -contains $ServiceName) {
            Write-Log -Message "Baseline pinned for '$ServiceName': allowlisted for self-heal, will not adapt to '$CurrentStatus'" -Level Debug -Component 'ServiceBaseline'
            return [PSCustomObject]@{
                IsExpected     = $false
                BaselineState  = $expected
                Transition     = 'StateChange'
            }
        }
    }

    if ($autoAdapt -and $elapsed -ge $stabilizeMin) {
        # New state has been stable long enough -- adapt baseline
        $oldState = $expected
        $entry.expectedState  = $CurrentStatus
        $entry.baselinedAt    = $nowStr
        $entry.stateChangedAt = $null
        $entry.previousState  = $null
        $entry.notes          = "Auto-adapted: $oldState -> $CurrentStatus after $([math]::Round($elapsed, 0)) min stability"
        Write-Log -Message "Service baseline adapted: $ServiceName = $CurrentStatus (was $oldState, stable for $([math]::Round($elapsed, 0)) min)" -Level Info -Component 'ServiceBaseline'
        return [PSCustomObject]@{
            IsExpected     = $true
            BaselineState  = $CurrentStatus
            Transition     = 'Stabilized'
        }
    }

    # Still in change window, not yet stabilized
    return [PSCustomObject]@{
        IsExpected     = $false
        BaselineState  = $expected
        Transition     = 'StateChange'
    }
}

function Collect-ServiceResiliency {
    <#
    .SYNOPSIS
        Collects service health, restart counts, MTTR, and availability for CyberArk services.
        Uses adaptive baseline to distinguish expected stops (passive CPM, DR vault) from
        unexpected failures. Only alerts on state CHANGES from the baseline.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [string[]]$ServiceFilter
    )

    $startTime = Get-Date
    Write-Log -Message 'Starting service resiliency collection' -Level Debug -Component 'ServiceResiliency'

    if ($UseMockData -or -not (Test-IsWindowsPlatform)) {
        Write-Log -Message 'Using mock data for service resiliency' -Level Debug -Component 'ServiceResiliency'
        return Get-MockData -DataType 'ServiceResiliency'
    }

    try {
        $cfg            = $script:Config
        $lookbackDays   = $cfg.collection.eventLogLookbackDays
        $servicesToCheck = if ($ServiceFilter) { $ServiceFilter } else { @($cfg.collection.cyberArkServices) }

        # Merge additional services from serviceBaseline config
        $additional = $cfg.serviceBaseline.additionalServices
        if ($additional -and $additional.Count -gt 0) {
            foreach ($svc in $additional) {
                if ($servicesToCheck -notcontains $svc) {
                    $servicesToCheck += $svc
                }
            }
        }

        $serverName  = $env:COMPUTERNAME
        $timestamp   = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')

        # --- Recency framework config (bucket windows + which one drives alerts) ---
        $rec = $cfg.recency
        $rcDay   = if ($rec -and $rec.dayHours)   { [int]$rec.dayHours }   else { 24 }
        $rcWeek  = if ($rec -and $rec.weekHours)  { [int]$rec.weekHours }  else { 168 }
        $rcMonth = if ($rec -and $rec.monthHours) { [int]$rec.monthHours } else { 720 }
        $rcAlertWin  = if ($rec -and $rec.alertWindowHours)  { [int]$rec.alertWindowHours }  else { 24 }
        $rcCrashDays = if ($rec -and $rec.crashLookbackDays) { [int]$rec.crashLookbackDays } else { 7 }
        $alertWinKey  = if ($rcAlertWin -le $rcDay) { 'count24h' } elseif ($rcAlertWin -le $rcWeek) { 'count7d' } else { 'count30d' }
        $rcAlertLabel = switch ($alertWinKey) { 'count24h' { '24h' } 'count7d' { '7d' } default { '30d' } }
        # Query window must cover the widest bucket AND the legacy eventLogLookbackDays.
        $lookbackDate = (Get-Date).AddHours(-([math]::Max($lookbackDays * 24, $rcMonth)))

        $serviceResults    = @()
        $healthyCount      = 0
        $degradedCount     = 0
        $stoppedCount      = 0
        $expectedStopCount = 0
        $baselineChanges   = @()

        foreach ($serviceName in $servicesToCheck) {
            $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
            if (-not $service) { continue }

            $status    = $service.Status.ToString()
            $startType = $service.StartType.ToString()

            # --- Baseline evaluation ---
            $baselineResult = Update-ServiceBaseline -ServiceName $serviceName -CurrentStatus $status -ForceBaseline:$Baseline
            $isExpectedState = $baselineResult.IsExpected

            if ($baselineResult.Transition -notin @('None','NewService','Baselined')) {
                $baselineChanges += [PSCustomObject]@{
                    ServiceName = $serviceName
                    Transition  = $baselineResult.Transition
                    FromState   = $baselineResult.BaselineState
                    ToState     = $status
                }
            }

            # --- Process metrics ---
            $statusDetail    = 'Healthy'
            $memoryMB        = 0
            $cpuTimeSeconds  = 0
            $svcPid          = 0

            if ($status -eq 'Running') {
                try {
                    # ServiceController has no PID -- resolve it via Win32_Service.
                    $escapedName = $serviceName -replace "'", "''"
                    $wmiSvc = Get-CimInstance -ClassName Win32_Service -Filter "Name='$escapedName'" -ErrorAction SilentlyContinue
                    if ($wmiSvc -and $wmiSvc.ProcessId -gt 0) {
                        $proc = Get-Process -Id $wmiSvc.ProcessId -ErrorAction SilentlyContinue
                        if ($proc) {
                            $svcPid         = $proc.Id
                            $memoryMB       = [math]::Round($proc.WorkingSet64 / 1MB, 2)
                            $cpuTimeSeconds = [math]::Round($proc.TotalProcessorTime.TotalSeconds, 2)
                        }
                    }
                }
                catch {
                    Write-Log -Message "Process metrics unavailable for '$serviceName': $($_.Exception.Message)" -Level Debug -Component 'ServiceResiliency'
                }
            }

            # --- Event-log recency analysis ---
            # 7036 = entered running/stopped; 7031/7034 = terminated unexpectedly (crash);
            # 7000/7009 = failed to start / start timeout.
            $restartTimes = @(); $stopTimes = @(); $crashTimes = @(); $startFailTimes = @()
            $serviceEvents = @()
            try {
                $events = Get-WinEvent -FilterHashtable @{
                    LogName   = 'System'
                    Id        = @(7036,7031,7034,7000,7009)
                    StartTime = $lookbackDate
                } -ErrorAction SilentlyContinue | Where-Object { $_.Message -like "*$serviceName*" }

                if ($events) {
                    $serviceEvents = @($events)
                    foreach ($ev in $serviceEvents) {
                        switch ($ev.Id) {
                            7036 {
                                if     ($ev.Message -like '*running*') { $restartTimes += $ev.TimeCreated }
                                elseif ($ev.Message -like '*stopped*') { $stopTimes    += $ev.TimeCreated }
                            }
                            7031 { $crashTimes     += $ev.TimeCreated }
                            7034 { $crashTimes     += $ev.TimeCreated }
                            7000 { $startFailTimes += $ev.TimeCreated }
                            7009 { $startFailTimes += $ev.TimeCreated }
                        }
                    }
                }
            }
            catch { }

            $restarts   = Get-RecencyProfile -Timestamps $restartTimes   -DayHours $rcDay -WeekHours $rcWeek -MonthHours $rcMonth
            $stops      = Get-RecencyProfile -Timestamps $stopTimes      -DayHours $rcDay -WeekHours $rcWeek -MonthHours $rcMonth
            $crashes    = Get-RecencyProfile -Timestamps $crashTimes     -DayHours $rcDay -WeekHours $rcWeek -MonthHours $rcMonth
            $startFails = Get-RecencyProfile -Timestamps $startFailTimes -DayHours $rcDay -WeekHours $rcWeek -MonthHours $rcMonth
            $restartCount = [int]$restarts.total    # back-compat (= all-time restarts in window)
            $crashCutoff  = (Get-Date).AddDays(-$rcCrashDays)
            $recentCrashes    = @($crashTimes     | Where-Object { $_ -ge $crashCutoff }).Count
            $recentStartFails = @($startFailTimes | Where-Object { $_ -ge $crashCutoff }).Count

            $lastStartTime = $null
            $uptimeHours   = 0
            if ($status -eq 'Running') {
                $startEvt = $serviceEvents | Where-Object { $_.Id -eq 7036 -and $_.Message -like '*running*' } | Sort-Object TimeCreated -Descending | Select-Object -First 1
                if ($startEvt) {
                    $lastStartTime = $startEvt.TimeCreated.ToString('yyyy-MM-dd HH:mm:ss')
                    $uptimeHours   = [math]::Round(((Get-Date) - $startEvt.TimeCreated).TotalHours, 2)
                }
            }

            # MTTR calculation
            $mttr           = 0
            $stopStartPairs = @()
            $stopEvts       = $serviceEvents | Where-Object { $_.Id -eq 7036 -and $_.Message -like '*stopped*' } | Sort-Object TimeCreated
            $startEvts2     = $serviceEvents | Where-Object { $_.Id -eq 7036 -and $_.Message -like '*running*' } | Sort-Object TimeCreated

            $lastClaimedStart = [datetime]::MinValue
            foreach ($stopEvt in $stopEvts) {
                # Each Start event may only be claimed by ONE Stop -- otherwise two
                # stops before the next start double-count the same downtime.
                $nextStart = $startEvts2 | Where-Object { $_.TimeCreated -gt $stopEvt.TimeCreated -and $_.TimeCreated -gt $lastClaimedStart } | Select-Object -First 1
                if ($nextStart) {
                    $downtime         = ($nextStart.TimeCreated - $stopEvt.TimeCreated).TotalMinutes
                    $stopStartPairs  += $downtime
                    $lastClaimedStart = $nextStart.TimeCreated
                }
            }
            if ($stopStartPairs.Count -gt 0) {
                $mttr = [math]::Round(($stopStartPairs | Measure-Object -Average).Average, 2)
            }

            $totalMinutes    = $lookbackDays * 24 * 60
            $downtimeMinutes = ($stopStartPairs | Measure-Object -Sum).Sum
            if (-not $downtimeMinutes) { $downtimeMinutes = 0 }
            $availabilityPct = if ($totalMinutes -gt 0) { [math]::Round((($totalMinutes - $downtimeMinutes) / $totalMinutes) * 100, 2) } else { 100 }

            # --- Status determination (baseline-aware + recency-based) ---
            # Alerts fire on RECENT activity, not the all-time total: a service that
            # flapped last week but has been stable since reads Healthy again.
            $recentRestarts = [int]$restarts[$alertWinKey]
            if ($status -eq 'Running') {
                if ($recentCrashes -ge 1 -or $recentStartFails -ge 1) {
                    $statusDetail = "Degraded - recent failure (crashes:$recentCrashes start-fails:$recentStartFails in ${rcCrashDays}d)"
                    $degradedCount++
                }
                elseif ($recentRestarts -ge $cfg.thresholds.serviceRestartCritical) {
                    $statusDetail = "Degraded - flapping ($recentRestarts restarts/$rcAlertLabel)"
                    $degradedCount++
                }
                elseif ($recentRestarts -ge $cfg.thresholds.serviceRestartWarning) {
                    $statusDetail = "Degraded - elevated restarts ($recentRestarts/$rcAlertLabel)"
                    $degradedCount++
                }
                elseif ($availabilityPct -lt 99.0) {
                    $statusDetail = 'Degraded - Low availability'
                    $degradedCount++
                }
                else {
                    $healthyCount++
                }
            }
            else {
                # Service is stopped -- is this expected?
                if ($isExpectedState) {
                    $statusDetail = 'Stopped (Expected)'
                    $expectedStopCount++
                    # Do NOT count as stoppedCount -- this is intentional
                }
                else {
                    $statusDetail = 'Stopped (Unexpected)'
                    $stoppedCount++
                }
            }

            $serviceResults += [PSCustomObject]@{
                ServiceName         = $serviceName
                DisplayName         = $service.DisplayName
                Status              = $status
                StartType           = $startType
                PID                 = $svcPid
                MemoryMB            = $memoryMB
                CpuTimeSeconds      = $cpuTimeSeconds
                RestartCount        = $restartCount
                Restarts            = $restarts
                Stops               = $stops
                Crashes             = $crashes
                StartFailures       = $startFails
                LastRestart         = $restarts.lastAt
                LastCrash           = $crashes.lastAt
                LastStartTime       = $lastStartTime
                UptimeHours         = $uptimeHours
                MTTR                = $mttr
                AvailabilityPercent = $availabilityPct
                StatusDetail        = $statusDetail
                IsExpectedState     = $isExpectedState
                BaselineState       = $baselineResult.BaselineState
                BaselineTransition  = $baselineResult.Transition
            }
        }

        # Overall status: only unexpected stops are Critical
        $overallStatus = 'OK'
        if ($stoppedCount -gt 0)  { $overallStatus = 'Critical' }
        elseif ($degradedCount -gt 0) { $overallStatus = 'Warning' }

        if (@($serviceResults).Count -eq 0) {
            Write-Log -Message 'Service resiliency: no monitored services present on this host (none of collection.cyberArkServices exist)' -Level Info -Component 'ServiceResiliency'
        }
        else {
            $logParts = @("Healthy:$healthyCount", "Degraded:$degradedCount", "Stopped(unexpected):$stoppedCount")
            if ($expectedStopCount -gt 0) { $logParts += "Stopped(expected):$expectedStopCount" }
            if ($baselineChanges.Count -gt 0) { $logParts += "BaselineChanges:$($baselineChanges.Count)" }
            Write-Log -Message "Service resiliency: $overallStatus ($($logParts -join ' '))" -Level Info -Component 'ServiceResiliency'
        }

        return [PSCustomObject]@{
            Status              = $overallStatus
            TotalServices       = $serviceResults.Count
            HealthyServices     = $healthyCount
            DegradedServices    = $degradedCount
            StoppedServices     = $stoppedCount
            ExpectedStopCount   = $expectedStopCount
            BaselineChanges     = $baselineChanges
            Services            = $serviceResults
            CheckedAt           = $timestamp
            ServerName          = $serverName
            CorrelationID       = $script:CorrelationID
            Duration            = ((Get-Date) - $startTime).ToString()
            IsMockData          = $false
            ErrorMessage        = $null
        }
    }
    catch {
        Write-Log -Message "Service resiliency collection failed: $($_.Exception.Message)" -Level Error -Color Red -Component 'ServiceResiliency'
        return [PSCustomObject]@{
            Status              = 'Error'
            TotalServices       = 0
            HealthyServices     = 0
            DegradedServices    = 0
            StoppedServices     = 0
            ExpectedStopCount   = 0
            BaselineChanges     = @()
            Services            = @()
            CheckedAt           = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
            ServerName          = $env:COMPUTERNAME
            CorrelationID       = $script:CorrelationID
            Duration            = ((Get-Date) - $startTime).ToString()
            IsMockData          = $false
            ErrorMessage        = $_.Exception.Message
        }
    }
}

#endregion

#region Certificate Health

function Collect-CertificateHealth {
    <#
    .SYNOPSIS
        Enumerates CyberArk-related certificates in LocalMachine stores and assesses expiry risk.
        Checks LocalMachine\My and LocalMachine\Root for CyberArk/Privilege/Vault/PSM/CPM/PVWA subjects.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param()

    $startTime = Get-Date
    Write-Log -Message 'Starting certificate health collection' -Level Debug -Component 'CertHealth'

    if ($UseMockData -or -not (Test-IsWindowsPlatform)) {
        Write-Log -Message 'Using mock data for certificate health' -Level Debug -Component 'CertHealth'
        return Get-MockData -DataType 'CertificateHealth'
    }

    try {
        $cfg          = $script:Config
        $warningDays  = $cfg.thresholds.certWarningDays
        $criticalDays = $cfg.thresholds.certCriticalDays
        $serverName   = $env:COMPUTERNAME
        $timestamp    = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')

        $certResults  = @()
        $expiredCount = 0
        $critCount    = 0
        $warnCount    = 0
        $okCount      = 0

        $cyberArkKeywords = @('CyberArk','Privilege','Vault','DVCA','PrivateArk','PVWA','PSM','CPM')

        $stores = @(
            @{ Path = 'Cert:\LocalMachine\My';   Name = 'LocalMachine\My' }
            @{ Path = 'Cert:\LocalMachine\Root';  Name = 'LocalMachine\Root' }
        )

        foreach ($store in $stores) {
            if (-not (Test-Path $store.Path)) { continue }

            $certs = Get-ChildItem -Path $store.Path -ErrorAction SilentlyContinue
            foreach ($cert in $certs) {
                $isCyberArk = $false
                foreach ($kw in $cyberArkKeywords) {
                    if ($cert.Subject -like "*$kw*" -or $cert.Issuer -like "*$kw*") {
                        $isCyberArk = $true
                        break
                    }
                }
                if (-not $isCyberArk) { continue }

                $daysLeft = [math]::Round(($cert.NotAfter - (Get-Date)).TotalDays, 0)
                $risk     = 'OK'

                if ($daysLeft -le 0) {
                    $risk = 'Expired'
                    $expiredCount++
                }
                elseif ($daysLeft -le $criticalDays) {
                    $risk = 'Critical'
                    $critCount++
                }
                elseif ($daysLeft -le $warningDays) {
                    $risk = 'Warning'
                    $warnCount++
                }
                else {
                    $okCount++
                }

                $certResults += [PSCustomObject]@{
                    Subject         = $cert.Subject
                    Issuer          = $cert.Issuer
                    Thumbprint      = $cert.Thumbprint
                    NotBefore       = $cert.NotBefore.ToString('yyyy-MM-dd')
                    NotAfter        = $cert.NotAfter.ToString('yyyy-MM-dd')
                    DaysUntilExpiry = $daysLeft
                    RiskLevel       = $risk
                    Store           = $store.Name
                }
            }
        }

        $overallStatus = 'OK'
        if ($expiredCount -gt 0 -or $critCount -gt 0) { $overallStatus = 'Critical' }
        elseif ($warnCount -gt 0) { $overallStatus = 'Warning' }

        Write-Log -Message "Certificate health collected: $overallStatus (Total:$($certResults.Count) Expired:$expiredCount Crit:$critCount Warn:$warnCount)" -Level Info -Component 'CertHealth'

        return [PSCustomObject]@{
            Status            = $overallStatus
            TotalCertificates = $certResults.Count
            ExpiredCount      = $expiredCount
            CriticalCount     = $critCount
            WarningCount      = $warnCount
            OKCount           = $okCount
            Certificates      = $certResults
            CheckedAt         = $timestamp
            ServerName        = $serverName
            CorrelationID     = $script:CorrelationID
            Duration          = ((Get-Date) - $startTime).ToString()
            IsMockData        = $false
            ErrorMessage      = $null
        }
    }
    catch {
        Write-Log -Message "Certificate health collection failed: $($_.Exception.Message)" -Level Error -Color Red -Component 'CertHealth'
        return [PSCustomObject]@{
            Status            = 'Error'
            TotalCertificates = 0
            ExpiredCount      = 0
            CriticalCount     = 0
            WarningCount      = 0
            OKCount           = 0
            Certificates      = @()
            CheckedAt         = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
            ServerName        = $env:COMPUTERNAME
            CorrelationID     = $script:CorrelationID
            Duration          = ((Get-Date) - $startTime).ToString()
            IsMockData        = $false
            ErrorMessage      = $_.Exception.Message
        }
    }
}

#endregion

#region Server Capacity

function Collect-ServerCapacity {
    <#
    .SYNOPSIS
        Samples CPU, memory, disk I/O performance counters and enumerates CyberArk-port connections.
        Calculates capacity headroom. Uses Get-Counter and Get-NetTCPConnection.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param()

    $startTime = Get-Date
    Write-Log -Message 'Starting server capacity collection' -Level Debug -Component 'Capacity'

    if ($UseMockData -or -not (Test-IsWindowsPlatform)) {
        Write-Log -Message 'Using mock data for server capacity' -Level Debug -Component 'Capacity'
        return Get-MockData -DataType 'ServerCapacity'
    }

    try {
        $cfg           = $script:Config
        $sampleCount   = $cfg.collection.cpuSampleCount
        $sampleInterval = $cfg.collection.cpuSampleIntervalMs
        $serverName    = $env:COMPUTERNAME
        $timestamp     = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')

        $cpuSamples       = @()
        $diskReadSamples  = @()
        $diskWriteSamples = @()
        $diskQueueSamples = @()

        $counters = @(
            '\Processor(_Total)\% Processor Time'
            '\PhysicalDisk(_Total)\Disk Reads/sec'
            '\PhysicalDisk(_Total)\Disk Writes/sec'
            '\PhysicalDisk(_Total)\Current Disk Queue Length'
        )

        for ($i = 0; $i -lt $sampleCount; $i++) {
            $samples = $null
            try {
                $samples = Get-Counter -Counter $counters -SampleInterval 1 -MaxSamples 1
            }
            catch {
                # A single unavailable counter (registry-disabled, corrupt counter
                # DB) fails the combined call. Retry per-counter so the healthy
                # metrics still collect instead of erroring the whole collector.
                $collected = [System.Collections.ArrayList]::new()
                foreach ($counterPath in $counters) {
                    try {
                        $one = Get-Counter -Counter $counterPath -SampleInterval 1 -MaxSamples 1
                        foreach ($cs in $one.CounterSamples) { $null = $collected.Add($cs) }
                    }
                    catch {
                        Write-Log -Message "Counter unavailable, skipping: $counterPath ($($_.Exception.Message))" -Level Debug -Component 'Capacity'
                    }
                }
                $samples = [PSCustomObject]@{ CounterSamples = @($collected) }
            }

            foreach ($sample in $samples.CounterSamples) {
                if ($sample.Path -like '*Processor*')   { $cpuSamples       += $sample.CookedValue }
                elseif ($sample.Path -like '*Disk Reads*')  { $diskReadSamples  += $sample.CookedValue }
                elseif ($sample.Path -like '*Disk Writes*') { $diskWriteSamples += $sample.CookedValue }
                elseif ($sample.Path -like '*Queue Length*'){ $diskQueueSamples += $sample.CookedValue }
            }

            if ($i -lt ($sampleCount - 1)) { Start-Sleep -Milliseconds $sampleInterval }
        }

        # If CPU sampling produced nothing, downstream indexing/averages would
        # throw -- degrade to zeros rather than erroring the collector.
        if ($cpuSamples.Count -eq 0) { $cpuSamples = @(0) }

        $cpuCurrent  = [math]::Round($cpuSamples[-1], 2)
        $cpuAverage  = [math]::Round(($cpuSamples | Measure-Object -Average).Average, 2)
        $cpuPeak     = [math]::Round(($cpuSamples | Measure-Object -Maximum).Maximum, 2)
        $cpuHeadroom = [math]::Round(100 - $cpuAverage, 2)

        $osInfo          = Get-CimInstance -ClassName Win32_OperatingSystem
        $totalMemGB      = [math]::Round($osInfo.TotalVisibleMemorySize / 1MB, 2)
        $availMemGB      = [math]::Round($osInfo.FreePhysicalMemory / 1MB, 2)
        $usedMemGB       = [math]::Round($totalMemGB - $availMemGB, 2)
        $usedMemPct      = if ($totalMemGB -gt 0) { [math]::Round(($usedMemGB / $totalMemGB) * 100, 2) } else { 0 }
        $memHeadroom     = [math]::Round(100 - $usedMemPct, 2)

        $diskReadBps     = [math]::Round(($diskReadSamples  | Measure-Object -Average).Average, 2)
        $diskWriteBps    = [math]::Round(($diskWriteSamples | Measure-Object -Average).Average, 2)
        $diskQueueLen    = [math]::Round(($diskQueueSamples | Measure-Object -Average).Average, 2)

        $networkConns = @()
        $cyberArkPorts = @(
            @{ Port = 1858; Description = 'CyberArk Vault' }
            @{ Port = 443;  Description = 'HTTPS' }
            @{ Port = 3389; Description = 'RDP' }
        )

        foreach ($portInfo in $cyberArkPorts) {
            # With exactly ONE connection Get-NetTCPConnection returns a single
            # object (not an array); a bare $conns.Count throws under StrictMode
            # ("property 'Count' cannot be found"). Null-check first, because
            # @($null).Count is 1 (a 1-element array), not 0 -- so wrap only when
            # there IS output: 0 (no conns) / 1 (single) / N (array).
            $conns = Get-NetTCPConnection -LocalPort $portInfo.Port -ErrorAction SilentlyContinue
            $count = if ($null -eq $conns) { 0 } else { @($conns).Count }
            $networkConns += [PSCustomObject]@{
                Port        = $portInfo.Port
                Protocol    = 'TCP'
                Count       = $count
                Description = $portInfo.Description
            }
        }

        $overallStatus = 'OK'
        if ($cpuAverage -ge $cfg.thresholds.cpuCriticalPercent -or $usedMemPct -ge $cfg.thresholds.memoryCriticalPercent) {
            $overallStatus = 'Critical'
        }
        elseif ($cpuAverage -ge $cfg.thresholds.cpuWarningPercent -or $usedMemPct -ge $cfg.thresholds.memoryWarningPercent) {
            $overallStatus = 'Warning'
        }

        Write-Log -Message "Server capacity collected: $overallStatus (CPU:$cpuAverage% Mem:$usedMemPct%)" -Level Info -Component 'Capacity'

        return [PSCustomObject]@{
            Status = $overallStatus
            CPU = [PSCustomObject]@{
                Current         = $cpuCurrent
                Average         = $cpuAverage
                Peak            = $cpuPeak
                HeadroomPercent = $cpuHeadroom
            }
            Memory = [PSCustomObject]@{
                TotalGB         = $totalMemGB
                UsedGB          = $usedMemGB
                UsedPercent     = $usedMemPct
                HeadroomPercent = $memHeadroom
            }
            DiskIO = [PSCustomObject]@{
                ReadBytesPerSec  = $diskReadBps
                WriteBytesPerSec = $diskWriteBps
                QueueLength      = $diskQueueLen
            }
            NetworkConnections = $networkConns
            CheckedAt          = $timestamp
            ServerName         = $serverName
            CorrelationID      = $script:CorrelationID
            Duration           = ((Get-Date) - $startTime).ToString()
            IsMockData         = $false
            ErrorMessage       = $null
        }
    }
    catch {
        Write-Log -Message "Server capacity collection failed: $($_.Exception.Message)" -Level Error -Color Red -Component 'Capacity'
        return [PSCustomObject]@{
            Status             = 'Error'
            CPU                = $null
            Memory             = $null
            DiskIO             = $null
            NetworkConnections = @()
            CheckedAt          = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
            ServerName         = $env:COMPUTERNAME
            CorrelationID      = $script:CorrelationID
            Duration           = ((Get-Date) - $startTime).ToString()
            IsMockData         = $false
            ErrorMessage       = $_.Exception.Message
        }
    }
}

#endregion

#region CPM Health

function Test-CAComponentPresent {
    <#
    .SYNOPSIS
        Shared "is this CyberArk component installed on THIS host?" gate. Returns
        $true if any named service exists OR any registry path / file path exists.
        Lets each component collector return Status 'NotInstalled' and skip cleanly
        on a plain Windows box instead of raising a false alert -- the contract that
        keeps the tool usable on non-CyberArk hosts.
    #>
    [CmdletBinding()]
    [OutputType([bool])]
    param(
        [string[]]$ServiceNames  = @(),
        [string[]]$RegistryPaths = @(),
        [string[]]$FilePaths     = @()
    )
    foreach ($s in $ServiceNames)  { if (-not [string]::IsNullOrWhiteSpace($s) -and (Get-Service -Name $s -ErrorAction SilentlyContinue)) { return $true } }
    foreach ($r in $RegistryPaths) { if (-not [string]::IsNullOrWhiteSpace($r) -and (Test-Path $r)) { return $true } }
    foreach ($f in $FilePaths)     { if (-not [string]::IsNullOrWhiteSpace($f) -and (Test-Path $f)) { return $true } }
    return $false
}

function Get-CPMLogPath {
    <#
    .SYNOPSIS
        Discovers CPM log directory from registry, config, or default path.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param()

    $cfg = $script:Config.cpmHealth

    # 1. Registry
    try {
        if (Test-Path -Path $cfg.registryPath -ErrorAction SilentlyContinue) {
            $installPath = (Get-ItemProperty -Path $cfg.registryPath -Name $cfg.registryValue -ErrorAction Stop).($cfg.registryValue)
            $logPath     = Join-Path $installPath 'Logs'
            if (Test-Path $logPath) {
                return [PSCustomObject]@{ Path = $logPath; Source = 'Registry' }
            }
        }
    }
    catch { }

    # 2. Config path
    if (-not [string]::IsNullOrWhiteSpace($cfg.logPath) -and (Test-Path $cfg.logPath)) {
        return [PSCustomObject]@{ Path = $cfg.logPath; Source = 'Config' }
    }

    # 3. Default
    if (Test-Path $cfg.defaultLogPath) {
        return [PSCustomObject]@{ Path = $cfg.defaultLogPath; Source = 'Default' }
    }

    throw "CPM log path not found via registry, config, or default location ($($cfg.defaultLogPath))"
}

function Test-CPMLogEntry {
    <#
    .SYNOPSIS
        Tests if a CPM log line matches error patterns. Returns parsed entry or $null.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Entry,
        [string[]]$ErrorPatterns,
        [string[]]$IgnorePatterns
    )

    # Patterns come from user-editable JSON config -- one invalid regex must
    # skip that pattern, not abort the whole CPM health collection.
    if ($IgnorePatterns) {
        foreach ($pat in $IgnorePatterns) {
            try { if ($Entry -match $pat) { return $null } }
            catch { Write-Log -Message "Invalid ignorePattern regex skipped: $pat" -Level Debug -Component 'CPMHealth' }
        }
    }

    $matchedPattern = $null
    if ($ErrorPatterns) {
        foreach ($pat in $ErrorPatterns) {
            try { if ($Entry -match $pat) { $matchedPattern = $pat; break } }
            catch { Write-Log -Message "Invalid errorPattern regex skipped: $pat" -Level Debug -Component 'CPMHealth' }
        }
        if (-not $matchedPattern) { return $null }
    }

    $parsePattern = '^(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\s+\[(\w+)\]\s+(\w+)\s+(.*)$'
    if ($Entry -match $parsePattern) {
        $ts = $null
        try { $ts = [datetime]::ParseExact($Matches[1], 'yyyy-MM-dd HH:mm:ss', [System.Globalization.CultureInfo]::InvariantCulture) }
        catch { }

        return [PSCustomObject]@{
            Timestamp      = $ts
            Severity       = $Matches[2]
            Code           = $Matches[3]
            Message        = $Matches[4]
            RawEntry       = $Entry
            MatchedPattern = $matchedPattern
        }
    }

    # No parseable timestamp (continuation line / stack dump). Timestamp stays
    # $null: stamping "now" would keep the entry inside the lookback window on
    # EVERY future collection cycle, so the alert would never self-resolve.
    return [PSCustomObject]@{
        Timestamp      = $null
        Severity       = 'UNKNOWN'
        Code           = 'UNKNOWN'
        Message        = $Entry
        RawEntry       = $Entry
        MatchedPattern = $matchedPattern
    }
}

function Read-CPMErrors {
    <#
    .SYNOPSIS
        Reads and parses CPM pm_error.log. Uses -Tail for memory safety.
    #>
    [CmdletBinding()]
    param(
        [string]$LogPath,
        [int]$TailLines       = 0,
        [int]$LookbackMinutes = 0
    )

    $cfg = $script:Config.cpmHealth

    if (-not $LogPath) {
        $logPathResult = Get-CPMLogPath
        $LogPath       = $logPathResult.Path
    }

    if ($TailLines -le 0)       { $TailLines       = $cfg.tailLines }
    if ($LookbackMinutes -le 0) { $LookbackMinutes  = $cfg.lookbackMinutes }

    $logFile = Join-Path $LogPath $cfg.logFileName

    if (-not (Test-Path $logFile)) {
        Write-Log -Message "CPM log file not found: $logFile" -Level Warn -Color Yellow -Component 'CPMHealth'
        return @()
    }

    $threshold = (Get-Date).AddMinutes(-$LookbackMinutes)
    $errors    = @()

    try {
        $lines = Get-Content -Path $logFile -Tail $TailLines -ErrorAction Stop
        $skippedNoTs = 0
        foreach ($line in $lines) {
            if ([string]::IsNullOrWhiteSpace($line)) { continue }
            $parsed = Test-CPMLogEntry -Entry $line -ErrorPatterns $cfg.errorPatterns -IgnorePatterns $cfg.ignorePatterns
            if ($null -eq $parsed) { continue }
            if ($null -eq $parsed.Timestamp) { $skippedNoTs++; continue }
            if ($parsed.Timestamp -ge $threshold) {
                $errors += $parsed
            }
        }
        if ($skippedNoTs -gt 0) {
            Write-Log -Message "$skippedNoTs pattern-matching CPM log line(s) without a parseable timestamp were excluded from the lookback window" -Level Debug -Component 'CPMHealth'
        }
    }
    catch {
        Write-Log -Message "Error reading CPM log: $($_.Exception.Message)" -Level Error -Color Red -Component 'CPMHealth'
        throw
    }

    return $errors
}

function Get-CPMPluginHealth {
    <#
    .SYNOPSIS
        CPM plugin inventory sub-check: counts plugin DLLs/EXEs in the CPM
        bin\Plugins folder and flags obviously broken (zero-byte) ones. Local
        filesystem only; never throws (returns zeros when the folder is absent).
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param([string]$PluginPath)

    $r = [PSCustomObject]@{ Total = 0; Unhealthy = 0; Path = ''; UnhealthyNames = @() }

    if ([string]::IsNullOrWhiteSpace($PluginPath)) {
        try {
            $ip = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\CyberArk\Password Manager' -Name 'InstallPath' -ErrorAction Stop).InstallPath
            if ($ip) { $PluginPath = Join-Path $ip 'bin\Plugins' }
        }
        catch { }
        if ([string]::IsNullOrWhiteSpace($PluginPath)) { $PluginPath = 'C:\Program Files (x86)\CyberArk\Password Manager\bin\Plugins' }
    }
    $r.Path = $PluginPath
    if (-not (Test-Path $PluginPath)) { return $r }

    try {
        $files = @(Get-ChildItem -Path $PluginPath -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -in '.dll','.exe' })
        $r.Total = $files.Count
        foreach ($f in $files) {
            if ($f.Length -eq 0) { $r.Unhealthy++; $r.UnhealthyNames += $f.Name }
        }
    }
    catch { }
    return $r
}

function Collect-CPMHealth {
    <#
    .SYNOPSIS
        Main CPM health orchestrator: discovers log path, reads errors, returns structured result.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param()

    $startTime = Get-Date
    Write-Log -Message 'Starting CPM health collection' -Level Debug -Component 'CPMHealth'

    if ($UseMockData -or -not (Test-IsWindowsPlatform)) {
        Write-Log -Message 'Using mock data for CPM health' -Level Debug -Component 'CPMHealth'
        return Get-MockData -DataType 'CPMHealth'
    }

    $result = [PSCustomObject]@{
        Status          = 'Unknown'
        Errors          = @()
        ErrorCount      = 0
        ErrorCountTotal = 0
        Recency         = $null
        CheckedAt       = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
        LogPath         = ''
        LogPathSource   = ''
        LookbackMinutes = $script:Config.cpmHealth.lookbackMinutes
        ServerName      = $env:COMPUTERNAME
        CorrelationID   = $script:CorrelationID
        Duration        = ''
        IsMockData      = $false
        ErrorMessage    = $null
        PluginTotal     = 0
        PluginUnhealthy = 0
        PluginPath      = ''
    }

    # Component-present gate: skip cleanly on a host with no CPM installed rather
    # than surfacing a scary 'Error'/false alert.
    if (-not (Test-CAComponentPresent -ServiceNames @('CyberArk Password Manager','CyberArk Central Policy Manager Scanner') `
              -RegistryPaths @($script:Config.cpmHealth.registryPath) `
              -FilePaths @($script:Config.cpmHealth.logPath, $script:Config.cpmHealth.defaultLogPath))) {
        $result.Status   = 'NotInstalled'
        $result.Duration = ((Get-Date) - $startTime).ToString()
        Write-Log -Message 'CPM not installed on this host -- skipping CPM health' -Level Debug -Component 'CPMHealth'
        return $result
    }

    try {
        $logPathResult    = Get-CPMLogPath
        $result.LogPath   = Join-Path $logPathResult.Path $script:Config.cpmHealth.logFileName
        $result.LogPathSource = $logPathResult.Source

        # Read all errors across the recency month window (not the old 60-min slice),
        # then bucket by timestamp. ErrorCount stays the RECENT-window count so the
        # orchestrator's cpmErrorWarning/Critical alerting is now recency-based.
        $rc = Resolve-RecencyConfig
        $errors            = @(Read-CPMErrors -LogPath $logPathResult.Path -LookbackMinutes ($rc.Month * 60))
        $result.Errors     = $errors
        $recency           = Get-RecencyProfile -Timestamps @($errors | ForEach-Object { $_.Timestamp }) -DayHours $rc.Day -WeekHours $rc.Week -MonthHours $rc.Month
        $result.Recency    = $recency
        $result.ErrorCount = [int]$recency[$rc.AlertKey]
        $result.ErrorCountTotal = [int]$recency.total
        $result.Status     = if ($result.ErrorCount -eq 0) { 'Healthy' } else { 'Unhealthy' }
    }
    catch {
        $result.Status       = 'Error'
        $result.ErrorMessage = $_.Exception.Message
        Write-Log -Message "CPM health collection failed: $($_.Exception.Message)" -Level Error -Color Red -Component 'CPMHealth'
    }

    # Plugin inventory sub-check (CPM confirmed present by the gate above).
    try {
        $plugins = Get-CPMPluginHealth -PluginPath $script:Config.cpmHealth.pluginsPath
        $result.PluginTotal     = $plugins.Total
        $result.PluginUnhealthy = $plugins.Unhealthy
        $result.PluginPath      = $plugins.Path
    }
    catch { }

    $result.Duration = ((Get-Date) - $startTime).ToString()
    $cpmLogNote = if ($result.LogPath) { " reading $($result.LogPath) [$($result.LogPathSource)]" } else { '' }
    Write-Log -Message "CPM health collected: $($result.Status) (Errors recent: $($result.ErrorCount), 30d total: $($result.ErrorCountTotal))$cpmLogNote" -Level Info -Component 'CPMHealth'

    return $result
}

#endregion

#region PSM Health

function Get-PSMLogPath {
    <#
    .SYNOPSIS
        Discovers PSM log directory from registry, config, or default path.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param()

    $cfg = $script:Config.psmHealth

    # 1. Registry
    try {
        $installPath = (Get-ItemProperty -Path $cfg.registryPath -Name $cfg.registryValue -ErrorAction Stop).($cfg.registryValue)
        $logPath     = Join-Path $installPath 'Logs'
        if (Test-Path $logPath) {
            return [PSCustomObject]@{ Path = $logPath; Source = 'Registry' }
        }
    }
    catch { }

    # 2. Config path
    if (-not [string]::IsNullOrWhiteSpace($cfg.logPath) -and (Test-Path $cfg.logPath)) {
        return [PSCustomObject]@{ Path = $cfg.logPath; Source = 'Config' }
    }

    # 3. Default
    if (Test-Path $cfg.defaultLogPath) {
        return [PSCustomObject]@{ Path = $cfg.defaultLogPath; Source = 'Default' }
    }

    throw "PSM log path not found via registry, config, or default location ($($cfg.defaultLogPath))"
}

function Get-PSMServiceStatus {
    <#
    .SYNOPSIS
        Retrieves PSM service status (name, status, start type).
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param()

    $serviceName = $script:Config.psmHealth.serviceName

    try {
        $service = Get-Service -Name $serviceName -ErrorAction Stop
        return [PSCustomObject]@{
            Name        = $service.Name
            DisplayName = $service.DisplayName
            Status      = $service.Status.ToString()
            StartType   = $service.StartType.ToString()
            Found       = $true
        }
    }
    catch [Microsoft.PowerShell.Commands.ServiceCommandException] {
        return [PSCustomObject]@{
            Name        = $serviceName
            DisplayName = ''
            Status      = 'NotFound'
            StartType   = 'Unknown'
            Found       = $false
        }
    }
    catch {
        return [PSCustomObject]@{
            Name        = $serviceName
            DisplayName = ''
            Status      = 'Error'
            StartType   = 'Unknown'
            Found       = $false
            Error       = $_.Exception.Message
        }
    }
}

function Read-PSMShadowUserErrors {
    <#
    .SYNOPSIS
        Reads PSMConsole.log for Shadow User creation errors. Uses -Tail for memory safety.
    #>
    [CmdletBinding()]
    [OutputType([PSObject[]])]
    param(
        [string]$LogPath,
        [int]$TailLines       = 0,
        [int]$LookbackMinutes = 0
    )

    $cfg = $script:Config.psmHealth
    if ($TailLines -le 0)       { $TailLines       = $cfg.tailLines }
    if ($LookbackMinutes -le 0) { $LookbackMinutes = $cfg.lookbackMinutes }

    if ([string]::IsNullOrWhiteSpace($LogPath)) {
        try {
            $pathInfo = Get-PSMLogPath
            $LogPath  = Join-Path $pathInfo.Path $cfg.logFileName
        }
        catch {
            Write-Log -Message "Cannot find PSM log path: $($_.Exception.Message)" -Level Warn -Color Yellow -Component 'PSMHealth'
            return @()
        }
    }

    if (-not (Test-Path $LogPath)) {
        Write-Log -Message "PSM log file not found: $LogPath" -Level Warn -Color Yellow -Component 'PSMHealth'
        return @()
    }

    $shadowPatterns = @('Shadow User','CreateLocalUser','Failed to create','Local user creation')
    $cutoff         = (Get-Date).AddMinutes(-$LookbackMinutes)
    $errors         = @()

    try {
        $lines = Get-Content -Path $LogPath -Tail $TailLines -ErrorAction Stop
        foreach ($line in $lines) {
            if ($line -match '^(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\s+\[(\w+)\]\s+(.+)$') {
                $ts  = $null
                try { $ts = [datetime]::ParseExact($Matches[1], 'yyyy-MM-dd HH:mm:ss', [System.Globalization.CultureInfo]::InvariantCulture) } catch { continue }
                if ($ts -lt $cutoff) { continue }

                $sev     = $Matches[2]
                $message = $Matches[3]
                if ($sev -ne 'ERROR' -and $sev -ne 'WARN') { continue }

                $matched = $null
                foreach ($pat in $shadowPatterns) {
                    if ($message -match $pat) { $matched = $pat; break }
                }

                if ($matched) {
                    $errors += [PSCustomObject]@{
                        Timestamp      = $ts
                        Severity       = $sev
                        Message        = $message
                        MatchedPattern = $matched
                        RawEntry       = $line
                    }
                }
            }
        }
    }
    catch {
        Write-Log -Message "Error reading PSM shadow user log: $($_.Exception.Message)" -Level Error -Color Red -Component 'PSMHealth'
    }

    return $errors
}

function Get-PSMErrorCategory {
    <#
    .SYNOPSIS
        Categorizes a PSM error message: Browser, RDP, SSH, User, or Unknown.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory)][string]$ErrorMessage
    )

    $browserPats = @('failed to initialize web browser','Session has been closed','failed to find element',
                     'Element is not clickable','BrowserPath','ChromeDriver','msedgedriver','WebDriver',
                     'selenium','browser not found')
    $rdpPats     = @('Network Level Authentication','NLA','Licensing timed out','CredSSP',
                     'RDP connection failed','Remote Desktop','certificate','TLS','SSL handshake')
    $sshPats     = @('handshake failed','Connection refused','unable to authenticate',
                     'Server refused our key','Host key verification failed','SSH connection','key exchange')
    $userPats    = @('Access Denied','Bad password','Authentication failure','Invalid credentials',
                     'Account locked','Password expired','Logon failure')

    foreach ($p in $browserPats) { if ($ErrorMessage -match [regex]::Escape($p)) { return 'Browser' } }
    foreach ($p in $rdpPats)     { if ($ErrorMessage -match [regex]::Escape($p)) { return 'RDP' } }
    foreach ($p in $sshPats)     { if ($ErrorMessage -match [regex]::Escape($p)) { return 'SSH' } }
    foreach ($p in $userPats)    { if ($ErrorMessage -match [regex]::Escape($p)) { return 'User' } }

    return 'Unknown'
}

function Read-PSMCategorizedErrors {
    <#
    .SYNOPSIS
        Reads PSMConsole.log and categorizes all ERROR/WARN lines into Browser/RDP/SSH/User/Unknown.
        Returns Errors array and Summary.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [string]$LogPath,
        [int]$TailLines       = 0,
        [int]$LookbackMinutes = 0
    )

    $cfg = $script:Config.psmHealth
    if ($TailLines -le 0)       { $TailLines       = $cfg.tailLines }
    if ($LookbackMinutes -le 0) { $LookbackMinutes = $cfg.lookbackMinutes }

    $emptySummary = [PSCustomObject]@{
        BrowserErrors    = 0; RDPErrors = 0; SSHErrors = 0
        UserErrors       = 0; UnknownErrors = 0
        SystemErrorCount = 0; UserErrorCount = 0
    }

    if ([string]::IsNullOrWhiteSpace($LogPath)) {
        try {
            $pathInfo = Get-PSMLogPath
            $LogPath  = Join-Path $pathInfo.Path $cfg.logFileName
        }
        catch {
            Write-Log -Message "Cannot find PSM log path: $($_.Exception.Message)" -Level Warn -Color Yellow -Component 'PSMHealth'
            return [PSCustomObject]@{ Errors = @(); Summary = $emptySummary }
        }
    }

    if (-not (Test-Path $LogPath)) {
        return [PSCustomObject]@{ Errors = @(); Summary = $emptySummary }
    }

    $errors        = @()
    $cutoff        = (Get-Date).AddMinutes(-$LookbackMinutes)
    $browserCount  = 0; $rdpCount = 0; $sshCount = 0; $userCount = 0; $unknownCount = 0

    try {
        $lines = Get-Content -Path $LogPath -Tail $TailLines -ErrorAction Stop
        foreach ($line in $lines) {
            if ($line -match '^(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\s+\[(\w+)\]\s+(.+)$') {
                $ts  = $null
                try { $ts = [datetime]::ParseExact($Matches[1], 'yyyy-MM-dd HH:mm:ss', [System.Globalization.CultureInfo]::InvariantCulture) } catch { continue }
                if ($ts -lt $cutoff) { continue }

                $sev     = $Matches[2]
                $message = $Matches[3]
                if ($sev -ne 'ERROR' -and $sev -ne 'WARN') { continue }

                $category = Get-PSMErrorCategory -ErrorMessage $message
                switch ($category) {
                    'Browser' { $browserCount++ }
                    'RDP'     { $rdpCount++ }
                    'SSH'     { $sshCount++ }
                    'User'    { $userCount++ }
                    'Unknown' { $unknownCount++ }
                }

                $errors += [PSCustomObject]@{
                    Timestamp = $ts
                    Severity  = $sev
                    Message   = $message
                    Category  = $category
                    RawEntry  = $line
                }
            }
        }
    }
    catch {
        Write-Log -Message "Error reading PSM log (categorized): $($_.Exception.Message)" -Level Error -Color Red -Component 'PSMHealth'
        return [PSCustomObject]@{ Errors = @(); Summary = $emptySummary }
    }

    $systemErrCount = $browserCount + $rdpCount + $sshCount
    $summary = [PSCustomObject]@{
        BrowserErrors    = $browserCount
        RDPErrors        = $rdpCount
        SSHErrors        = $sshCount
        UserErrors       = $userCount
        UnknownErrors    = $unknownCount
        SystemErrorCount = $systemErrCount
        UserErrorCount   = $userCount
    }

    return [PSCustomObject]@{ Errors = $errors; Summary = $summary }
}

function Get-PSMConnectionComponentHealth {
    <#
    .SYNOPSIS
        Validates PSM connection components: parses each Components\*.ini and
        confirms the referenced client executable (ClientApp/BrowserPath) exists.
        Config-only validation (no live sessions). Never throws.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param([string]$ComponentsPath)

    $r = [PSCustomObject]@{ Total = 0; Invalid = 0; Path = ''; InvalidNames = @() }

    if ([string]::IsNullOrWhiteSpace($ComponentsPath)) {
        try { $info = Get-PSMComponentsPath; if ($info -and $info.Exists) { $ComponentsPath = $info.Path } } catch { }
    }
    $r.Path = $ComponentsPath
    if ([string]::IsNullOrWhiteSpace($ComponentsPath) -or -not (Test-Path $ComponentsPath)) { return $r }

    try {
        $inis = @(Get-ChildItem -Path $ComponentsPath -Filter '*.ini' -File -ErrorAction SilentlyContinue)
        $r.Total = $inis.Count
        foreach ($ini in $inis) {
            try {
                $data = @{}
                foreach ($line in (Get-Content -Path $ini.FullName -ErrorAction Stop)) {
                    if ($line -match '^\s*([^;=\[][^=]*?)\s*=\s*(.+?)\s*$') { $data[$Matches[1].Trim()] = $Matches[2].Trim() }
                }
                $exe = if ($data.ContainsKey('ClientApp')) { $data['ClientApp'] } elseif ($data.ContainsKey('BrowserPath')) { $data['BrowserPath'] } else { $null }
                # Only validate settings that name a concrete path (skip dispatcher
                # tokens / relative component references).
                if ($exe -and ($exe -match '\.exe' -or $exe -match ':\\')) {
                    $exePath = [System.Environment]::ExpandEnvironmentVariables($exe)
                    if (-not (Test-Path $exePath)) { $r.Invalid++; $r.InvalidNames += $ini.BaseName }
                }
            }
            catch { $r.Invalid++; $r.InvalidNames += $ini.BaseName }
        }
    }
    catch { }
    return $r
}

function Get-PSMRecordingHealth {
    <#
    .SYNOPSIS
        PSM recording-storage backlog sub-check: free space on the Recordings
        volume plus pending-file count and oldest-pending age (uploads stuck?).
        Local filesystem only; never throws.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param([string]$RecordingsPath, [double]$WarnGB = 10, [double]$CriticalGB = 2)

    $r = [PSCustomObject]@{ Path = ''; FreeGB = $null; FreeSpacePercent = $null; PendingCount = 0; OldestPendingHours = $null; Status = 'OK' }

    if ([string]::IsNullOrWhiteSpace($RecordingsPath)) {
        foreach ($reg in @('HKLM:\SOFTWARE\CyberArk\PSM','HKLM:\SOFTWARE\CyberArk\PrivilegedSessionManager')) {
            try {
                $il = (Get-ItemProperty -Path $reg -Name 'InstallLocation' -ErrorAction Stop).InstallLocation
                if ($il) { $cand = Join-Path $il 'Recordings'; if (Test-Path $cand) { $RecordingsPath = $cand; break } }
            }
            catch { }
        }
        if ([string]::IsNullOrWhiteSpace($RecordingsPath)) { $RecordingsPath = 'C:\Program Files (x86)\CyberArk\PSM\Recordings' }
    }
    $r.Path = $RecordingsPath
    if (-not (Test-Path $RecordingsPath)) { $r.Status = 'NotFound'; return $r }

    # Free space: local drive-letter paths via Get-PSDrive; UNC shares (the
    # COMMON topology for PSM recordings) via Scripting.FileSystemObject, which
    # resolves share capacity. Split-Path -Qualifier THROWS on UNC paths.
    try {
        if ($RecordingsPath -match '^\\\\') {
            $fso = New-Object -ComObject Scripting.FileSystemObject
            $drv = $fso.GetDrive($fso.GetDriveName($RecordingsPath))
            $r.FreeGB = [math]::Round($drv.AvailableSpace / 1GB, 2)
            if ($drv.TotalSize -gt 0) { $r.FreeSpacePercent = [math]::Round(($drv.AvailableSpace / $drv.TotalSize) * 100, 2) }
        }
        else {
            $qualifier = (Split-Path -Qualifier $RecordingsPath).Replace(':','')
            $drive = Get-PSDrive -Name $qualifier -ErrorAction Stop
            $r.FreeGB = [math]::Round($drive.Free / 1GB, 2)
            $tot = $drive.Free + $drive.Used
            if ($tot -gt 0) { $r.FreeSpacePercent = [math]::Round(($drive.Free / $tot) * 100, 2) }
        }
    }
    catch {
        Write-Log -Message "Recording free-space probe failed for '$RecordingsPath': $($_.Exception.Message)" -Level Debug -Component 'PSMHealth'
    }

    try {
        $files = @(Get-ChildItem -Path $RecordingsPath -File -ErrorAction SilentlyContinue)
        $r.PendingCount = $files.Count
        if ($files.Count -gt 0) {
            $oldest = $files | Sort-Object CreationTime | Select-Object -First 1
            $r.OldestPendingHours = [math]::Round(((Get-Date) - $oldest.CreationTime).TotalHours, 2)
        }
    }
    catch { }

    # Judge thresholds ONLY on a real measurement -- an unmeasured share must
    # report Unknown, never a false Critical (FreeGB 0) that pages someone.
    if ($null -eq $r.FreeGB)         { $r.Status = 'Unknown' }
    elseif ($r.FreeGB -le $CriticalGB) { $r.Status = 'Critical' }
    elseif ($r.FreeGB -le $WarnGB)   { $r.Status = 'Warning' }
    else                             { $r.Status = 'OK' }
    return $r
}

function Collect-PSMHealth {
    <#
    .SYNOPSIS
        Main PSM health orchestrator: service status, shadow user errors, categorized errors.
        Vault connectivity is handled in Region 16 (Collect-Connectivity).
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param()

    $startTime = Get-Date
    Write-Log -Message 'Starting PSM health collection' -Level Debug -Component 'PSMHealth'

    if ($UseMockData -or -not (Test-IsWindowsPlatform)) {
        Write-Log -Message 'Using mock data for PSM health' -Level Debug -Component 'PSMHealth'
        return Get-MockData -DataType 'PSMHealth'
    }

    $result = [PSCustomObject]@{
        Status            = 'Unknown'
        CheckedAt         = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
        CorrelationID     = $script:CorrelationID
        ServerName        = $env:COMPUTERNAME
        Component         = 'PSM'
        ServiceStatus     = $null
        ShadowUserErrors  = @()
        CategorizedErrors = $null
        SystemErrorCount  = 0
        SystemErrorCountTotal = 0
        Recency           = $null
        UserErrorCount    = 0
        ErrorCategories   = $null
        Duration          = $null
        IsMockData        = $false
        ErrorMessage      = $null
        ConnComponentsTotal   = 0
        ConnComponentsInvalid = 0
        RecordingStatus       = 'OK'
        RecordingFreeGB       = 0
        RecordingPendingCount = 0
        RecordingOldestPendingHours = $null
    }

    # Component-present gate: a host with no PSM must not raise a Critical. Probe
    # both known PSM registry roots (\PSM and \PrivilegedSessionManager).
    if (-not (Test-CAComponentPresent -ServiceNames @($script:Config.psmHealth.serviceName) `
              -RegistryPaths @($script:Config.psmHealth.registryPath, 'HKLM:\SOFTWARE\CyberArk\PrivilegedSessionManager') `
              -FilePaths @($script:Config.psmHealth.logPath, $script:Config.psmHealth.defaultLogPath))) {
        $result.Status   = 'NotInstalled'
        $result.Duration = ((Get-Date) - $startTime).ToString('hh\:mm\:ss\.fff')
        Write-Log -Message 'PSM not installed on this host -- skipping PSM health' -Level Debug -Component 'PSMHealth'
        return $result
    }

    $isHealthy = $true

    # Service status
    try {
        $result.ServiceStatus = Get-PSMServiceStatus
        if ($result.ServiceStatus.Status -ne 'Running') { $isHealthy = $false }
    }
    catch {
        $result.ServiceStatus = [PSCustomObject]@{ Status = 'Error'; Error = $_.Exception.Message }
        $isHealthy = $false
    }

    # Shadow user errors
    try {
        # @() -- an empty return unrolls to $null and .Count throws under StrictMode
        $shadowErrors            = @(Read-PSMShadowUserErrors)
        $result.ShadowUserErrors = $shadowErrors
        if ($shadowErrors.Count -gt 0) { $isHealthy = $false }
    }
    catch {
        Write-Log -Message "Shadow user check error: $($_.Exception.Message)" -Level Warn -Color Yellow -Component 'PSMHealth'
    }

    # Categorized errors -- read the recency month window, then bucket the SYSTEM
    # errors (Browser/RDP/SSH) so SystemErrorCount (the alert driver) is recent-only.
    try {
        $rc = Resolve-RecencyConfig
        $catResult                = Read-PSMCategorizedErrors -LookbackMinutes ($rc.Month * 60)
        $result.CategorizedErrors = $catResult.Errors
        $sysErrs = @($catResult.Errors | Where-Object { $_.Category -in @('Browser','RDP','SSH') })
        $psmRecency = Get-RecencyProfile -Timestamps @($sysErrs | ForEach-Object { $_.Timestamp }) -DayHours $rc.Day -WeekHours $rc.Week -MonthHours $rc.Month
        $result.Recency          = $psmRecency
        $result.SystemErrorCount = [int]$psmRecency[$rc.AlertKey]
        $result.SystemErrorCountTotal = [int]$psmRecency.total
        $result.UserErrorCount    = $catResult.Summary.UserErrorCount
        $result.ErrorCategories   = [PSCustomObject]@{
            Browser = $catResult.Summary.BrowserErrors
            RDP     = $catResult.Summary.RDPErrors
            SSH     = $catResult.Summary.SSHErrors
            User    = $catResult.Summary.UserErrors
            Unknown = $catResult.Summary.UnknownErrors
        }
        if ($result.SystemErrorCount -gt 0) { $isHealthy = $false }
    }
    catch {
        Write-Log -Message "Categorized error check failed: $($_.Exception.Message)" -Level Warn -Color Yellow -Component 'PSMHealth'
    }

    # Connection-component validation sub-check
    try {
        $cc = Get-PSMConnectionComponentHealth -ComponentsPath $script:Config.psmHealth.componentsPath
        $result.ConnComponentsTotal   = $cc.Total
        $result.ConnComponentsInvalid = $cc.Invalid
        if ($cc.Invalid -gt 0) { $isHealthy = $false }
    }
    catch { }

    # Recording-storage backlog sub-check
    try {
        $rec = Get-PSMRecordingHealth -RecordingsPath $script:Config.psmHealth.recordingsPath `
            -WarnGB $script:Config.psmHealth.recordingWarnGB -CriticalGB $script:Config.psmHealth.recordingCriticalGB
        $result.RecordingStatus            = $rec.Status
        $result.RecordingFreeGB            = $rec.FreeGB
        $result.RecordingPendingCount      = $rec.PendingCount
        $result.RecordingOldestPendingHours = $rec.OldestPendingHours
        if ($rec.Status -in @('Warning','Critical')) { $isHealthy = $false }
    }
    catch { }

    $result.Status   = if ($isHealthy) { 'Healthy' } else { 'Unhealthy' }
    $result.Duration = ((Get-Date) - $startTime).ToString('hh\:mm\:ss\.fff')

    $psmLogNote = ''
    try { $pi = Get-PSMLogPath; $psmLogNote = " reading $(Join-Path $pi.Path $script:Config.psmHealth.logFileName) [$($pi.Source)]" } catch { $psmLogNote = ' (PSM log path not found)' }
    Write-Log -Message "PSM health collected: $($result.Status) (SysErrors:$($result.SystemErrorCount) UserErrors:$($result.UserErrorCount))$psmLogNote" -Level Info -Component 'PSMHealth'

    return $result
}

#endregion

#region Connectivity Tests

function Test-PortConnectivity {
    <#
    .SYNOPSIS
        Tests TCP connectivity to a given host and port using TcpClient.
        Works on Windows and non-Windows (no dependency on Test-NetConnection).
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)][string]$Target,
        [Parameter(Mandatory)][int]$Port,
        [string]$Description       = '',
        [int]$TimeoutSeconds       = 5,
        [int]$RetryCount           = 1,
        [int]$RetryDelaySeconds    = 3
    )

    if ($RetryCount -lt 1) { $RetryCount = 1 }
    $reachable = $false
    $errorMsg  = $null
    $latencyMs = $null
    $attempts  = 0

    for ($attempt = 1; $attempt -le $RetryCount; $attempt++) {
        $attempts = $attempt
        $sw       = [System.Diagnostics.Stopwatch]::StartNew()
        $client   = $null
        $errorMsg = $null

        try {
            $client   = [System.Net.Sockets.TcpClient]::new()
            $task     = $client.ConnectAsync($Target, $Port)
            $completed = $task.Wait($TimeoutSeconds * 1000)
            if ($completed -and -not $task.IsFaulted) {
                $reachable = $true
            }
            else {
                $errorMsg = if ($task.Exception -and $task.Exception.InnerException) { $task.Exception.InnerException.Message }
                            elseif ($task.Exception) { $task.Exception.Message }
                            else { 'Timeout' }
            }
        }
        catch {
            # Unwrap AggregateException from Task.Wait for a readable message
            $errorMsg = if ($_.Exception.InnerException) { $_.Exception.InnerException.Message } else { $_.Exception.Message }
        }
        finally {
            $sw.Stop()
            # Always dispose -- on timeout the socket (and the still-running
            # ConnectAsync) would otherwise leak a handle per failed check.
            if ($null -ne $client) { try { $client.Dispose() } catch { } }
        }

        if ($reachable) {
            $latencyMs = $sw.ElapsedMilliseconds
            break
        }

        if ($attempt -lt $RetryCount) {
            Write-Log -Message "Retry $attempt/$($RetryCount - 1) for ${Target}:${Port} in ${RetryDelaySeconds}s ($errorMsg)" -Level Debug -Component 'Connectivity'
            Start-Sleep -Seconds $RetryDelaySeconds
        }
    }

    return [PSCustomObject]@{
        Target      = $Target
        Port        = $Port
        Reachable   = $reachable
        LatencyMs   = $latencyMs
        Status      = if ($reachable) { 'Connected' } else { 'Unreachable' }
        Description = $Description
        Error       = $errorMsg
        Attempts    = $attempts
        IsMockData  = $false
    }
}

function Test-PingConnectivity {
    <#
    .SYNOPSIS
        Tests ICMP reachability to a host using System.Net.NetworkInformation.Ping,
        with the same retry semantics as Test-PortConnectivity. Returns the same
        result shape (Port = $null, Description defaults to 'ICMP Ping').
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)][string]$Target,
        [string]$Description       = 'ICMP Ping',
        [int]$TimeoutSeconds       = 5,
        [int]$RetryCount           = 1,
        [int]$RetryDelaySeconds    = 3
    )

    if ($RetryCount -lt 1) { $RetryCount = 1 }
    $reachable = $false
    $errorMsg  = $null
    $latencyMs = $null
    $attempts  = 0

    for ($attempt = 1; $attempt -le $RetryCount; $attempt++) {
        $attempts = $attempt
        $pinger   = $null
        $errorMsg = $null

        try {
            $pinger = [System.Net.NetworkInformation.Ping]::new()
            $reply  = $pinger.Send($Target, $TimeoutSeconds * 1000)
            if ($reply.Status -eq [System.Net.NetworkInformation.IPStatus]::Success) {
                $reachable = $true
                $latencyMs = $reply.RoundtripTime
            }
            else {
                $errorMsg = "Ping status: $($reply.Status)"
            }
        }
        catch {
            $errorMsg = $_.Exception.Message
        }
        finally {
            if ($null -ne $pinger) { try { $pinger.Dispose() } catch { } }
        }

        if ($reachable) { break }

        if ($attempt -lt $RetryCount) {
            Write-Log -Message "Ping retry $attempt/$($RetryCount - 1) for $Target in ${RetryDelaySeconds}s ($errorMsg)" -Level Debug -Component 'Connectivity'
            Start-Sleep -Seconds $RetryDelaySeconds
        }
    }

    return [PSCustomObject]@{
        Target      = $Target
        Port        = $null
        Reachable   = $reachable
        LatencyMs   = $latencyMs
        Status      = if ($reachable) { 'Connected' } else { 'Unreachable' }
        Description = $Description
        Error       = $errorMsg
        Attempts    = $attempts
        IsMockData  = $false
    }
}

function Test-VaultConnectivity {
    <#
    .SYNOPSIS
        Tests TCP connectivity to configured Vault server(s) on port 1858 (or configured port).
        Returns array of connectivity results.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject[]])]
    param()

    $cfg     = $script:Config.connectivity
    $results = @()

    # Primary vault address
    if (-not [string]::IsNullOrWhiteSpace($cfg.vaultAddress)) {
        $results += Test-PortConnectivity -Target $cfg.vaultAddress -Port $cfg.vaultPort `
            -Description 'CyberArk Vault' -TimeoutSeconds $cfg.timeoutSeconds
    }

    return $results
}

function ConvertTo-FarmPeerSpec {
    <#
    .SYNOPSIS
        Normalizes a farm peer entry into @{ Host; Ports[]; Ping }.
        Accepts strings ('host', 'host:3389', 'host:1858,443' -- bare host means
        ICMP ping) or objects/hashtables ({ host; ports[]; ping }).
        Returns $null for entries that cannot be parsed.
    #>
    [CmdletBinding()]
    param([Parameter(Mandatory)] $Entry)

    $peerHost = $null
    $ports    = @()
    $ping     = $false

    if ($Entry -is [string]) {
        # Strip stray quote chars -- never legal in a hostname, but they appear
        # when a caller's shell quoting leaked into the value (-File args).
        $s = ($Entry -replace "['`"]", '').Trim()
        if ([string]::IsNullOrWhiteSpace($s)) { return $null }
        $idx = $s.IndexOf(':')
        if ($idx -lt 0) {
            $peerHost = $s
            $ping     = $true
        }
        else {
            $peerHost = $s.Substring(0, $idx)
            foreach ($p in ($s.Substring($idx + 1) -split ',')) {
                $portNum = 0
                if ([int]::TryParse($p.Trim(), [ref]$portNum) -and $portNum -ge 1 -and $portNum -le 65535) {
                    $ports += $portNum
                }
            }
            if ($ports.Count -eq 0) { $ping = $true }  # 'host:' or junk ports -- fall back to ping
        }
    }
    else {
        # Hashtable (from defaults) or PSCustomObject (from JSON config)
        $peerHost = if ($Entry -is [hashtable]) { $Entry['host'] } else { Get-PSPropertySafe -Object $Entry -Name 'host' }
        if ([string]::IsNullOrWhiteSpace($peerHost)) { return $null }
        $rawPorts = if ($Entry -is [hashtable]) { $Entry['ports'] } else { Get-PSPropertySafe -Object $Entry -Name 'ports' }
        foreach ($p in @($rawPorts)) {
            $portNum = 0
            if ($null -ne $p -and [int]::TryParse("$p", [ref]$portNum) -and $portNum -ge 1 -and $portNum -le 65535) {
                $ports += $portNum
            }
        }
        $rawPing = if ($Entry -is [hashtable]) { $Entry['ping'] } else { Get-PSPropertySafe -Object $Entry -Name 'ping' }
        if ($null -ne $rawPing) { $ping = [bool]$rawPing }
        if ($ports.Count -eq 0) { $ping = $true }
    }

    if ([string]::IsNullOrWhiteSpace($peerHost)) { return $null }

    return @{ Host = "$peerHost"; Ports = $ports; Ping = $ping }
}

function Update-PeerStatus {
    <#
    .SYNOPSIS
        Down-grace state machine for one farm-peer target. Tracks failures in
        persistent state (platform-state.json > peerStatus) so a peer must fail
        2+ consecutive check-ins AND stay down past the grace window before it
        is confirmed Down. Transient errors surface as 'Suspect' (no alert).
    .OUTPUTS
        [string] PeerState: 'OK', 'Recovered', 'Suspect', or 'Down'.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory)][string]$PeerKey,
        [Parameter(Mandatory)][bool]$Reachable,
        [Parameter()][string]$ErrorMessage = '',
        [Parameter()][int]$GraceSeconds = 150
    )

    $state = $script:PlatformState
    if ($null -eq $state) {
        # No persistent state (should not happen in normal modes) -- report the
        # raw result with no grace window rather than hiding a real failure.
        return $(if ($Reachable) { 'OK' } else { 'Down' })
    }

    if ($null -eq $state['peerStatus']) { $state['peerStatus'] = [ordered]@{} }
    $peers  = $state['peerStatus']
    $now    = (Get-Date).ToUniversalTime()
    $nowStr = $now.ToString('o')

    if (-not $peers.Contains($PeerKey)) {
        $peers[$PeerKey] = [ordered]@{
            firstFailedAt       = $null
            lastOkAt            = $null
            consecutiveFailures = 0
            confirmedDown       = $false
            lastError           = $null
        }
    }
    $entry = $peers[$PeerKey]

    if ($Reachable) {
        $wasDown    = [bool]$entry['confirmedDown']
        $wasFailing = ([int]$entry['consecutiveFailures'] -gt 0)
        $entry['lastOkAt']            = $nowStr
        $entry['firstFailedAt']       = $null
        $entry['consecutiveFailures'] = 0
        $entry['confirmedDown']       = $false
        $entry['lastError']           = $null

        if ($wasDown) {
            Write-Log -Message "Farm peer RECOVERED: $PeerKey" -Level Info -Color Green -Component 'FarmPeer'
            return 'Recovered'
        }
        if ($wasFailing) {
            Write-Log -Message "Farm peer recovered within grace window (no alert was raised): $PeerKey" -Level Info -Color Green -Component 'FarmPeer'
        }
        return 'OK'
    }

    # Failure path
    $entry['consecutiveFailures'] = [int]$entry['consecutiveFailures'] + 1
    $entry['lastError']           = $ErrorMessage
    if ($null -eq $entry['firstFailedAt']) {
        $entry['firstFailedAt'] = $nowStr
    }

    if ([bool]$entry['confirmedDown']) { return 'Down' }

    $elapsedSec = 0
    try {
        $firstFailed = [datetime]::Parse($entry['firstFailedAt']).ToUniversalTime()
        $elapsedSec  = ($now - $firstFailed).TotalSeconds
    }
    catch { }

    if ([int]$entry['consecutiveFailures'] -ge 2 -and $elapsedSec -ge $GraceSeconds) {
        $entry['confirmedDown'] = $true
        Write-Log -Message "Farm peer confirmed DOWN: $PeerKey (failing for $([math]::Round($elapsedSec, 0))s across $($entry['consecutiveFailures']) check-ins; last error: $ErrorMessage)" -Level Error -Color Red -Component 'FarmPeer'
        return 'Down'
    }

    Write-Log -Message "Farm peer suspect (grace window active, $([math]::Round($elapsedSec, 0))s/$($GraceSeconds)s, failures: $($entry['consecutiveFailures'])): $PeerKey ($ErrorMessage)" -Level Warn -Color Yellow -Component 'FarmPeer'
    return 'Suspect'
}

function Collect-Connectivity {
    <#
    .SYNOPSIS
        Runs all configured connectivity tests: vault, PSM servers, any extra ports,
        and farm peers (TCP and/or ICMP with in-run retries + down-grace tracking).
        Returns array of connectivity result objects.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject[]])]
    param()

    Write-Log -Message 'Starting connectivity tests' -Level Debug -Component 'Connectivity'

    if ($UseMockData) {
        Write-Log -Message 'Using mock data for connectivity' -Level Debug -Component 'Connectivity'
        return Get-MockData -DataType 'Connectivity'
    }

    $results = @()
    $cfg     = $script:Config.connectivity

    # In-run retry settings (absorb transient network errors within one check-in)
    $retryCount = 2
    $retryDelay = 3
    $graceSec   = 150
    try {
        if ($null -ne $cfg.retryCount -and [int]$cfg.retryCount -ge 1)           { $retryCount = [int]$cfg.retryCount }
        if ($null -ne $cfg.retryDelaySeconds -and [int]$cfg.retryDelaySeconds -ge 0) { $retryDelay = [int]$cfg.retryDelaySeconds }
        if ($null -ne $cfg.peerDownGraceSeconds -and [int]$cfg.peerDownGraceSeconds -ge 0) { $graceSec = [int]$cfg.peerDownGraceSeconds }
    }
    catch { }

    # Vault connectivity
    if (-not [string]::IsNullOrWhiteSpace($cfg.vaultAddress)) {
        try {
            $result    = Test-PortConnectivity -Target $cfg.vaultAddress -Port $cfg.vaultPort `
                -Description 'CyberArk Vault' -TimeoutSeconds $cfg.timeoutSeconds `
                -RetryCount $retryCount -RetryDelaySeconds $retryDelay
            $results  += $result
        }
        catch {
            $results += [PSCustomObject]@{
                Target      = $cfg.vaultAddress
                Port        = $cfg.vaultPort
                Reachable   = $false
                LatencyMs   = $null
                Status      = 'Error'
                Description = 'CyberArk Vault'
                Error       = $_.Exception.Message
                IsMockData  = $false
            }
        }
    }

    # PSM servers
    $psmTargets = @()
    if ($cfg.psmServers) { $psmTargets = $cfg.psmServers }

    foreach ($psm in $psmTargets) {
        try {
            $results += Test-PortConnectivity -Target $psm -Port 3389 `
                -Description 'PSM RDP' -TimeoutSeconds $cfg.timeoutSeconds `
                -RetryCount $retryCount -RetryDelaySeconds $retryDelay
        }
        catch {
            $results += [PSCustomObject]@{
                Target      = $psm
                Port        = 3389
                Reachable   = $false
                LatencyMs   = $null
                Status      = 'Error'
                Description = 'PSM RDP'
                Error       = $_.Exception.Message
                IsMockData  = $false
            }
        }
    }

    # Extra ports from CLI
    if ($ConnectivityPorts) {
        foreach ($port in $ConnectivityPorts) {
            $allTargets = @()
            if (-not [string]::IsNullOrWhiteSpace($cfg.vaultAddress)) { $allTargets += $cfg.vaultAddress }
            foreach ($t in $allTargets) {
                try {
                    $results += Test-PortConnectivity -Target $t -Port $port `
                        -Description "Port $port" -TimeoutSeconds $cfg.timeoutSeconds `
                        -RetryCount $retryCount -RetryDelaySeconds $retryDelay
                }
                catch { }
            }
        }
    }

    # Farm peers: TCP ports and/or ICMP ping per peer, with the down-grace state
    # machine so each server independently reports a peer down only after the
    # grace window (default 150s + 2 consecutive failed check-ins) has passed.
    $rawPeers = @()
    try { if ($null -ne $cfg.farmPeers) { $rawPeers = @($cfg.farmPeers) } } catch { }

    # Support ';' as a peer separator inside one string -- powershell.exe -File
    # (scheduled tasks) cannot pass real arrays: -FarmPeers "psm01:3389;vault01:1858"
    $expandedPeers = @()
    foreach ($rp in $rawPeers) {
        if ($rp -is [string] -and $rp.Contains(';')) {
            $expandedPeers += @($rp -split ';' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
        }
        else {
            $expandedPeers += $rp
        }
    }
    $rawPeers = $expandedPeers

    foreach ($rawPeer in $rawPeers) {
        $spec = $null
        try { $spec = ConvertTo-FarmPeerSpec -Entry $rawPeer } catch { }
        if ($null -eq $spec) {
            Write-Log -Message "Skipping unparseable farm peer entry: $rawPeer" -Level Warn -Color Yellow -Component 'FarmPeer'
            continue
        }

        $checks = @()
        foreach ($port in $spec.Ports) {
            $checks += @{ Kind = 'tcp'; Port = $port }
        }
        if ($spec.Ping) {
            $checks += @{ Kind = 'icmp'; Port = $null }
        }

        foreach ($check in $checks) {
            $peerResult = $null
            try {
                if ($check.Kind -eq 'tcp') {
                    $peerResult = Test-PortConnectivity -Target $spec.Host -Port $check.Port `
                        -Description 'Farm Peer' -TimeoutSeconds $cfg.timeoutSeconds `
                        -RetryCount $retryCount -RetryDelaySeconds $retryDelay
                    $peerKey = "$($spec.Host):$($check.Port)"
                }
                else {
                    $peerResult = Test-PingConnectivity -Target $spec.Host `
                        -Description 'Farm Peer (ICMP)' -TimeoutSeconds $cfg.timeoutSeconds `
                        -RetryCount $retryCount -RetryDelaySeconds $retryDelay
                    $peerKey = "$($spec.Host):icmp"
                }

                $errText   = if ($peerResult.Error) { "$($peerResult.Error)" } else { '' }
                $peerState = Update-PeerStatus -PeerKey $peerKey -Reachable ([bool]$peerResult.Reachable) `
                    -ErrorMessage $errText -GraceSeconds $graceSec

                $null = $peerResult.PSObject.Properties.Add([System.Management.Automation.PSNoteProperty]::new('IsFarmPeer', $true))
                $null = $peerResult.PSObject.Properties.Add([System.Management.Automation.PSNoteProperty]::new('PeerState', $peerState))
                # Surface the grace state in Status so reports/dashboards show
                # Suspect (within grace, no alert) vs Down (confirmed).
                if (-not $peerResult.Reachable) {
                    $peerResult.Status = if ($peerState -eq 'Down') { 'Down' } else { 'Suspect' }
                }
                $results += $peerResult
            }
            catch {
                Write-Log -Message "Farm peer check failed for $($spec.Host): $($_.Exception.Message)" -Level Warn -Color Yellow -Component 'FarmPeer'
            }
        }
    }

    Write-Log -Message "Connectivity tests complete: $($results.Count) targets tested" -Level Info -Component 'Connectivity'

    return $results
}

#endregion

#region WebDriver Health

function Get-PSMComponentsPath {
    <#
    .SYNOPSIS
        Discovers PSM Components directory from registry, config cache, or default path.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param()

    $cfg = $script:Config.webDriver

    # 1. Cached path from config
    if (-not [string]::IsNullOrWhiteSpace($cfg.psmComponentsPath) -and (Test-Path $cfg.psmComponentsPath)) {
        return [PSCustomObject]@{ Path = $cfg.psmComponentsPath; Source = 'Config'; Exists = $true }
    }

    # 2. Registry
    try {
        $installPath    = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\CyberArk\PSM' -Name 'InstallLocation' -ErrorAction Stop).InstallLocation
        $componentsPath = Join-Path $installPath 'Components'
        if (Test-Path $componentsPath) {
            return [PSCustomObject]@{ Path = $componentsPath; Source = 'Registry'; Exists = $true }
        }
    }
    catch { }

    # 3. Default
    $defaultPath = 'C:\Program Files (x86)\CyberArk\PSM\Components'
    $exists      = Test-Path $defaultPath
    return [PSCustomObject]@{ Path = $defaultPath; Source = 'Default'; Exists = $exists }
}

function Get-BrowserInfo {
    <#
    .SYNOPSIS
        Detects browser installation and version from registry or known locations.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [ValidateSet('Chrome','Edge')]
        [string]$Browser = 'Chrome'
    )

    $cfg         = $script:Config.webDriver
    $exeName     = if ($Browser -eq 'Chrome') { 'chrome.exe' } else { 'msedge.exe' }
    $regPath     = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\$exeName"
    $knownLocs   = if ($Browser -eq 'Chrome') { $cfg.knownChromePaths } else { $cfg.knownEdgePaths }

    # Registry
    try {
        $browserPath = (Get-ItemProperty -Path $regPath -Name '(default)' -ErrorAction Stop).'(default)'
        if (Test-Path $browserPath) {
            $version = (Get-Item $browserPath).VersionInfo.ProductVersion
            return [PSCustomObject]@{ Browser = $Browser; Path = $browserPath; Version = $version; Exists = $true }
        }
    }
    catch { }

    # Known locations
    if ($knownLocs) {
        foreach ($loc in $knownLocs) {
            if (Test-Path $loc) {
                try {
                    $version = (Get-Item $loc).VersionInfo.ProductVersion
                    return [PSCustomObject]@{ Browser = $Browser; Path = $loc; Version = $version; Exists = $true }
                }
                catch { }
            }
        }
    }

    return [PSCustomObject]@{ Browser = $Browser; Path = ''; Version = ''; Exists = $false }
}

function Get-WebDriverInfo {
    <#
    .SYNOPSIS
        Gets WebDriver version and SHA256 hash from PSM Components folder.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [ValidateSet('Chrome','Edge')]
        [string]$Browser = 'Chrome'
    )

    $components  = Get-PSMComponentsPath
    if (-not $components.Exists) {
        return [PSCustomObject]@{ Driver = $Browser; Path = ''; Version = ''; Hash = ''; Exists = $false }
    }

    $driverName  = if ($Browser -eq 'Chrome') { 'chromedriver.exe' } else { 'msedgedriver.exe' }
    $driverPath  = Join-Path $components.Path $driverName

    if (-not (Test-Path $driverPath)) {
        return [PSCustomObject]@{ Driver = $Browser; Path = $driverPath; Version = ''; Hash = ''; Exists = $false }
    }

    $version = 'Unknown'
    $hash    = ''
    try { $version = (Get-Item $driverPath).VersionInfo.ProductVersion } catch { }
    try { $hash    = (Get-FileHash -Path $driverPath -Algorithm SHA256).Hash } catch { }

    return [PSCustomObject]@{ Driver = $Browser; Path = $driverPath; Version = $version; Hash = $hash; Exists = $true }
}

function Test-BrowserDriverCompatibility {
    <#
    .SYNOPSIS
        Compares browser and driver major versions (or full version if StrictVersionMatch=true).
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [ValidateSet('Chrome','Edge')]
        [string]$Browser = 'Chrome'
    )

    $cfg         = $script:Config.webDriver
    $browserInfo = Get-BrowserInfo -Browser $Browser

    if (-not $browserInfo.Exists) {
        # Must carry the same property set as the full result -- callers read
        # DriverExists/DriverPath and StrictMode throws on missing properties.
        return [PSCustomObject]@{ Browser = $Browser; Compatible = $false; BrowserVersion = ''; DriverVersion = ''; DriverPath = ''; DriverExists = $false; Message = "$Browser not found on system" }
    }

    $driverInfo = Get-WebDriverInfo -Browser $Browser
    if (-not $driverInfo.Exists) {
        return [PSCustomObject]@{ Browser = $Browser; Compatible = $false; BrowserVersion = $browserInfo.Version; DriverVersion = ''; DriverPath = $driverInfo.Path; DriverExists = $false; Message = 'WebDriver not found in Components folder' }
    }

    $bParts     = $browserInfo.Version -split '\.'
    $dParts     = $driverInfo.Version  -split '\.'
    $compatible = $false
    $message    = ''

    if ($cfg.strictVersionMatch) {
        $compatible = ($bParts -join '.') -eq ($dParts -join '.')
        $message    = if ($compatible) { "Versions match (strict): $($bParts -join '.')" } else { "Browser ($($bParts -join '.')) != Driver ($($dParts -join '.'))" }
    }
    else {
        $bMajor     = $bParts[0]
        $dMajor     = $dParts[0]
        $compatible = $bMajor -eq $dMajor
        $message    = if ($compatible) { "Major versions match: $bMajor" } else { "Browser major ($bMajor) != Driver major ($dMajor)" }
    }

    return [PSCustomObject]@{
        Browser        = $Browser
        Compatible     = $compatible
        BrowserVersion = $browserInfo.Version
        DriverVersion  = $driverInfo.Version
        DriverPath     = $driverInfo.Path
        DriverExists   = $driverInfo.Exists
        Message        = $message
    }
}

function Compare-WebDriverHash {
    <#
    .SYNOPSIS
        Compares SHA256 of driver in Components (x86) vs Components\64 (x64). Returns NeedsSync flag.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [ValidateSet('Chrome','Edge')]
        [string]$Browser = 'Chrome'
    )

    $components  = Get-PSMComponentsPath
    if (-not $components.Exists) {
        return [PSCustomObject]@{ Browser = $Browser; Match = $false; x86Hash = ''; x64Hash = ''; NeedsSync = $false; Message = 'Components folder not found' }
    }

    $driverName = if ($Browser -eq 'Chrome') { 'chromedriver.exe' } else { 'msedgedriver.exe' }
    $x86Path    = Join-Path $components.Path $driverName
    $x64Path    = Join-Path (Join-Path $components.Path '64') $driverName

    if (-not (Test-Path $x86Path)) {
        return [PSCustomObject]@{ Browser = $Browser; Match = $false; x86Hash = ''; x64Hash = ''; NeedsSync = $false; Message = 'x86 driver not found' }
    }
    if (-not (Test-Path $x64Path)) {
        $x86Hash = (Get-FileHash -Path $x86Path -Algorithm SHA256).Hash
        return [PSCustomObject]@{ Browser = $Browser; Match = $false; x86Hash = $x86Hash; x64Hash = ''; NeedsSync = $true; Message = 'x64 driver not found (needs initial sync)' }
    }

    $x86Hash = (Get-FileHash -Path $x86Path -Algorithm SHA256).Hash
    $x64Hash = (Get-FileHash -Path $x64Path -Algorithm SHA256).Hash
    $match   = $x86Hash -eq $x64Hash

    return [PSCustomObject]@{
        Browser   = $Browser
        Match     = $match
        x86Hash   = $x86Hash
        x64Hash   = $x64Hash
        NeedsSync = -not $match
        Message   = if ($match) { 'Hashes match - no sync needed' } else { 'Hashes differ - sync required' }
    }
}

function Collect-WebDriverHealth {
    <#
    .SYNOPSIS
        Orchestrates WebDriver health check for Chrome and Edge.
        Returns array of browser compatibility results with hash check.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject[]])]
    param()

    Write-Log -Message 'Starting WebDriver health collection' -Level Debug -Component 'WebDriver'

    if ($UseMockData -or -not (Test-IsWindowsPlatform)) {
        Write-Log -Message 'Using mock data for WebDriver health' -Level Debug -Component 'WebDriver'
        return Get-MockData -DataType 'WebDriverHealth'
    }

    # WebDriver/PSM-driver compatibility only matters where PSM's Components store
    # exists. On a host with no PSM there is nothing to be compatible with, so a
    # browser installed for other reasons must not raise a "missing driver" warning.
    $componentsInfo = Get-PSMComponentsPath
    if (-not $componentsInfo.Exists) {
        Write-Log -Message 'PSM Components folder not found -- skipping WebDriver health (no PSM on this host)' -Level Debug -Component 'WebDriver'
        return @()
    }

    $results = @()

    foreach ($browser in @('Chrome', 'Edge')) {
        try {
            $compat = Test-BrowserDriverCompatibility -Browser $browser

            $hashCheck = $null
            if ($compat.DriverExists) {
                try { $hashCheck = Compare-WebDriverHash -Browser $browser } catch { }
            }

            $results += [PSCustomObject]@{
                Browser        = $compat.Browser
                Compatible     = $compat.Compatible
                BrowserVersion = $compat.BrowserVersion
                DriverVersion  = $compat.DriverVersion
                DriverPath     = $compat.DriverPath
                DriverExists   = $compat.DriverExists
                HashMatch      = if ($hashCheck) { $hashCheck.Match } else { $null }
                NeedsSync      = if ($hashCheck) { $hashCheck.NeedsSync } else { $null }
                Message        = $compat.Message
                IsMockData     = $false
            }
        }
        catch {
            Write-Log -Message "WebDriver check failed for $browser`: $($_.Exception.Message)" -Level Warn -Color Yellow -Component 'WebDriver'
            $results += [PSCustomObject]@{
                Browser        = $browser
                Compatible     = $false
                BrowserVersion = ''
                DriverVersion  = ''
                DriverPath     = ''
                DriverExists   = $false
                HashMatch      = $null
                NeedsSync      = $null
                Message        = "Check failed: $($_.Exception.Message)"
                IsMockData     = $false
            }
        }
    }

    Write-Log -Message "WebDriver health collected: $($results.Count) browsers checked" -Level Info -Component 'WebDriver'

    return $results
}

#endregion

#region PVWA Health

function Collect-PVWAHealth {
    <#
    .SYNOPSIS
        Local PVWA/IIS health: W3SVC, PasswordVault app pool, w3wp memory,
        app-pool recycle events (5074/5075), HTTPS binding, IIS log size.
        No REST/auth -- reads services, IIS config, processes, event log only.
        Returns Status 'NotInstalled' on a host with no PVWA (safe on any box).
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param()

    $startTime = Get-Date
    Write-Log -Message 'Starting PVWA/IIS health collection' -Level Debug -Component 'PVWAHealth'

    if ($UseMockData -or -not (Test-IsWindowsPlatform)) {
        Write-Log -Message 'Using mock data for PVWA health' -Level Debug -Component 'PVWAHealth'
        return Get-MockData -DataType 'PVWAHealth'
    }

    $cfg = $script:Config.pvwaHealth

    $result = [PSCustomObject]@{
        Status             = 'Unknown'
        IISServiceStatus   = 'Unknown'
        AppPoolStatus      = 'Unknown'
        WorkerProcessCount = 0
        MemoryUsageMB      = 0
        RecentRecycleCount = 0
        BindingStatus      = 'Unknown'
        LogFileSizeMB      = 0
        FallbackMode       = $false
        CheckedAt          = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
        ServerName         = $env:COMPUTERNAME
        Component          = 'PVWA'
        CorrelationID      = $script:CorrelationID
        Duration           = ''
        IsMockData         = $false
        ErrorMessage       = $null
    }

    # Component-present gate: PVWA-SPECIFIC markers (registry / install folder) --
    # NOT merely "IIS is installed", so a generic IIS box is never flagged.
    if (-not (Test-CAComponentPresent -RegistryPaths @($cfg.registryPath) -FilePaths @($cfg.installPath))) {
        $result.Status   = 'NotInstalled'
        $result.Duration = ((Get-Date) - $startTime).ToString()
        Write-Log -Message 'PVWA not installed on this host -- skipping PVWA/IIS health' -Level Debug -Component 'PVWAHealth'
        return $result
    }

    try {
        $iisService = Get-Service -Name $cfg.iisServiceName -ErrorAction SilentlyContinue
        $result.IISServiceStatus = if ($iisService) { $iisService.Status.ToString() } else { 'NotFound' }

        $hasWebAdmin = Get-Module -Name WebAdministration -ListAvailable -ErrorAction SilentlyContinue
        if ($hasWebAdmin) {
            Import-Module WebAdministration -ErrorAction SilentlyContinue

            $appPool = Get-Item "IIS:\AppPools\$($cfg.appPoolName)" -ErrorAction SilentlyContinue
            if ($appPool) {
                $result.AppPoolStatus = $appPool.State.ToString()

                $workers = @(Get-Process -Name w3wp -ErrorAction SilentlyContinue)
                $result.WorkerProcessCount = $workers.Count
                if ($workers.Count -gt 0) {
                    $totalMem = ($workers | Measure-Object -Property WorkingSet64 -Sum).Sum
                    $result.MemoryUsageMB = [math]::Round($totalMem / 1MB, 2)
                }

                # App-pool recycle events in the last 24h, filtered to this pool.
                try {
                    $recycleEvents = @(Get-WinEvent -LogName System -FilterXPath "*[System[(EventID=5074 or EventID=5075) and TimeCreated[timediff(@SystemTime) <= 86400000]]]" -ErrorAction SilentlyContinue |
                        Where-Object { $_.Message -match [regex]::Escape($cfg.appPoolName) })
                    $result.RecentRecycleCount = $recycleEvents.Count
                }
                catch { }
            }
            else {
                $result.AppPoolStatus = 'NotFound'
            }

            $site = Get-Website -Name $cfg.siteName -ErrorAction SilentlyContinue
            if ($site) {
                $binding = $site.bindings.Collection | Where-Object { $_.protocol -eq 'https' } | Select-Object -First 1
                $result.BindingStatus = if ($binding) { 'OK' } else { 'NoHTTPS' }
                try {
                    $logPath = [System.Environment]::ExpandEnvironmentVariables("$($site.logFile.directory)\W3SVC$($site.id)")
                    if (Test-Path $logPath) {
                        $logFiles = @(Get-ChildItem -Path $logPath -Filter '*.log' -ErrorAction SilentlyContinue)
                        $result.LogFileSizeMB = [math]::Round((($logFiles | Measure-Object -Property Length -Sum).Sum) / 1MB, 2)
                    }
                }
                catch { }
            }
            else {
                $result.BindingStatus = 'SiteNotFound'
            }

            # Overall status (full mode)
            if ($result.IISServiceStatus -eq 'Running' -and $result.AppPoolStatus -eq 'Started') {
                $result.Status = 'OK'
            }
            elseif ($result.IISServiceStatus -eq 'Running' -and $result.AppPoolStatus -in @('Starting','Stopping')) {
                $result.Status = 'Warning'
            }
            else {
                $result.Status = 'Critical'
            }
            if ($result.Status -eq 'OK' -and $cfg.recycleWarnCount -gt 0 -and $result.RecentRecycleCount -gt $cfg.recycleWarnCount) {
                $result.Status = 'Warning'
            }
            if ($result.Status -eq 'OK' -and $cfg.memoryWarnMB -gt 0 -and $result.MemoryUsageMB -gt $cfg.memoryWarnMB) {
                $result.Status = 'Warning'
            }
        }
        else {
            # Fallback: no WebAdministration module -- service-state only.
            $result.FallbackMode = $true
            $result.Status = if ($result.IISServiceStatus -eq 'Running') { 'OK' } else { 'Critical' }
        }
    }
    catch {
        $result.Status       = 'Error'
        $result.ErrorMessage = $_.Exception.Message
        Write-Log -Message "PVWA/IIS health collection failed: $($_.Exception.Message)" -Level Error -Color Red -Component 'PVWAHealth'
    }

    $result.Duration = ((Get-Date) - $startTime).ToString()
    Write-Log -Message "PVWA/IIS health collected: $($result.Status) (IIS:$($result.IISServiceStatus) Pool:$($result.AppPoolStatus))" -Level Info -Component 'PVWAHealth'
    return $result
}

#endregion

#region CyberArk Log Scan

function Get-CALogLineSeverity {
    <#
    .SYNOPSIS
        Classify ONE CyberArk log line as ERROR / WARN / INFO. A CyberArk error code
        (ITATS/CACPM/BLSERVICE + digits + trailing E/W/I) is authoritative; otherwise a
        delimited severity token (bracketed, pipe field, or after the thread bracket).
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param([string]$Line)
    if ($Line -match '(?:ITATS|CACPM|BLSERVICE)\d+([EWI])') {
        switch ($Matches[1]) { 'E' { return 'ERROR' } 'W' { return 'WARN' } default { return 'INFO' } }
    }
    $tok = $null
    if     ($Line -match '\[(FATAL|CRITICAL|ERROR|WARNING|WARN)\]')     { $tok = $Matches[1] }
    elseif ($Line -match '\b(FATAL|CRITICAL|ERROR|WARNING|WARN)\s*\|')  { $tok = $Matches[1] }
    elseif ($Line -match '\]\s+(FATAL|CRITICAL|ERROR|WARNING|WARN)\b')  { $tok = $Matches[1] }
    if ($tok) {
        $u = $tok.ToUpperInvariant()
        return $(if ($u -in @('FATAL','CRITICAL','ERROR')) { 'ERROR' } else { 'WARN' })
    }
    return 'INFO'
}

function Get-CALogSeverityCounts {
    <#
    .SYNOPSIS
        Count ERROR/WARN across CyberArk log lines (back-compat wrapper over
        Get-CALogLineSeverity).
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param([string[]]$Lines)
    $err = 0; $warn = 0
    foreach ($line in $Lines) {
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        switch (Get-CALogLineSeverity -Line $line) { 'ERROR' { $err++ } 'WARN' { $warn++ } }
    }
    return [PSCustomObject]@{ Errors = $err; Warnings = $warn }
}

function Get-CALogEntries {
    <#
    .SYNOPSIS
        Parse CyberArk log lines into ERROR/WARN findings WITH a per-line timestamp so
        LogScan can bucket by recency. Timestamp is extracted with a per-format leading
        regex (overridable per source); a line whose timestamp won't parse keeps
        Timestamp=$null (counted as 'undated' by Get-RecencyProfile, never in a window).
    #>
    [CmdletBinding()]
    [OutputType([System.Object[]])]
    param(
        [string[]]$Lines,
        [string]$Format,
        [string]$TimestampRegex,
        [string]$TimestampFormat
    )
    # Built-in leading-timestamp patterns per known CyberArk log format.
    $defaults = @{
        'log4net'   = @{ rx = '^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})'; fmt = 'yyyy-MM-dd HH:mm:ss' }
        'BLService' = @{ rx = '^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})'; fmt = 'yyyy-MM-dd HH:mm:ss' }
        'CACPM'     = @{ rx = '^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})'; fmt = 'yyyy-MM-dd HH:mm:ss' }
        'ITALog'    = @{ rx = '^(\d{2}/\d{2}/\d{4} \d{2}:\d{2}:\d{2})'; fmt = 'MM/dd/yyyy HH:mm:ss' }
    }
    $d   = $defaults[$Format]
    $rx  = if ($TimestampRegex)  { $TimestampRegex }  elseif ($d) { $d.rx }  else { $null }
    $fmt = if ($TimestampFormat) { $TimestampFormat } elseif ($d) { $d.fmt } else { $null }
    $entries = @()
    foreach ($line in $Lines) {
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        $sev = Get-CALogLineSeverity -Line $line
        if ($sev -ne 'ERROR' -and $sev -ne 'WARN') { continue }
        $ts = $null
        if ($rx -and $line -match $rx) {
            try { $ts = [datetime]::ParseExact($Matches[1], $fmt, [System.Globalization.CultureInfo]::InvariantCulture) } catch { $ts = $null }
        }
        $entries += [pscustomobject]@{ Timestamp = $ts; Severity = $sev }
    }
    return $entries
}

function Collect-CALogScan {
    <#
    .SYNOPSIS
        Generic CyberArk log-code scanner: for each configured source whose log
        file exists, tails it and counts ERROR/WARN severities (Vault ITALog,
        CPM CACPM, Connector Manager BLSERVICE, PVWA log4net). Local files only.
        Returns Status 'NotInstalled' when NO configured source file exists.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param()

    $startTime = Get-Date
    Write-Log -Message 'Starting CyberArk log scan' -Level Debug -Component 'LogScan'

    if ($UseMockData -or -not (Test-IsWindowsPlatform)) {
        Write-Log -Message 'Using mock data for log scan' -Level Debug -Component 'LogScan'
        return Get-MockData -DataType 'CALogScan'
    }

    $cfg = $script:Config.logScan

    $result = [PSCustomObject]@{
        Status        = 'Unknown'
        Sources       = @()
        TotalErrors   = 0
        TotalWarnings = 0
        MaxSourceErrors = 0
        CheckedAt     = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
        ServerName    = $env:COMPUTERNAME
        CorrelationID = $script:CorrelationID
        Duration      = ''
        IsMockData    = $false
        ErrorMessage  = $null
    }

    $tail = if ($cfg.tailLines -gt 0) { $cfg.tailLines } else { 1000 }
    $rc   = Resolve-RecencyConfig
    $anyFound = $false
    $sourcesOut = @()

    foreach ($src in @($cfg.sources)) {
        $name   = if ($src -is [hashtable]) { $src['name'] }   else { $src.name }
        $format = if ($src -is [hashtable]) { $src['format'] } else { $src.format }
        $paths  = @(if ($src -is [hashtable]) { $src['paths'] } else { $src.paths })
        # Optional per-source overrides; Get-PSPropertySafe so a JSON source object
        # that omits these keys doesn't throw under StrictMode.
        $tsRx   = if ($src -is [hashtable]) { $src['timestampRegex'] }  else { Get-PSPropertySafe -Object $src -Name 'timestampRegex' }
        $tsFmt  = if ($src -is [hashtable]) { $src['timestampFormat'] } else { Get-PSPropertySafe -Object $src -Name 'timestampFormat' }

        $found = $null
        foreach ($p in $paths) { if (-not [string]::IsNullOrWhiteSpace($p) -and (Test-Path $p)) { $found = $p; break } }

        # ErrorCount/WarnCount are the RECENT-window counts (alert drivers); Recency holds
        # the 24h/7d/30d buckets. Undated (unparseable-timestamp) errors don't drive
        # recency alerts UNLESS a source is 100% undated -> tail-count fallback.
        $srcResult = [PSCustomObject]@{ Name = $name; Format = $format; Path = $found; Found = [bool]$found
                                        ErrorCount = 0; WarnCount = 0; ErrorRecency = $null; WarnRecency = $null; Fallback = $false }

        if ($found) {
            $anyFound = $true
            try {
                $lines   = Get-Content -Path $found -Tail $tail -ErrorAction Stop
                $entries = @(Get-CALogEntries -Lines $lines -Format $format -TimestampRegex $tsRx -TimestampFormat $tsFmt)
                $errTs   = @($entries | Where-Object Severity -eq 'ERROR' | ForEach-Object { $_.Timestamp })
                $warnTs  = @($entries | Where-Object Severity -eq 'WARN'  | ForEach-Object { $_.Timestamp })
                $errRec  = Get-RecencyProfile -Timestamps $errTs  -DayHours $rc.Day -WeekHours $rc.Week -MonthHours $rc.Month
                $warnRec = Get-RecencyProfile -Timestamps $warnTs -DayHours $rc.Day -WeekHours $rc.Week -MonthHours $rc.Month
                $srcResult.ErrorRecency = $errRec
                $srcResult.WarnRecency  = $warnRec

                $datedErr = [int]$errRec.total - [int]$errRec.undated
                if ([int]$errRec.undated -gt 0 -and $datedErr -eq 0) {
                    # Whole source is timestamp-less for this format: keep alerting on the
                    # raw tail count rather than going silent.
                    $srcResult.Fallback   = $true
                    $srcResult.ErrorCount = [int]$errRec.undated
                    $srcResult.WarnCount  = [int]$warnRec.undated
                    Write-Log -Message "LogScan: '$name' ($format) has no parseable timestamps -- using tail-count fallback ($($srcResult.ErrorCount) err)" -Level Debug -Component 'LogScan'
                } else {
                    $srcResult.ErrorCount = [int]$errRec[$rc.AlertKey]
                    $srcResult.WarnCount  = [int]$warnRec[$rc.AlertKey]
                }
                $result.TotalErrors   += $srcResult.ErrorCount
                $result.TotalWarnings += $srcResult.WarnCount
                if ($srcResult.ErrorCount -gt $result.MaxSourceErrors) { $result.MaxSourceErrors = $srcResult.ErrorCount }
            }
            catch {
                Write-Log -Message "Log scan read failed for '$name' ($found): $($_.Exception.Message)" -Level Warn -Color Yellow -Component 'LogScan'
            }
        }
        $sourcesOut += $srcResult
    }

    $result.Sources = $sourcesOut

    if (-not $anyFound) {
        $result.Status   = 'NotInstalled'
        $result.Duration = ((Get-Date) - $startTime).ToString()
        Write-Log -Message 'No CyberArk log sources present on this host -- skipping log scan' -Level Debug -Component 'LogScan'
        return $result
    }

    $warnAt = if ($cfg.warnCount -gt 0) { $cfg.warnCount } else { 1 }
    $critAt = if ($cfg.criticalCount -gt 0) { $cfg.criticalCount } else { 25 }
    if ($result.MaxSourceErrors -ge $critAt)   { $result.Status = 'Critical' }
    elseif ($result.TotalErrors -ge $warnAt)   { $result.Status = 'Warning' }
    else                                        { $result.Status = 'OK' }

    $result.Duration = ((Get-Date) - $startTime).ToString()
    Write-Log -Message "CyberArk log scan complete: $($result.Status) (recent Errors:$($result.TotalErrors) Warnings:$($result.TotalWarnings) across $(@($sourcesOut | Where-Object Found).Count) log(s))" -Level Info -Component 'LogScan'
    return $result
}

#endregion

#region Collection Orchestrator

function Get-CollectionFindings {
    <#
    .SYNOPSIS
        Normalize the recency signals from every collector (service restarts/crashes/
        start-failures, CPM/PSM/LogScan errors) into one flat Findings list -- the
        unified surface the report and JSONL render consistently. Severity is computed
        on the RECENT window; a finding is emitted for anything with 30d activity so the
        history is visible even when it isn't currently alarming.
    #>
    [CmdletBinding()]
    param([Parameter(Mandatory)]$Results)
    $rc = Resolve-RecencyConfig
    $th = $script:Config.thresholds
    $win = $rc.AlertLabel
    $out = @()
    # Safe getter across hashtable / [ordered] / PSCustomObject.
    $get = {
        param($o, $n)
        if ($null -eq $o) { $null }
        elseif ($o -is [System.Collections.IDictionary]) { $o[$n] }
        else { Get-PSPropertySafe -Object $o -Name $n }
    }
    $bkt = { param($p) "$([int](& $get $p 'count24h'))/24h $([int](& $get $p 'count7d'))/7d $([int](& $get $p 'count30d'))/30d" }

    # --- Services ---
    $svcResult = $Results.ServiceStatus
    if ($null -ne $svcResult) {
        foreach ($svc in @(& $get $svcResult 'Services')) {
            $name = & $get $svc 'ServiceName'
            $restarts   = & $get $svc 'Restarts'
            $crashes    = & $get $svc 'Crashes'
            $startFails = & $get $svc 'StartFailures'
            if ($restarts -and [int](& $get $restarts 'total') -gt 0) {
                $sev = Get-RecencyVerdict -Profile $restarts -Warn $th.serviceRestartWarning -Critical $th.serviceRestartCritical -Window $win
                $out += New-Finding -Source "Service:$name" -Kind ServiceRestart -Severity $sev -Recency $restarts -Detail "restarts $(& $bkt $restarts)"
            }
            if ($crashes -and [int](& $get $crashes 'total') -gt 0) {
                $sev = if ([int](& $get $crashes 'count7d') -ge 1) { 'Critical' } else { 'OK' }
                $out += New-Finding -Source "Service:$name" -Kind ServiceCrash -Severity $sev -Recency $crashes -Detail "unexpected terminations $(& $bkt $crashes)"
            }
            if ($startFails -and [int](& $get $startFails 'total') -gt 0) {
                $sev = if ([int](& $get $startFails 'count7d') -ge 1) { 'Critical' } else { 'OK' }
                $out += New-Finding -Source "Service:$name" -Kind ServiceStartFailure -Severity $sev -Recency $startFails -Detail "start failures $(& $bkt $startFails)"
            }
        }
    }
    # --- CPM / PSM ---
    $cpm = $Results.CPMHealth
    $cpmR = & $get $cpm 'Recency'
    if ($cpmR -and [int](& $get $cpmR 'total') -gt 0) {
        $sev = Get-RecencyVerdict -Profile $cpmR -Warn $th.cpmErrorWarning -Critical $th.cpmErrorCritical -Window $win
        $out += New-Finding -Source 'CPM:pm_error.log' -Kind LogError -Severity $sev -Recency $cpmR -Detail "errors $(& $bkt $cpmR)"
    }
    $psm = $Results.PSMHealth
    $psmR = & $get $psm 'Recency'
    if ($psmR -and [int](& $get $psmR 'total') -gt 0) {
        $sev = Get-RecencyVerdict -Profile $psmR -Warn $th.psmSystemErrorWarning -Critical $th.psmSystemErrorCritical -Window $win
        $out += New-Finding -Source 'PSM:system errors' -Kind LogError -Severity $sev -Recency $psmR -Detail "system errors $(& $bkt $psmR)"
    }
    # --- LogScan sources ---
    $ls = $Results.LogScan
    if ($null -ne $ls) {
        $lcfg   = $script:Config.logScan
        $warnAt = if ($lcfg.warnCount -gt 0) { $lcfg.warnCount } else { 1 }
        $critAt = if ($lcfg.criticalCount -gt 0) { $lcfg.criticalCount } else { 25 }
        foreach ($s in @(& $get $ls 'Sources')) {
            $er = & $get $s 'ErrorRecency'
            if ($er -and [int](& $get $er 'total') -gt 0) {
                $sev = Get-RecencyVerdict -Profile $er -Warn $warnAt -Critical $critAt -Window $win
                $out += New-Finding -Source "Log:$(& $get $s 'Name')($(& $get $s 'Format'))" -Kind LogError -Severity $sev -Recency $er -Detail "errors $(& $bkt $er)"
            }
        }
    }
    return $out
}

function Invoke-MetricsCollection {
    <#
    .SYNOPSIS
        Calls all enabled collectors with isolated try/catch.
        Runs threshold evaluation after each collector and accumulates alerts.
        Returns a hashtable of all results.
    #>
    [CmdletBinding()]
    [OutputType([hashtable])]
    param()

    $cfg      = $script:Config
    $tholds   = $cfg.thresholds

    $results = @{
        CollectionMeta = [ordered]@{
            recordType    = 'CollectionMeta'
            timestamp     = (Get-Date).ToUniversalTime().ToString('o')
            serverName    = $env:COMPUTERNAME
            mode          = $script:OperatingMode
            tier          = $script:CurrentTier
            components    = @()
            toolVersion   = $script:ToolVersion
            correlationId = $script:CorrelationID
        }
        SystemHealth      = $null
        ServiceStatus     = $null
        CertificateHealth = $null
        ServerCapacity    = $null
        CPMHealth         = $null
        PSMHealth         = $null
        Connectivity      = $null
        WebDriverHealth   = $null
        PVWAHealth        = $null
        LogScan           = $null
        Alerts            = [System.Collections.ArrayList]::new()
        Errors            = [System.Collections.ArrayList]::new()
        Findings          = [System.Collections.ArrayList]::new()
    }

    # Determine which collectors to run based on tier
    if ($script:CurrentTier -ne 'All') {
        $tierCollectors = Get-TierCollectors -TierName $script:CurrentTier
    } else {
        $tierCollectors = @('SystemHealth','ServiceStatus','CertificateHealth','ServerCapacity','CPMHealth','PSMHealth','Connectivity','WebDriverHealth','PVWAHealth','LogScan')
    }

    # Helper: add alert if non-null
    $addAlert = {
        param($alert)
        if ($null -ne $alert) { $null = $results.Alerts.Add($alert) }
    }

    # --- System Health ---
    if ($tierCollectors -contains 'SystemHealth' -and -not $SkipSystemHealth) {
        Write-Log -Message 'Collecting: System Health' -Level Info -Color Cyan
        try {
            $sh                  = Collect-SystemHealth
            $results.SystemHealth = $sh
            $null = $results.CollectionMeta.components += 'SystemHealth'

            if ($sh.CPU) {
                & $addAlert (Test-Threshold -Value $sh.CPU.Average -Warning $tholds.cpuWarningPercent -Critical $tholds.cpuCriticalPercent `
                    -HigherIsBad $true -Source 'SystemHealth' -MetricName 'CPU Average' -Unit '%')
            }
            if ($sh.Memory) {
                & $addAlert (Test-Threshold -Value $sh.Memory.UsedPercent -Warning $tholds.memoryWarningPercent -Critical $tholds.memoryCriticalPercent `
                    -HigherIsBad $true -Source 'SystemHealth' -MetricName 'Memory Used' -Unit '%')
            }
            if ($sh.Disks) {
                foreach ($disk in $sh.Disks) {
                    & $addAlert (Test-Threshold -Value $disk.UsedPercent -Warning $tholds.diskWarningPercent -Critical $tholds.diskCriticalPercent `
                        -HigherIsBad $true -Source 'SystemHealth' -MetricName "Disk $($disk.DriveLetter)" -Unit '%')
                }
            }
            # Orphaned-session indicator: too many DISCONNECTED RDP sessions
            # (opt-in via thresholds.rdpDisconnectedWarning; 0 = disabled).
            $rdpSess = Get-PSPropertySafe -Object $sh -Name 'RdpSessions'
            $rdpWarnAt = 0
            try { if ($null -ne $tholds.rdpDisconnectedWarning) { $rdpWarnAt = [int]$tholds.rdpDisconnectedWarning } } catch { }
            if ($rdpWarnAt -gt 0 -and $null -ne $rdpSess -and [int]$rdpSess.Disconnected -ge $rdpWarnAt) {
                $null = $results.Alerts.Add((New-Alert -Severity 'Warning' -Source 'SystemHealth' -MetricName 'Disconnected RDP Sessions' `
                    -Message "$($rdpSess.Disconnected) disconnected RDP session(s) (threshold $rdpWarnAt) -- possible orphaned logons ($($rdpSess.ShadowDisconnected) shadow-user)" `
                    -Value $rdpSess.Disconnected -Threshold $rdpWarnAt))
            }

            $shWorstDisk = @($sh.Disks | Sort-Object UsedPercent -Descending | Select-Object -First 1)
            $shDiskStr   = if ($shWorstDisk.Count -gt 0) { "Disk:$($shWorstDisk[0].DriveLetter)$([math]::Round([double]$shWorstDisk[0].UsedPercent,0))%" } else { 'Disk:n/a' }
            $shSessStr   = if ($null -ne $rdpSess) { " Sessions:$($rdpSess.Active)A/$($rdpSess.Disconnected)D" } else { '' }
            Write-Finding -Status $(if ($sh.Status -eq 'OK') { 'OK' } elseif ($sh.Status -eq 'Warning') { 'WARN' } else { 'FAIL' }) `
                -Message "System Health: $($sh.Status) (CPU:$($sh.CPU.Average)% Mem:$($sh.Memory.UsedPercent)% $shDiskStr$shSessStr)" -Component 'SystemHealth'
        }
        catch {
            $null = $results.Errors.Add([PSCustomObject]@{ collector = 'SystemHealth'; error = $_.Exception.Message })
            Write-Log -Message "SystemHealth collector failed: $($_.Exception.Message)" -Level Error -Color Red
        }
    }

    # --- Service Resiliency ---
    if ($tierCollectors -contains 'ServiceStatus' -and -not $SkipServices) {
        Write-Log -Message 'Collecting: Service Resiliency' -Level Info -Color Cyan
        try {
            $sr                   = Collect-ServiceResiliency
            $results.ServiceStatus = $sr
            $null = $results.CollectionMeta.components += 'ServiceStatus'

            if ($sr.StoppedServices -gt 0) {
                $null = $results.Alerts.Add((New-Alert -Severity 'Critical' -Source 'ServiceStatus' -MetricName 'Stopped Services' `
                    -Message "$($sr.StoppedServices) CyberArk service(s) are stopped" -Value $sr.StoppedServices -Threshold 0))
            }
            elseif ($sr.DegradedServices -gt 0) {
                $null = $results.Alerts.Add((New-Alert -Severity 'Warning' -Source 'ServiceStatus' -MetricName 'Degraded Services' `
                    -Message "$($sr.DegradedServices) CyberArk service(s) are degraded" -Value $sr.DegradedServices -Threshold 0))
            }

            if ($sr.TotalServices -eq 0) {
                Write-Finding -Status 'INFO' -Message 'Services: no monitored services present on this host (none of collection.cyberArkServices exist)' -Component 'ServiceStatus'
            }
            else {
                Write-Finding -Status $(if ($sr.Status -eq 'OK') { 'OK' } elseif ($sr.Status -eq 'Warning') { 'WARN' } else { 'FAIL' }) `
                    -Message "Services: $($sr.Status) (Healthy:$($sr.HealthyServices) Degraded:$($sr.DegradedServices) Stopped:$($sr.StoppedServices))" -Component 'ServiceStatus'
            }
        }
        catch {
            $null = $results.Errors.Add([PSCustomObject]@{ collector = 'ServiceStatus'; error = $_.Exception.Message })
            Write-Log -Message "ServiceResiliency collector failed: $($_.Exception.Message)" -Level Error -Color Red
        }
    }

    # --- Certificate Health ---
    if ($tierCollectors -contains 'CertificateHealth' -and -not $SkipCertificates) {
        Write-Log -Message 'Collecting: Certificate Health' -Level Info -Color Cyan
        try {
            $ch                       = Collect-CertificateHealth
            $results.CertificateHealth = $ch
            $null = $results.CollectionMeta.components += 'CertificateHealth'

            if ($ch.ExpiredCount -gt 0 -or $ch.CriticalCount -gt 0) {
                $null = $results.Alerts.Add((New-Alert -Severity 'Critical' -Source 'CertHealth' -MetricName 'Certificate Expiry' `
                    -Message "$($ch.CriticalCount) cert(s) critical expiry, $($ch.ExpiredCount) expired" `
                    -Value ($ch.CriticalCount + $ch.ExpiredCount) -Threshold 0))
            }
            elseif ($ch.WarningCount -gt 0) {
                $null = $results.Alerts.Add((New-Alert -Severity 'Warning' -Source 'CertHealth' -MetricName 'Certificate Expiry' `
                    -Message "$($ch.WarningCount) cert(s) expiring within $($tholds.certWarningDays) days" `
                    -Value $ch.WarningCount -Threshold 0))
            }

            Write-Finding -Status $(if ($ch.Status -eq 'OK') { 'OK' } elseif ($ch.Status -eq 'Warning') { 'WARN' } else { 'FAIL' }) `
                -Message "Certificates: $($ch.Status) (Total:$($ch.TotalCertificates) Expired:$($ch.ExpiredCount) Crit:$($ch.CriticalCount) Warn:$($ch.WarningCount))" -Component 'CertHealth'
        }
        catch {
            $null = $results.Errors.Add([PSCustomObject]@{ collector = 'CertificateHealth'; error = $_.Exception.Message })
            Write-Log -Message "CertificateHealth collector failed: $($_.Exception.Message)" -Level Error -Color Red
        }
    }

    # --- Server Capacity ---
    if ($tierCollectors -contains 'ServerCapacity' -and -not $SkipCapacity) {
        Write-Log -Message 'Collecting: Server Capacity' -Level Info -Color Cyan
        try {
            $sc                   = Collect-ServerCapacity
            $results.ServerCapacity = $sc
            $null = $results.CollectionMeta.components += 'ServerCapacity'

            Write-Finding -Status $(if ($sc.Status -eq 'OK') { 'OK' } elseif ($sc.Status -eq 'Warning') { 'WARN' } else { 'FAIL' }) `
                -Message "Server Capacity: $($sc.Status)" -Component 'Capacity'
        }
        catch {
            $null = $results.Errors.Add([PSCustomObject]@{ collector = 'ServerCapacity'; error = $_.Exception.Message })
            Write-Log -Message "ServerCapacity collector failed: $($_.Exception.Message)" -Level Error -Color Red
        }
    }

    # --- CPM Health ---
    if ($tierCollectors -contains 'CPMHealth' -and -not $SkipCPM) {
        Write-Log -Message 'Collecting: CPM Health' -Level Info -Color Cyan
        try {
            $cpm                = Collect-CPMHealth
            $results.CPMHealth  = $cpm
            $null = $results.CollectionMeta.components += 'CPMHealth'

            if ($cpm.ErrorCount -ge $tholds.cpmErrorCritical) {
                $null = $results.Alerts.Add((New-Alert -Severity 'Critical' -Source 'CPMHealth' -MetricName 'CPM Errors' `
                    -Message "CPM has $($cpm.ErrorCount) errors in last $($cpm.LookbackMinutes) minutes" `
                    -Value $cpm.ErrorCount -Threshold $tholds.cpmErrorCritical))
            }
            elseif ($cpm.ErrorCount -ge $tholds.cpmErrorWarning) {
                $null = $results.Alerts.Add((New-Alert -Severity 'Warning' -Source 'CPMHealth' -MetricName 'CPM Errors' `
                    -Message "CPM has $($cpm.ErrorCount) errors in last $($cpm.LookbackMinutes) minutes" `
                    -Value $cpm.ErrorCount -Threshold $tholds.cpmErrorWarning))
            }

            if ($cpm.Status -ne 'NotInstalled' -and $cpm.PluginUnhealthy -gt 0) {
                $null = $results.Alerts.Add((New-Alert -Severity 'Warning' -Source 'CPMHealth' -MetricName 'CPM Plugins' `
                    -Message "$($cpm.PluginUnhealthy) CPM plugin(s) unhealthy (of $($cpm.PluginTotal))" -Value $cpm.PluginUnhealthy -Threshold 0))
            }

            if ($cpm.Status -eq 'NotInstalled') {
                Write-Finding -Status 'INFO' -Message 'CPM Health: not installed on this host (skipped)' -Component 'CPMHealth'
            }
            else {
                Write-Finding -Status $(if ($cpm.Status -eq 'Healthy') { 'OK' } elseif ($cpm.Status -eq 'Unhealthy') { 'WARN' } else { 'FAIL' }) `
                    -Message "CPM Health: $($cpm.Status) (Errors: $($cpm.ErrorCount))" -Component 'CPMHealth'
            }
        }
        catch {
            $null = $results.Errors.Add([PSCustomObject]@{ collector = 'CPMHealth'; error = $_.Exception.Message })
            Write-Log -Message "CPMHealth collector failed: $($_.Exception.Message)" -Level Error -Color Red
        }
    }

    # --- PSM Health ---
    if ($tierCollectors -contains 'PSMHealth' -and -not $SkipPSM) {
        Write-Log -Message 'Collecting: PSM Health' -Level Info -Color Cyan
        try {
            $psm               = Collect-PSMHealth
            $results.PSMHealth = $psm
            $null = $results.CollectionMeta.components += 'PSMHealth'

            if ($psm.SystemErrorCount -ge $tholds.psmSystemErrorCritical) {
                $null = $results.Alerts.Add((New-Alert -Severity 'Critical' -Source 'PSMHealth' -MetricName 'PSM System Errors' `
                    -Message "PSM has $($psm.SystemErrorCount) system errors" `
                    -Value $psm.SystemErrorCount -Threshold $tholds.psmSystemErrorCritical))
            }
            elseif ($psm.SystemErrorCount -ge $tholds.psmSystemErrorWarning) {
                $null = $results.Alerts.Add((New-Alert -Severity 'Warning' -Source 'PSMHealth' -MetricName 'PSM System Errors' `
                    -Message "PSM has $($psm.SystemErrorCount) system errors" `
                    -Value $psm.SystemErrorCount -Threshold $tholds.psmSystemErrorWarning))
            }

            # Only alert on a stopped service when PSM is actually installed --
            # a 'NotInstalled' host (ServiceStatus NotFound) must not go Critical.
            if ($psm.Status -ne 'NotInstalled' -and $psm.ServiceStatus -and $psm.ServiceStatus.Status -ne 'Running') {
                $null = $results.Alerts.Add((New-Alert -Severity 'Critical' -Source 'PSMHealth' -MetricName 'PSM Service' `
                    -Message "PSM service is $($psm.ServiceStatus.Status)" -Value 0 -Threshold 0))
            }

            if ($psm.Status -ne 'NotInstalled') {
                if ($psm.ConnComponentsInvalid -gt 0) {
                    $null = $results.Alerts.Add((New-Alert -Severity 'Warning' -Source 'PSMHealth' -MetricName 'PSM Connection Components' `
                        -Message "$($psm.ConnComponentsInvalid) PSM connection component(s) reference a missing executable (of $($psm.ConnComponentsTotal))" `
                        -Value $psm.ConnComponentsInvalid -Threshold 0))
                }
                if ($psm.RecordingStatus -eq 'Critical') {
                    $null = $results.Alerts.Add((New-Alert -Severity 'Critical' -Source 'PSMHealth' -MetricName 'PSM Recording Storage' `
                        -Message "PSM recording storage critically low: $($psm.RecordingFreeGB) GB free (pending:$($psm.RecordingPendingCount))" `
                        -Value $psm.RecordingFreeGB -Threshold $script:Config.psmHealth.recordingCriticalGB))
                }
                elseif ($psm.RecordingStatus -eq 'Warning') {
                    $null = $results.Alerts.Add((New-Alert -Severity 'Warning' -Source 'PSMHealth' -MetricName 'PSM Recording Storage' `
                        -Message "PSM recording storage low: $($psm.RecordingFreeGB) GB free (pending:$($psm.RecordingPendingCount))" `
                        -Value $psm.RecordingFreeGB -Threshold $script:Config.psmHealth.recordingWarnGB))
                }
            }

            if ($psm.Status -eq 'NotInstalled') {
                Write-Finding -Status 'INFO' -Message 'PSM Health: not installed on this host (skipped)' -Component 'PSMHealth'
            }
            else {
                Write-Finding -Status $(if ($psm.Status -eq 'Healthy') { 'OK' } elseif ($psm.Status -eq 'Unhealthy') { 'WARN' } else { 'FAIL' }) `
                    -Message "PSM Health: $($psm.Status) (SysErrors:$($psm.SystemErrorCount))" -Component 'PSMHealth'
            }
        }
        catch {
            $null = $results.Errors.Add([PSCustomObject]@{ collector = 'PSMHealth'; error = $_.Exception.Message })
            Write-Log -Message "PSMHealth collector failed: $($_.Exception.Message)" -Level Error -Color Red
        }
    }

    # --- Connectivity ---
    if ($tierCollectors -contains 'Connectivity' -and -not $SkipConnectivity) {
        Write-Log -Message 'Collecting: Connectivity' -Level Info -Color Cyan
        try {
            # @() -- with no targets configured the empty return unrolls to $null
            $conn                  = @(Collect-Connectivity)
            $results.Connectivity  = $conn
            $null = $results.CollectionMeta.components += 'Connectivity'

            $isPeer = { param($c) ($c.PSObject.Properties.Name -contains 'IsFarmPeer') -and $c.IsFarmPeer }

            # Non-peer targets (vault/PSM/extra ports): unreachable = Critical, as before.
            $coreUnreachable = @($conn | Where-Object { -not $_.Reachable -and -not (& $isPeer $_) })
            if ($coreUnreachable.Count -gt 0) {
                $null = $results.Alerts.Add((New-Alert -Severity 'Critical' -Source 'Connectivity' -MetricName 'Network Connectivity' `
                    -Message "$($coreUnreachable.Count) target(s) unreachable: $($coreUnreachable.Target -join ', ')" `
                    -Value $coreUnreachable.Count -Threshold 0))
            }

            # Farm peers: only alert once confirmed Down (past the grace window).
            # Suspect peers (inside the grace window) are findings, not alerts.
            $peersDown = @($conn | Where-Object { (& $isPeer $_) -and $_.PeerState -eq 'Down' })
            if ($peersDown.Count -gt 0) {
                $downList = @($peersDown | ForEach-Object { "$($_.Target)$(if ($null -ne $_.Port) { ":$($_.Port)" } else { ' (icmp)' })" })
                $null = $results.Alerts.Add((New-Alert -Severity 'Critical' -Source 'FarmPeer' -MetricName 'Farm Peer Down' `
                    -Message "$($peersDown.Count) farm peer target(s) confirmed DOWN (past grace window): $($downList -join ', ')" `
                    -Value $peersDown.Count -Threshold 0))
            }

            $peersSuspect = @($conn | Where-Object { (& $isPeer $_) -and $_.PeerState -eq 'Suspect' })

            $reachable   = @($conn | Where-Object { $_.Reachable })
            $connStatus  = if ($coreUnreachable.Count -gt 0 -or $peersDown.Count -gt 0) { 'FAIL' }
                           elseif ($peersSuspect.Count -gt 0) { 'WARN' }
                           else { 'OK' }
            $suspectNote = if ($peersSuspect.Count -gt 0) { " ($($peersSuspect.Count) peer(s) in grace window)" } else { '' }
            Write-Finding -Status $connStatus `
                -Message "Connectivity: $($reachable.Count)/$($conn.Count) targets reachable$suspectNote" -Component 'Connectivity'
        }
        catch {
            $null = $results.Errors.Add([PSCustomObject]@{ collector = 'Connectivity'; error = $_.Exception.Message })
            Write-Log -Message "Connectivity collector failed: $($_.Exception.Message)" -Level Error -Color Red
        }
    }

    # --- WebDriver Health ---
    if ($tierCollectors -contains 'WebDriverHealth' -and -not $SkipWebDrivers) {
        Write-Log -Message 'Collecting: WebDriver Health' -Level Info -Color Cyan
        try {
            $wd                      = Collect-WebDriverHealth
            $results.WebDriverHealth = $wd
            $null = $results.CollectionMeta.components += 'WebDriverHealth'

            $incompatible = @($wd | Where-Object { $_.DriverExists -and -not $_.Compatible })
            if ($incompatible.Count -gt 0) {
                $null = $results.Alerts.Add((New-Alert -Severity 'Warning' -Source 'WebDriverHealth' -MetricName 'WebDriver Compatibility' `
                    -Message "$($incompatible.Count) browser(s) have incompatible WebDriver version" `
                    -Value $incompatible.Count -Threshold 0))
            }

            $notFound = @($wd | Where-Object { -not $_.DriverExists -and $_.BrowserVersion })
            if ($notFound.Count -gt 0) {
                $null = $results.Alerts.Add((New-Alert -Severity 'Warning' -Source 'WebDriverHealth' -MetricName 'WebDriver Missing' `
                    -Message "$($notFound.Count) browser(s) missing WebDriver" `
                    -Value $notFound.Count -Threshold 0))
            }

            if (@($wd).Count -eq 0) {
                Write-Finding -Status 'INFO' -Message 'WebDriver Health: no PSM driver store on this host (skipped)' -Component 'WebDriver'
            }
            else {
                $wdStatus = if ($incompatible.Count -gt 0 -or $notFound.Count -gt 0) { 'WARN' } else { 'OK' }
                Write-Finding -Status $wdStatus -Message "WebDriver Health: $($wd.Count) browser(s) checked" -Component 'WebDriver'
            }
        }
        catch {
            $null = $results.Errors.Add([PSCustomObject]@{ collector = 'WebDriverHealth'; error = $_.Exception.Message })
            Write-Log -Message "WebDriverHealth collector failed: $($_.Exception.Message)" -Level Error -Color Red
        }
    }

    # --- PVWA / IIS Health ---
    if ($tierCollectors -contains 'PVWAHealth' -and -not $SkipPVWA) {
        Write-Log -Message 'Collecting: PVWA/IIS Health' -Level Info -Color Cyan
        try {
            $pvwa                    = Collect-PVWAHealth
            $results.PVWAHealth      = $pvwa
            $null = $results.CollectionMeta.components += 'PVWAHealth'

            if ($pvwa.Status -eq 'NotInstalled') {
                Write-Finding -Status 'INFO' -Message 'PVWA/IIS Health: not installed on this host (skipped)' -Component 'PVWAHealth'
            }
            else {
                if ($pvwa.Status -eq 'Critical') {
                    $null = $results.Alerts.Add((New-Alert -Severity 'Critical' -Source 'PVWAHealth' -MetricName 'PVWA IIS' `
                        -Message "PVWA IIS unhealthy (Service:$($pvwa.IISServiceStatus) AppPool:$($pvwa.AppPoolStatus))" -Value 0 -Threshold 0))
                }
                elseif ($pvwa.Status -eq 'Warning') {
                    $null = $results.Alerts.Add((New-Alert -Severity 'Warning' -Source 'PVWAHealth' -MetricName 'PVWA IIS' `
                        -Message "PVWA IIS degraded (AppPool:$($pvwa.AppPoolStatus) Recycles24h:$($pvwa.RecentRecycleCount) MemMB:$($pvwa.MemoryUsageMB))" `
                        -Value $pvwa.RecentRecycleCount -Threshold $script:Config.pvwaHealth.recycleWarnCount))
                }

                Write-Finding -Status $(if ($pvwa.Status -eq 'OK') { 'OK' } elseif ($pvwa.Status -eq 'Warning') { 'WARN' } else { 'FAIL' }) `
                    -Message "PVWA/IIS Health: $($pvwa.Status) (IIS:$($pvwa.IISServiceStatus) Pool:$($pvwa.AppPoolStatus))" -Component 'PVWAHealth'
            }
        }
        catch {
            $null = $results.Errors.Add([PSCustomObject]@{ collector = 'PVWAHealth'; error = $_.Exception.Message })
            Write-Log -Message "PVWAHealth collector failed: $($_.Exception.Message)" -Level Error -Color Red
        }
    }

    # --- CyberArk Log Scan ---
    if ($tierCollectors -contains 'LogScan' -and -not $SkipLogScan) {
        Write-Log -Message 'Collecting: CyberArk Log Scan' -Level Info -Color Cyan
        try {
            $logscan               = Collect-CALogScan
            $results.LogScan       = $logscan
            $null = $results.CollectionMeta.components += 'LogScan'

            if ($logscan.Status -eq 'NotInstalled') {
                Write-Finding -Status 'INFO' -Message 'CyberArk Log Scan: no CyberArk logs on this host (skipped)' -Component 'LogScan'
            }
            else {
                if ($logscan.Status -eq 'Critical') {
                    $null = $results.Alerts.Add((New-Alert -Severity 'Critical' -Source 'LogScan' -MetricName 'CyberArk Log Errors' `
                        -Message "CyberArk logs report $($logscan.TotalErrors) error(s) (max $($logscan.MaxSourceErrors) in one log)" `
                        -Value $logscan.MaxSourceErrors -Threshold $script:Config.logScan.criticalCount))
                }
                elseif ($logscan.Status -eq 'Warning') {
                    $null = $results.Alerts.Add((New-Alert -Severity 'Warning' -Source 'LogScan' -MetricName 'CyberArk Log Errors' `
                        -Message "CyberArk logs report $($logscan.TotalErrors) error(s), $($logscan.TotalWarnings) warning(s)" `
                        -Value $logscan.TotalErrors -Threshold $script:Config.logScan.warnCount))
                }

                Write-Finding -Status $(if ($logscan.Status -eq 'OK') { 'OK' } elseif ($logscan.Status -eq 'Warning') { 'WARN' } else { 'FAIL' }) `
                    -Message "CyberArk Log Scan: $($logscan.Status) (Errors:$($logscan.TotalErrors) Warnings:$($logscan.TotalWarnings))" -Component 'LogScan'
            }
        }
        catch {
            $null = $results.Errors.Add([PSCustomObject]@{ collector = 'LogScan'; error = $_.Exception.Message })
            Write-Log -Message "LogScan collector failed: $($_.Exception.Message)" -Level Error -Color Red
        }
    }

    # Recency findings: unified service + log recency surface.
    try { foreach ($f in @(Get-CollectionFindings -Results $results)) { $null = $results.Findings.Add($f) } }
    catch { Write-Log -Message "Findings aggregation failed (non-fatal): $($_.Exception.Message)" -Level Warn -Color Yellow }

    # Overall health
    $overallStatus = Get-OverallHealthStatus -Alerts @($results.Alerts)
    $results.CollectionMeta['overallStatus'] = $overallStatus
    $results.CollectionMeta['alertCount']    = $results.Alerts.Count
    $results.CollectionMeta['errorCount']    = $results.Errors.Count
    $results.CollectionMeta['durationMs']    = [math]::Round(((Get-Date) - $script:StartTime).TotalMilliseconds, 0)

    Write-Log -Message "Collection complete: $overallStatus (Alerts:$($results.Alerts.Count) Errors:$($results.Errors.Count))" -Level Info -Color $(if ($overallStatus -eq 'OK') { 'Green' } elseif ($overallStatus -eq 'Warning') { 'Yellow' } else { 'Red' })

    return $results
}

#endregion

#region Capacity Forecasting

function Get-CapacityForecast {
    <#
    .SYNOPSIS
        Linear regression forecast for a single metric using JSONL history.
    .DESCRIPTION
        Reads SystemHealth records from JSONL, extracts (timestamp, value) pairs
        for the specified metric, and performs linear regression to predict when
        a threshold will be reached.
    .PARAMETER MetricName
        Name of the metric to forecast: CPU, Memory, or a disk drive letter (e.g. 'C:')
    .PARAMETER MetricsDir
        Directory containing platform-metrics-*.jsonl files.
    .PARAMETER ThresholdValue
        The capacity threshold to forecast against.
    .PARAMETER LookbackDays
        Number of days of historical data to include. Default: 30.
    .OUTPUTS
        [PSCustomObject] Forecast result with trend, growth rate, days until limit.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject])]
    param(
        [Parameter(Mandatory)]
        [string]$MetricName,

        [Parameter(Mandatory)]
        [string]$MetricsDir,

        [Parameter()]
        [double]$ThresholdValue = 0,

        [Parameter()]
        [int]$LookbackDays = 30
    )

    # Default thresholds from config
    if ($ThresholdValue -le 0) {
        $cfg = $script:Config
        switch -Regex ($MetricName) {
            'CPU'    { $ThresholdValue = $cfg.thresholds.cpuCriticalPercent }
            'Memory' { $ThresholdValue = $cfg.thresholds.memoryCriticalPercent }
            default  { $ThresholdValue = $cfg.thresholds.diskCriticalPercent }
        }
    }

    # Initialize result
    $result = [PSCustomObject]@{
        MetricName      = $MetricName
        DataPoints      = 0
        CurrentValue    = 0
        GrowthRateDaily = 0
        DaysUntilLimit  = [int]::MaxValue
        ProjectedDate   = $null
        Threshold       = $ThresholdValue
        Recommendation  = ''
        TrendDirection  = 'Stable'
    }

    # Read historical SystemHealth records from JSONL
    $records = @(Read-MetricRecords -MetricsDir $MetricsDir -RecordType 'SystemHealth' -LookbackDays $LookbackDays)

    if ($records.Count -lt 2) {
        $result.Recommendation = 'Insufficient data for forecast (need at least 2 data points)'
        return $result
    }

    # Extract (timestamp, value) pairs based on MetricName
    $dataPoints = [System.Collections.ArrayList]::new()
    foreach ($rec in $records) {
        $ts = $null
        $val = $null
        try {
            if ($rec.PSObject.Properties.Name -contains 'timestamp') {
                $ts = [DateTime]$rec.timestamp
            }
            elseif ($rec.PSObject.Properties.Name -contains 'CheckedAt') {
                $ts = [DateTime]$rec.CheckedAt
            }
            if ($null -eq $ts) { continue }

            switch -Regex ($MetricName) {
                '^CPU$' {
                    if ($null -ne $rec.CPU -and $null -ne $rec.CPU.Average) {
                        $val = [double]$rec.CPU.Average
                    }
                }
                '^Memory$' {
                    if ($null -ne $rec.Memory -and $null -ne $rec.Memory.UsedPercent) {
                        $val = [double]$rec.Memory.UsedPercent
                    }
                }
                default {
                    # Disk drive letter like C: or D:
                    if ($null -ne $rec.Disks) {
                        $diskObj = $rec.Disks | Where-Object { $_.DriveLetter -eq $MetricName } | Select-Object -First 1
                        if ($null -ne $diskObj -and $null -ne $diskObj.UsedPercent) {
                            $val = [double]$diskObj.UsedPercent
                        }
                    }
                }
            }

            if ($null -ne $val) {
                $null = $dataPoints.Add([PSCustomObject]@{ Timestamp = $ts; Value = $val })
            }
        }
        catch { continue }
    }

    $result.DataPoints = $dataPoints.Count

    if ($dataPoints.Count -lt 2) {
        $result.Recommendation = 'Insufficient data for forecast (need at least 2 data points)'
        return $result
    }

    $result.CurrentValue = [math]::Round($dataPoints[-1].Value, 2)

    # Present breach takes priority over any forecast horizon: a metric already
    # at/over the limit is a current problem, not a future projection, and must
    # be reported regardless of how little history exists (otherwise a full disk
    # would read "window too short / Stable").
    if ($result.CurrentValue -ge $ThresholdValue) {
        $result.DaysUntilLimit = 0
        $result.ProjectedDate  = Get-Date
        $result.Recommendation = "CRITICAL: Current value ($($result.CurrentValue)) exceeds threshold ($ThresholdValue). Immediate action required."
        return $result
    }

    # Minimum observation window. A linear regression over (time-in-DAYS, value)
    # pairs that all fall inside a few minutes divides a tiny value change by a
    # tiny time span, manufacturing an enormous per-day slope -- 30 min of normal
    # memory jitter becomes "17%/day -> URGENT, 2 days". Refuse to forecast a
    # daily rate until the history spans a meaningful window (config-driven).
    $minSpanHours = 24.0
    if ($null -ne $script:Config) {
        $rep = $script:Config.reporting
        if ($rep -is [hashtable] -and $rep.ContainsKey('forecastMinSpanHours') -and
            $null -ne $rep['forecastMinSpanHours']) {
            $minSpanHours = [double]$rep['forecastMinSpanHours']
        }
    }
    $spanHours = ($dataPoints[-1].Timestamp - $dataPoints[0].Timestamp).TotalHours
    if ($spanHours -lt $minSpanHours) {
        $result.GrowthRateDaily = 0
        $result.DaysUntilLimit  = [int]::MaxValue
        $result.TrendDirection  = 'Stable'
        $result.Recommendation  = "INFO: Observation window too short ($([math]::Round($spanHours,1))h of $([math]::Round($minSpanHours,0))h needed) for a reliable capacity forecast. Keep collecting history."
        return $result
    }

    # Linear regression: y = mx + b
    # x = days offset from first data point, y = metric value
    $firstTimestamp = $dataPoints[0].Timestamp
    $n    = $dataPoints.Count
    $sumX  = [double]0
    $sumY  = [double]0
    $sumXY = [double]0
    $sumX2 = [double]0

    foreach ($point in $dataPoints) {
        $dayOffset = ($point.Timestamp - $firstTimestamp).TotalDays
        $value     = $point.Value

        $sumX  += $dayOffset
        $sumY  += $value
        $sumXY += ($dayOffset * $value)
        $sumX2 += ($dayOffset * $dayOffset)
    }

    # Calculate slope (m) and intercept (b)
    $denominator = ($n * $sumX2) - ($sumX * $sumX)

    if ($denominator -eq 0) {
        $result.GrowthRateDaily = 0
        $result.CurrentValue    = $sumY / $n
        $result.Recommendation  = 'No growth trend detected (flat data)'
        return $result
    }

    $slope = (($n * $sumXY) - ($sumX * $sumY)) / $denominator

    # Current value is the latest data point
    $result.CurrentValue    = [math]::Round($dataPoints[-1].Value, 2)
    $result.GrowthRateDaily = [math]::Round($slope, 4)

    # Determine trend direction
    if ($slope -gt 0.1) {
        $result.TrendDirection = 'Increasing'
    }
    elseif ($slope -lt -0.1) {
        $result.TrendDirection = 'Decreasing'
    }
    else {
        $result.TrendDirection = 'Stable'
    }

    # Calculate days until threshold
    if ($slope -gt 0 -and $result.CurrentValue -lt $ThresholdValue) {
        $daysUntilThreshold = ($ThresholdValue - $result.CurrentValue) / $slope
        # A near-flat (tiny positive) slope -- the normal steady state -- yields an
        # astronomically large horizon that overflows both Int32 and DateTime.
        # Cap anything beyond 10 years as "no foreseeable concern". Note: the old
        # [math]::Max(0, ...) selected the Int32 overload (literal 0 is [int]), which
        # threw when Ceiling exceeded Int32.MaxValue -- keep the [double] cast on 0.
        $ceil = [math]::Ceiling($daysUntilThreshold)
        if ($ceil -ge 3650) {
            $result.DaysUntilLimit = [int]::MaxValue
            $result.ProjectedDate  = $null
        }
        else {
            $result.DaysUntilLimit = [int][math]::Max([double]0, $ceil)
            $result.ProjectedDate  = (Get-Date).AddDays($result.DaysUntilLimit)
        }
    }
    elseif ($result.CurrentValue -ge $ThresholdValue) {
        $result.DaysUntilLimit = 0
        $result.ProjectedDate  = Get-Date
    }

    # Generate recommendation
    if ($result.CurrentValue -ge $ThresholdValue) {
        $result.Recommendation = "CRITICAL: Current value ($($result.CurrentValue)) exceeds threshold ($ThresholdValue). Immediate action required."
    }
    elseif ($result.DaysUntilLimit -le 7) {
        $result.Recommendation = "URGENT: Threshold will be reached in $($result.DaysUntilLimit) days. Plan capacity expansion immediately."
    }
    elseif ($result.DaysUntilLimit -le 30) {
        $result.Recommendation = "WARNING: Threshold will be reached in $($result.DaysUntilLimit) days. Begin capacity planning."
    }
    elseif ($result.DaysUntilLimit -le 90) {
        $result.Recommendation = "INFO: Capacity adequate for $($result.DaysUntilLimit) days at current growth rate."
    }
    else {
        $result.Recommendation = 'HEALTHY: No capacity concerns. Growth rate is sustainable.'
    }

    Write-Log -Message "Capacity forecast for ${MetricName}: $($result.TrendDirection), $($result.DaysUntilLimit) days until limit" -Level Debug -Component 'Forecasting'

    return $result
}

function Get-AllForecasts {
    <#
    .SYNOPSIS
        Runs capacity forecasts for CPU, Memory, and each discovered disk.
    .PARAMETER MetricsDir
        Directory containing JSONL metrics files.
    .PARAMETER LookbackDays
        Number of days of history to use.
    .OUTPUTS
        [PSCustomObject[]] Array of forecast results.
    #>
    [CmdletBinding()]
    [OutputType([PSCustomObject[]])]
    param(
        [Parameter(Mandatory)]
        [string]$MetricsDir,

        [Parameter()]
        [int]$LookbackDays = 30
    )

    $forecasts = @()

    # CPU forecast
    $forecasts += Get-CapacityForecast -MetricName 'CPU' -MetricsDir $MetricsDir -LookbackDays $LookbackDays

    # Memory forecast
    $forecasts += Get-CapacityForecast -MetricName 'Memory' -MetricsDir $MetricsDir -LookbackDays $LookbackDays

    # Disk forecasts: discover drive letters from the most recent SystemHealth record
    $recentRecords = @(Read-MetricRecords -MetricsDir $MetricsDir -RecordType 'SystemHealth' -LookbackDays 1)
    if ($recentRecords.Count -gt 0) {
        $latest = $recentRecords[-1]
        if ($null -ne $latest.Disks) {
            foreach ($disk in $latest.Disks) {
                if ($disk.DriveLetter) {
                    $forecasts += Get-CapacityForecast -MetricName $disk.DriveLetter -MetricsDir $MetricsDir -LookbackDays $LookbackDays
                }
            }
        }
    }

    return $forecasts
}

#endregion

#region Embedded CSS

function Get-ReportCSS {
    <#
    .SYNOPSIS
        Returns the full embedded CSS for the HTML health report.
        Dark theme design system matching the CyberArk Toolbox reports.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param()

    return @'
/* === CyberArk Toolbox Report Design System v1.0 === */
/* Dark theme based on v4 License Analyzer design language */

* { margin: 0; padding: 0; box-sizing: border-box; }

body {
    font-family: -apple-system, 'Segoe UI', system-ui, Roboto, sans-serif, Arial;
    background: #0d1117;
    color: #e6edf3;
    line-height: 1.6;
    padding: 20px;
    font-variant-numeric: tabular-nums;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
}

/* --- Header --- */
.header {
    background: linear-gradient(135deg, #1a5f7a 0%, #0d3b4f 100%);
    padding: 30px;
    border-radius: 12px;
    margin-bottom: 24px;
}
.header h1 {
    color: #fff;
    font-size: 28px;
    font-weight: 700;
    margin-bottom: 8px;
}
.header .subtitle {
    color: rgba(255,255,255,0.85);
    font-size: 14px;
}
.header .meta {
    display: flex;
    gap: 24px;
    flex-wrap: wrap;
    margin-top: 12px;
    font-size: 13px;
    color: rgba(255,255,255,0.7);
}
.header .meta strong { color: rgba(255,255,255,0.9); }

/* --- Executive Summary / Narrative --- */
.executive-summary {
    background: #161b22;
    border: 1px solid #30363d;
    border-left: 4px solid #58a6ff;
    border-radius: 8px;
    padding: 20px 24px;
    margin-bottom: 24px;
    font-size: 15px;
    line-height: 1.7;
    color: #c9d1d9;
}
.executive-summary strong { color: #e6edf3; }
.executive-summary .trend-up { color: #f85149; }
.executive-summary .trend-down { color: #3fb950; }
.executive-summary .trend-stable { color: #8b949e; }

/* --- Mock Data Banner --- */
.mock-banner {
    background: #3d2e0d;
    border: 1px solid #d29922;
    border-radius: 8px;
    padding: 12px 20px;
    margin-bottom: 24px;
    text-align: center;
    font-weight: 600;
    color: #d29922;
    font-size: 14px;
}

/* --- Sections --- */
.section {
    background: #161b22;
    border: 1px solid #30363d;
    border-radius: 8px;
    padding: 24px;
    margin-bottom: 24px;
}
.section h2 {
    font-size: 18px;
    margin-bottom: 16px;
    color: #58a6ff;
    border-bottom: 1px solid #30363d;
    padding-bottom: 8px;
}
.section h3 {
    font-size: 15px;
    color: #c9d1d9;
    margin: 16px 0 12px 0;
}
.section p {
    color: #8b949e;
    font-size: 14px;
    margin-bottom: 12px;
}

/* --- Card Grid (KPI Cards) --- */
.card-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 16px;
    margin-bottom: 24px;
}
.card {
    background: #161b22;
    border: 1px solid #30363d;
    border-radius: 8px;
    padding: 20px;
    text-align: center;
}
.card .value {
    font-size: 36px;
    font-weight: 700;
    color: #58a6ff;
    line-height: 1.2;
}
.card .label {
    font-size: 13px;
    color: #8b949e;
    margin-top: 4px;
}
.card .sublabel {
    font-size: 11px;
    color: #484f58;
    margin-top: 2px;
}
.card .delta {
    font-size: 12px;
    margin-top: 4px;
    font-weight: 600;
}
.card .delta.up { color: #f85149; }
.card .delta.down { color: #3fb950; }
.card .delta.stable { color: #8b949e; }

/* Card color modifiers */
.card.success .value { color: #3fb950; }
.card.warning .value { color: #d29922; }
.card.danger .value { color: #f85149; }
.card.highlight .value { color: #3fb950; }
.card.muted .value { color: #8b949e; }

/* Card with left accent border */
.card.accent-success { border-left: 4px solid #3fb950; }
.card.accent-warning { border-left: 4px solid #d29922; }
.card.accent-danger { border-left: 4px solid #f85149; }
.card.accent-primary { border-left: 4px solid #58a6ff; }

/* --- Tables --- */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 12px;
}
th, td {
    padding: 10px 12px;
    text-align: left;
    border-bottom: 1px solid #21262d;
}
th {
    background: #0d1117;
    color: #8b949e;
    font-weight: 600;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
tr:hover { background: #1c2128; }
.num { text-align: right; font-variant-numeric: tabular-nums; }

/* --- Badges --- */
.badge {
    display: inline-block;
    padding: 2px 10px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
    white-space: nowrap;
}
.badge-high, .badge-critical { background: #3d1f1f; color: #f85149; }
.badge-medium, .badge-warning { background: #3d2e0d; color: #d29922; }
.badge-low, .badge-info { background: #1a3050; color: #58a6ff; }
.badge-ok, .badge-success { background: #1f3a2e; color: #3fb950; }
.badge-group { background: #1f3a2e; color: #3fb950; }
.badge-user { background: #1a3050; color: #58a6ff; }
.badge-muted { background: #21262d; color: #8b949e; }

/* --- Status Colors (inline) --- */
.status-green, .status-ok { color: #3fb950; font-weight: 600; }
.status-yellow, .status-warning { color: #d29922; font-weight: 600; }
.status-red, .status-critical { color: #f85149; font-weight: 600; }
.status-blue, .status-info { color: #58a6ff; font-weight: 600; }
.status-muted { color: #8b949e; }

/* --- Progress Bars --- */
.bar-container {
    background: #21262d;
    border-radius: 4px;
    overflow: hidden;
    height: 20px;
    position: relative;
}
.bar {
    height: 100%;
    border-radius: 4px;
    min-width: 4px;
    transition: width 0.3s ease;
}
.bar-success { background: linear-gradient(90deg, #1f6f3a, #3fb950); }
.bar-warning { background: linear-gradient(90deg, #7a5a0d, #d29922); }
.bar-danger { background: linear-gradient(90deg, #7a1f1f, #f85149); }
.bar-primary { background: linear-gradient(90deg, #1a5f7a, #58a6ff); }
.bar-label {
    position: absolute;
    right: 8px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 11px;
    font-weight: 600;
    color: #e6edf3;
    text-shadow: 0 1px 2px rgba(0,0,0,0.5);
}

/* Inline trend bars (for tables) */
.trend-bar {
    display: inline-block;
    height: 16px;
    background: #58a6ff;
    border-radius: 3px;
    min-width: 2px;
    vertical-align: middle;
}

/* --- Gauge (CSS-only donut) --- */
.gauge-container {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 30px;
    margin: 20px 0;
}
.gauge {
    position: relative;
    width: 160px;
    height: 160px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    /* conic-gradient set inline via style attribute */
}
.gauge-inner {
    width: 110px;
    height: 110px;
    border-radius: 50%;
    background: #161b22;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
}
.gauge-value {
    font-size: 32px;
    font-weight: 700;
    line-height: 1.1;
}
.gauge-label {
    font-size: 11px;
    color: #8b949e;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
.gauge-legend {
    display: flex;
    flex-direction: column;
    gap: 8px;
}
.gauge-legend-item {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    color: #c9d1d9;
}
.gauge-legend-dot {
    width: 12px;
    height: 12px;
    border-radius: 3px;
    flex-shrink: 0;
}

/* --- Action Items --- */
.action-items {
    margin-top: 16px;
}
.action-item {
    display: flex;
    align-items: flex-start;
    gap: 15px;
    padding: 14px 16px;
    margin-bottom: 10px;
    border-radius: 6px;
    background: #1c2128;
    border-left: 4px solid #484f58;
}
.action-item.critical {
    border-left-color: #f85149;
    background: #1f1315;
}
.action-item.warning {
    border-left-color: #d29922;
    background: #1f1c13;
}
.action-item.info {
    border-left-color: #58a6ff;
    background: #131a24;
}
.action-item .severity-badge {
    flex-shrink: 0;
}
.action-item-text {
    flex: 1;
}
.action-item-text .description {
    font-weight: 600;
    color: #e6edf3;
    margin-bottom: 4px;
    font-size: 14px;
}
.action-item-text .recommendation {
    font-size: 13px;
    color: #8b949e;
}
.action-item-text .impact {
    font-size: 12px;
    color: #6e7681;
    margin-top: 4px;
    font-style: italic;
}

/* --- Forecast / Recommendation Boxes --- */
.rec-box {
    padding: 16px;
    margin: 12px 0;
    border-radius: 6px;
    border-left: 4px solid;
}
.rec-box.critical { background: #1f1315; border-color: #f85149; }
.rec-box.warning { background: #1f1c13; border-color: #d29922; }
.rec-box.info { background: #131a24; border-color: #58a6ff; }
.rec-box.healthy { background: #131f17; border-color: #3fb950; }
.rec-box p { color: #c9d1d9; margin-bottom: 6px; }
.rec-box strong { color: #e6edf3; }

/* --- Sparklines --- */
.sparkline { display: inline-flex; align-items: flex-end; gap: 2px; height: 30px; }
.sparkline-bar { display: inline-block; width: 8px; min-height: 2px; border-radius: 1px; }
.sparkline-bar.green { background: #3fb950; }
.sparkline-bar.amber { background: #d29922; }
.sparkline-bar.red { background: #f85149; }
.sparkline-empty { color: #484f58; font-style: italic; }

/* --- Footer --- */
.footer {
    margin-top: 24px;
    padding: 16px;
    text-align: center;
    color: #484f58;
    font-size: 12px;
    border-top: 1px solid #21262d;
}

/* --- Utility --- */
.flex-row { display: flex; gap: 16px; flex-wrap: wrap; }
.flex-center { display: flex; align-items: center; justify-content: center; }
.text-right { text-align: right; }
.text-center { text-align: center; }
.mt-0 { margin-top: 0; }
.mt-1 { margin-top: 8px; }
.mt-2 { margin-top: 16px; }
.mb-0 { margin-bottom: 0; }
.mb-1 { margin-bottom: 8px; }
.mb-2 { margin-bottom: 16px; }
.fw-bold { font-weight: 700; }
.fs-sm { font-size: 12px; }
.fs-xs { font-size: 11px; }
.text-muted { color: #8b949e; }
.text-success { color: #3fb950; }
.text-warning { color: #d29922; }
.text-danger { color: #f85149; }

/* --- Print Styles --- */
@media print {
    body {
        background: white;
        color: #333;
        padding: 10px;
        print-color-adjust: exact;
        -webkit-print-color-adjust: exact;
    }
    .container { max-width: 100%; }
    .header {
        background: #333 !important;
        color: white !important;
    }
    .section {
        background: white;
        border: 1px solid #ddd;
        page-break-inside: avoid;
    }
    .card {
        background: white;
        border: 1px solid #ddd;
    }
    .card .value { color: #333; }
    .card.success .value { color: #28a745; }
    .card.warning .value { color: #b8860b; }
    .card.danger .value { color: #cc0000; }
    table { page-break-inside: avoid; }
    th { background: #f5f5f5; color: #333; }
    tr:hover { background: transparent; }
    .bar-container { border: 1px solid #ddd; }
    .action-item { border: 1px solid #ddd; }
    .mock-banner { border: 2px solid #b8860b; }
    .footer { color: #666; }
    .gauge { print-color-adjust: exact; -webkit-print-color-adjust: exact; }
}
'@
}

#endregion

#region HTML Report Generator

function Get-StatusBadgeHtml {
    <#
    .SYNOPSIS
        Returns an HTML badge span for a status string.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory)]
        [string]$Status
    )

    $badgeClass = switch ($Status) {
        { $_ -in 'OK','Running','Healthy','Connected','Compatible','True','Yes','Recovered' } { 'badge-ok' }
        { $_ -in 'Warning','Degraded','Expiring','Suspect' }                                  { 'badge-warning' }
        { $_ -in 'Critical','Stopped','Unhealthy','Error','Unreachable','Expired','False','No','Incompatible','Down' } { 'badge-critical' }
        default { 'badge-muted' }
    }

    $safeStatus = [System.Net.WebUtility]::HtmlEncode($Status)
    return "<span class=`"badge $badgeClass`">$safeStatus</span>"
}

function Get-BarHtml {
    <#
    .SYNOPSIS
        Returns an HTML progress bar for a percentage value.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory)]
        [double]$Percent,
        [string]$Label = ''
    )

    $clampedPct = [math]::Max(0, [math]::Min(100, $Percent))
    $barClass = if ($clampedPct -ge 90) { 'bar-danger' } elseif ($clampedPct -ge 75) { 'bar-warning' } else { 'bar-success' }
    $labelHtml = if ($Label) { "<span class=`"bar-label`">$([System.Net.WebUtility]::HtmlEncode($Label))</span>" } else { '' }

    return "<div class=`"bar-container`"><div class=`"bar $barClass`" style=`"width:$($clampedPct)%`"></div>$labelHtml</div>"
}

function New-PlatformHealthReport {
    <#
    .SYNOPSIS
        Generates a complete HTML health report from collection results.
    .DESCRIPTION
        Builds an HTML report using [System.Text.StringBuilder] for performance.
        Includes all sections: header, executive summary, health score gauge,
        KPI cards, tables for each collector, capacity forecasts, and action items.
    .PARAMETER CollectionResults
        The hashtable returned by Invoke-MetricsCollection.
    .PARAMETER Forecasts
        Optional array of forecast objects from Get-AllForecasts.
    .PARAMETER RequirementEvals
        Optional array of evaluation results from Invoke-RequirementsEvaluation.
    .PARAMETER PlatformState
        Optional platform state hashtable for trend sparklines.
    .OUTPUTS
        [string] Complete HTML document string.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory)]
        [hashtable]$CollectionResults,

        [Parameter()]
        [object[]]$Forecasts = @(),

        [Parameter()]
        [object[]]$RequirementEvals = @(),

        [Parameter()]
        [hashtable]$PlatformState = $null
    )

    $sb = [System.Text.StringBuilder]::new(32768)
    $E  = [System.Net.WebUtility]

    $meta       = $CollectionResults.CollectionMeta
    $sh         = $CollectionResults.SystemHealth
    $sr         = $CollectionResults.ServiceStatus
    $ch         = $CollectionResults.CertificateHealth
    $sc         = $CollectionResults.ServerCapacity
    $cpm        = $CollectionResults.CPMHealth
    $psm        = $CollectionResults.PSMHealth
    $conn       = $CollectionResults.Connectivity
    $wd         = $CollectionResults.WebDriverHealth
    $pvwa       = $CollectionResults.PVWAHealth
    $logscan    = $CollectionResults.LogScan
    $alerts     = @($CollectionResults.Alerts)

    $serverName  = if ($meta -and $meta['serverName']) { $E::HtmlEncode($meta['serverName']) } else { $E::HtmlEncode($env:COMPUTERNAME) }
    $environment = $E::HtmlEncode($script:Config.server.environment)
    $role        = $E::HtmlEncode($script:Config.server.role)
    $timestamp   = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $title       = $E::HtmlEncode($script:Config.reporting.title)

    # Check if any collector has mock data
    $hasMockData = $false
    foreach ($key in @('SystemHealth','ServiceStatus','CertificateHealth','ServerCapacity','CPMHealth','PSMHealth')) {
        if ($null -ne $CollectionResults[$key] -and $CollectionResults[$key].PSObject.Properties.Name -contains 'IsMockData' -and $CollectionResults[$key].IsMockData) {
            $hasMockData = $true
            break
        }
    }
    if (-not $hasMockData -and $null -ne $conn) {
        foreach ($c in $conn) {
            if ($c.PSObject.Properties.Name -contains 'IsMockData' -and $c.IsMockData) { $hasMockData = $true; break }
        }
    }
    if (-not $hasMockData -and $null -ne $wd) {
        foreach ($w in $wd) {
            if ($w.PSObject.Properties.Name -contains 'IsMockData' -and $w.IsMockData) { $hasMockData = $true; break }
        }
    }

    # --- Calculate Health Score ---
    $collectorStatuses = @()
    if ($null -ne $sh) {
        $collectorStatuses += switch ($sh.Status) { 'OK' { 100 } 'Warning' { 50 } default { 0 } }
    }
    if ($null -ne $sr) {
        $collectorStatuses += switch ($sr.Status) { 'OK' { 100 } 'Warning' { 50 } default { 0 } }
    }
    if ($null -ne $ch) {
        $collectorStatuses += switch ($ch.Status) { 'OK' { 100 } 'Warning' { 50 } default { 0 } }
    }
    if ($null -ne $sc) {
        $collectorStatuses += switch ($sc.Status) { 'OK' { 100 } 'Warning' { 50 } default { 0 } }
    }
    # 'NotInstalled' components are neutral -- exclude them from the score so an
    # absent CPM/PSM on a non-CyberArk host doesn't drag the gauge down.
    if ($null -ne $cpm -and $cpm.Status -ne 'NotInstalled') {
        $collectorStatuses += switch ($cpm.Status) { 'Healthy' { 100 } { $_ -in 'Warning','Unhealthy' } { 50 } default { 0 } }
    }
    if ($null -ne $psm -and $psm.Status -ne 'NotInstalled') {
        $collectorStatuses += switch ($psm.Status) { 'Healthy' { 100 } { $_ -in 'Warning','Unhealthy' } { 50 } default { 0 } }
    }
    if ($null -ne $pvwa -and $pvwa.Status -ne 'NotInstalled') {
        $collectorStatuses += switch ($pvwa.Status) { 'OK' { 100 } 'Warning' { 50 } default { 0 } }
    }
    if ($null -ne $logscan -and $logscan.Status -ne 'NotInstalled') {
        $collectorStatuses += switch ($logscan.Status) { 'OK' { 100 } 'Warning' { 50 } default { 0 } }
    }
    # Connectivity (array of per-target results) and WebDriver (array per browser)
    # were previously excluded from the score entirely -- a vault-unreachable
    # event or a broken driver wouldn't move the gauge. Fold in the worst target.
    if ($null -ne $conn -and @($conn).Count -gt 0) {
        $connScore = 100
        foreach ($t in @($conn)) {
            $s = "$(if ($t -is [hashtable]) { $t['Status'] } else { $t.Status })"
            $v = if ($s -eq 'Connected') { 100 } elseif ($s -eq 'Suspect') { 50 } else { 0 }
            if ($v -lt $connScore) { $connScore = $v }
        }
        $collectorStatuses += $connScore
    }
    if ($null -ne $wd -and @($wd).Count -gt 0) {
        $wdScore = 100
        foreach ($b in @($wd)) {
            $c = if ($b -is [hashtable]) { $b['Compatible'] } else { $b.Compatible }
            $v = if ($c) { 100 } else { 50 }
            if ($v -lt $wdScore) { $wdScore = $v }
        }
        $collectorStatuses += $wdScore
    }

    $healthScore = if ($collectorStatuses.Count -gt 0) {
        [math]::Round(($collectorStatuses | Measure-Object -Average).Average, 0)
    } else { 0 }

    $scoreColor = if ($healthScore -ge 80) { '#3fb950' } elseif ($healthScore -ge 50) { '#d29922' } else { '#f85149' }
    $scoreLabel = if ($healthScore -ge 80) { 'Healthy' } elseif ($healthScore -ge 50) { 'Degraded' } else { 'Critical' }

    # ===== Build HTML =====

    # 1. HTML head
    $css = Get-ReportCSS
    $null = $sb.AppendLine('<!DOCTYPE html>')
    $null = $sb.AppendLine('<html lang="en">')
    $null = $sb.AppendLine('<head>')
    $null = $sb.AppendLine('<meta charset="UTF-8">')
    $null = $sb.AppendLine('<meta name="viewport" content="width=device-width, initial-scale=1.0">')
    $null = $sb.AppendLine("<title>$title - $serverName</title>")
    $null = $sb.AppendLine('<style>')
    $null = $sb.AppendLine($css)
    $null = $sb.AppendLine('</style>')
    $null = $sb.AppendLine('</head>')
    $null = $sb.AppendLine('<body>')
    $null = $sb.AppendLine('<div class="container">')

    # 2. Header
    $null = $sb.AppendLine('<div class="header">')
    $null = $sb.AppendLine("  <h1>$title</h1>")
    $null = $sb.AppendLine("  <div class=`"subtitle`">Platform Health Assessment</div>")
    $null = $sb.AppendLine('  <div class="meta">')
    $null = $sb.AppendLine("    <span><strong>Server:</strong> $serverName</span>")
    $null = $sb.AppendLine("    <span><strong>Environment:</strong> $environment</span>")
    $null = $sb.AppendLine("    <span><strong>Role:</strong> $role</span>")
    $null = $sb.AppendLine("    <span><strong>Generated:</strong> $timestamp</span>")
    $null = $sb.AppendLine("    <span><strong>Version:</strong> v$($script:ToolVersion)</span>")
    $null = $sb.AppendLine('  </div>')
    $null = $sb.AppendLine('</div>')

    # 3. Mock data banner
    if ($hasMockData) {
        $null = $sb.AppendLine('<div class="mock-banner">MOCK DATA -- This report was generated with simulated data for testing purposes. Values are not from live systems.</div>')
    }

    # 4. Executive Summary
    $overallStatus = if ($meta -and $meta['overallStatus']) { $meta['overallStatus'] } else { 'Unknown' }
    $alertCount    = if ($meta -and $meta['alertCount'])    { $meta['alertCount'] }    else { 0 }
    $durationMs    = if ($meta -and $meta['durationMs'])    { $meta['durationMs'] }    else { 0 }

    # The gauge color/label follow the authoritative worst-severity (overall
    # status), not the averaged number: one Critical collector diluted by healthy
    # ones must never render the headline gauge green/amber and hide it. The
    # numeric score remains "percent of subsystems healthy".
    if     ($overallStatus -eq 'Critical') { $scoreColor = '#f85149'; $scoreLabel = 'Critical' }
    elseif ($overallStatus -eq 'Warning')  { $scoreColor = '#d29922'; $scoreLabel = 'Degraded' }
    elseif ($overallStatus -eq 'OK')       { $scoreColor = '#3fb950'; $scoreLabel = 'Healthy'  }

    $summaryNarrative = "Platform health assessment for <strong>$serverName</strong> completed in <strong>${durationMs}ms</strong>. "
    $summaryNarrative += "Overall status: <span class=`"status-$(if ($overallStatus -eq 'OK') {'ok'} elseif ($overallStatus -eq 'Warning') {'warning'} else {'critical'})`">$($E::HtmlEncode($overallStatus))</span>. "
    if ($alertCount -gt 0) {
        $critCount = @($alerts | Where-Object { $_.severity -eq 'Critical' }).Count
        $warnCount = @($alerts | Where-Object { $_.severity -eq 'Warning' }).Count
        $summaryNarrative += "<strong>$alertCount</strong> alert(s) detected"
        if ($critCount -gt 0) { $summaryNarrative += " (<span class=`"status-critical`">$critCount critical</span>)" }
        if ($warnCount -gt 0) { $summaryNarrative += " (<span class=`"status-warning`">$warnCount warning</span>)" }
        $summaryNarrative += ". "
    } else {
        $summaryNarrative += "No alerts detected. All monitored metrics are within acceptable thresholds. "
    }
    $summaryNarrative += "Health score: <strong>$healthScore / 100</strong>."

    $null = $sb.AppendLine('<div class="executive-summary">')
    $null = $sb.AppendLine("  <p>$summaryNarrative</p>")
    $null = $sb.AppendLine('</div>')

    # 5. Health Score Gauge
    $greenDeg = [math]::Round(3.6 * $healthScore, 1)
    $null = $sb.AppendLine('<div class="section">')
    $null = $sb.AppendLine('  <h2>Health Score</h2>')
    $null = $sb.AppendLine('  <div class="gauge-container">')
    $null = $sb.AppendLine("    <div class=`"gauge`" style=`"background: conic-gradient($scoreColor 0deg, $scoreColor ${greenDeg}deg, #21262d ${greenDeg}deg, #21262d 360deg);`">")
    $null = $sb.AppendLine('      <div class="gauge-inner">')
    $null = $sb.AppendLine("        <div class=`"gauge-value`" style=`"color:$scoreColor`">$healthScore</div>")
    $null = $sb.AppendLine('        <div class="gauge-label">HEALTH</div>')
    $null = $sb.AppendLine('      </div>')
    $null = $sb.AppendLine('    </div>')
    $null = $sb.AppendLine('    <div class="gauge-legend">')
    $null = $sb.AppendLine("      <div class=`"gauge-legend-item`"><div class=`"gauge-legend-dot`" style=`"background:$scoreColor`"></div>$scoreLabel ($healthScore%)</div>")
    $null = $sb.AppendLine("      <div class=`"gauge-legend-item`"><div class=`"gauge-legend-dot`" style=`"background:#21262d`"></div>Remaining ($(100 - $healthScore)%)</div>")
    $null = $sb.AppendLine('    </div>')
    $null = $sb.AppendLine('  </div>')
    $null = $sb.AppendLine('</div>')

    # 6. KPI Cards
    $uptimeVal  = if ($null -ne $sh -and $sh.UptimeDays) { [math]::Round($sh.UptimeDays, 1) } else { 'N/A' }
    $cpuVal     = if ($null -ne $sh -and $null -ne $sh.CPU) { "$([math]::Round($sh.CPU.Average, 1))%" } else { 'N/A' }
    $memVal     = if ($null -ne $sh -and $null -ne $sh.Memory) { "$([math]::Round($sh.Memory.UsedPercent, 1))%" } else { 'N/A' }

    $diskWorst = 'N/A'
    $diskClass = ''
    if ($null -ne $sh -and $null -ne $sh.Disks -and @($sh.Disks).Count -gt 0) {
        $worstPct = ($sh.Disks | ForEach-Object { $_.UsedPercent } | Measure-Object -Maximum).Maximum
        $diskWorst = "$([math]::Round($worstPct, 1))%"
        $diskClass = if ($worstPct -ge 90) { 'danger' } elseif ($worstPct -ge 75) { 'warning' } else { 'success' }
    }

    $svcHealthy = 'N/A'
    $svcClass   = ''
    if ($null -ne $sr) {
        $svcHealthy = "$($sr.HealthyServices)/$($sr.TotalServices)"
        $svcClass   = if ($sr.StoppedServices -gt 0) { 'danger' } elseif ($sr.DegradedServices -gt 0) { 'warning' } else { 'success' }
    }

    $certLabel = 'N/A'
    $certClass = ''
    if ($null -ne $ch) {
        $certLabel = "OK:$($ch.OKCount) W:$($ch.WarningCount) C:$($ch.CriticalCount)"
        $certClass = if ($ch.CriticalCount -gt 0 -or $ch.ExpiredCount -gt 0) { 'danger' } elseif ($ch.WarningCount -gt 0) { 'warning' } else { 'success' }
    }

    $cpuClass = ''
    if ($null -ne $sh -and $null -ne $sh.CPU) {
        $cpuClass = if ($sh.CPU.Average -ge 90) { 'danger' } elseif ($sh.CPU.Average -ge 75) { 'warning' } else { 'success' }
    }
    $memClass = ''
    if ($null -ne $sh -and $null -ne $sh.Memory) {
        $memClass = if ($sh.Memory.UsedPercent -ge 90) { 'danger' } elseif ($sh.Memory.UsedPercent -ge 75) { 'warning' } else { 'success' }
    }

    $null = $sb.AppendLine('<div class="card-grid">')

    $null = $sb.AppendLine("  <div class=`"card accent-primary`"><div class=`"value`">$uptimeVal</div><div class=`"label`">Uptime (Days)</div></div>")
    $null = $sb.AppendLine("  <div class=`"card $cpuClass accent-$(if ($cpuClass) {$cpuClass} else {'primary'})`"><div class=`"value`">$cpuVal</div><div class=`"label`">CPU Average</div></div>")
    $null = $sb.AppendLine("  <div class=`"card $memClass accent-$(if ($memClass) {$memClass} else {'primary'})`"><div class=`"value`">$memVal</div><div class=`"label`">Memory Used</div></div>")
    $null = $sb.AppendLine("  <div class=`"card $diskClass accent-$(if ($diskClass) {$diskClass} else {'primary'})`"><div class=`"value`">$diskWorst</div><div class=`"label`">Disk (Worst)</div></div>")
    $null = $sb.AppendLine("  <div class=`"card $svcClass accent-$(if ($svcClass) {$svcClass} else {'primary'})`"><div class=`"value`">$svcHealthy</div><div class=`"label`">Services Healthy</div></div>")
    $null = $sb.AppendLine("  <div class=`"card $certClass accent-$(if ($certClass) {$certClass} else {'primary'})`"><div class=`"value`">$certLabel</div><div class=`"label`">Certificates</div></div>")

    $null = $sb.AppendLine('</div>')

    # 6b. Recent Findings -- unified recency surface (service restarts/crashes + log errors)
    $findings = @($CollectionResults.Findings)
    $null = $sb.AppendLine('<div class="section">')
    $null = $sb.AppendLine('  <h2>Recent Findings</h2>')
    $null = $sb.AppendLine('  <p class="muted">Service restarts/crashes and log errors by recency. Alerts fire on the recent window; the 30d column is history.</p>')
    if ($findings.Count -eq 0) {
        $null = $sb.AppendLine('  <p class="muted">No service restarts/crashes or log errors recorded in the window.</p>')
    }
    else {
        $rank = @{ 'Critical' = 0; 'Warning' = 1; 'OK' = 2 }
        $sorted = $findings | Sort-Object @{ Expression = { $rank["$($_['severity'])"] } }, @{ Expression = { [int]$_['count24h'] }; Descending = $true }
        $null = $sb.AppendLine('  <table>')
        $null = $sb.AppendLine('    <tr><th>Source</th><th>Kind</th><th>Severity</th><th class="num">24h</th><th class="num">7d</th><th class="num">30d</th><th>Last seen</th><th>Detail</th></tr>')
        foreach ($f in $sorted) {
            $badge = Get-StatusBadgeHtml -Status "$($f['severity'])"
            $last  = if ($f['lastAt']) { try { $E::HtmlEncode(([datetime]$f['lastAt']).ToLocalTime().ToString('yyyy-MM-dd HH:mm')) } catch { '-' } } else { '-' }
            $null = $sb.AppendLine("    <tr><td>$($E::HtmlEncode("$($f['source'])"))</td><td>$($E::HtmlEncode("$($f['kind'])"))</td><td>$badge</td><td class=`"num`">$($f['count24h'])</td><td class=`"num`">$($f['count7d'])</td><td class=`"num`">$($f['count30d'])</td><td>$last</td><td>$($E::HtmlEncode("$($f['detail'])"))</td></tr>")
        }
        $null = $sb.AppendLine('  </table>')
    }
    $null = $sb.AppendLine('</div>')

    # 7. Service Status Table
    $null = $sb.AppendLine('<div class="section">')
    $null = $sb.AppendLine('  <h2>Service Status</h2>')
    if ($null -eq $sr -or $null -eq $sr.Services -or @($sr.Services).Count -eq 0) {
        $null = $sb.AppendLine('  <p>Collector not available or no services detected.</p>')
    }
    else {
        $null = $sb.AppendLine('  <table>')
        $null = $sb.AppendLine('    <tr><th>Service Name</th><th>Status</th><th class="num">PID</th><th class="num">Memory MB</th><th class="num">Restarts (24h/7d/30d)</th><th class="num">Crashes 7d</th><th class="num">MTTR (min)</th><th class="num">Availability %</th><th>Detail</th></tr>')
        foreach ($svc in $sr.Services) {
            $svcName     = $E::HtmlEncode($svc.DisplayName)
            $svcStatus   = Get-StatusBadgeHtml -Status $svc.Status
            $svcPid      = if ($null -ne $svc.PID) { $svc.PID } else { '-' }
            $memMB       = if ($null -ne $svc.MemoryMB) { [math]::Round($svc.MemoryMB, 1) } else { '-' }
            $hasRestarts = ($svc.PSObject.Properties.Name -contains 'Restarts') -and $svc.Restarts
            $restarts    = if ($hasRestarts) { "$($svc.Restarts.count24h)/$($svc.Restarts.count7d)/$($svc.Restarts.count30d)" } elseif ($null -ne $svc.RestartCount) { "$($svc.RestartCount)" } else { '0' }
            $crashes7d   = if (($svc.PSObject.Properties.Name -contains 'Crashes') -and $svc.Crashes) { $svc.Crashes.count7d } else { 0 }
            $mttr        = if ($null -ne $svc.MTTR) { [math]::Round($svc.MTTR, 1) } else { '-' }
            $availability = if ($null -ne $svc.AvailabilityPercent) { [math]::Round($svc.AvailabilityPercent, 2) } else { '-' }
            $detail      = $E::HtmlEncode($(if ($svc.StatusDetail) { $svc.StatusDetail } else { '' }))

            $null = $sb.AppendLine("    <tr><td>$svcName</td><td>$svcStatus</td><td class=`"num`">$svcPid</td><td class=`"num`">$memMB</td><td class=`"num`">$restarts</td><td class=`"num`">$crashes7d</td><td class=`"num`">$mttr</td><td class=`"num`">$availability</td><td>$detail</td></tr>")
        }
        $null = $sb.AppendLine('  </table>')
    }
    $null = $sb.AppendLine('</div>')

    # 8. Certificate Health Table
    $null = $sb.AppendLine('<div class="section">')
    $null = $sb.AppendLine('  <h2>Certificate Health</h2>')
    if ($null -eq $ch -or $null -eq $ch.Certificates -or @($ch.Certificates).Count -eq 0) {
        $null = $sb.AppendLine('  <p>Collector not available or no certificates detected.</p>')
    }
    else {
        $null = $sb.AppendLine('  <table>')
        $null = $sb.AppendLine('    <tr><th>Subject</th><th>Issuer</th><th>Expires</th><th>Days Left</th><th>Status</th></tr>')
        foreach ($cert in $ch.Certificates) {
            $subj      = $E::HtmlEncode($cert.Subject)
            $issuer    = $E::HtmlEncode($cert.Issuer)
            $expires   = $E::HtmlEncode($cert.NotAfter)
            $daysLeft  = if ($null -ne $cert.DaysUntilExpiry) { [int]$cert.DaysUntilExpiry } else { 0 }
            $riskLevel = if ($cert.RiskLevel) { $cert.RiskLevel } else { 'Unknown' }
            $certBadge = Get-StatusBadgeHtml -Status $riskLevel

            # Days-left bar
            $barPct = [math]::Min(100, [math]::Max(0, $daysLeft))
            $barClass = if ($daysLeft -le 7) { 'bar-danger' } elseif ($daysLeft -le 30) { 'bar-warning' } else { 'bar-success' }
            $barHtml = "<div class=`"bar-container`" style=`"width:120px;height:16px;display:inline-block;vertical-align:middle;`"><div class=`"bar $barClass`" style=`"width:$($barPct)%`"></div></div> <span class=`"fs-sm`">$daysLeft d</span>"

            $null = $sb.AppendLine("    <tr><td>$subj</td><td>$issuer</td><td>$expires</td><td>$barHtml</td><td>$certBadge</td></tr>")
        }
        $null = $sb.AppendLine('  </table>')
    }
    $null = $sb.AppendLine('</div>')

    # 9. CPM Health Section
    $null = $sb.AppendLine('<div class="section">')
    $null = $sb.AppendLine('  <h2>CPM Health</h2>')
    if ($null -eq $cpm) {
        $null = $sb.AppendLine('  <p>Collector not available.</p>')
    }
    elseif ($cpm.Status -eq 'NotInstalled') {
        $null = $sb.AppendLine('  <p class="text-muted">CPM is not installed on this host &mdash; collector skipped.</p>')
    }
    else {
        $cpmStatus   = if ($cpm.Status) { $cpm.Status } else { 'Unknown' }
        $cpmErrors   = if ($null -ne $cpm.ErrorCount) { $cpm.ErrorCount } else { 0 }
        $cpmLogPath  = if ($cpm.LogPath) { $E::HtmlEncode($cpm.LogPath) } else { 'N/A' }
        $cpmLookback = if ($null -ne $cpm.LookbackMinutes) { $cpm.LookbackMinutes } else { 60 }

        $null = $sb.AppendLine("  <p>Status: $(Get-StatusBadgeHtml -Status $cpmStatus) | Errors in last ${cpmLookback}m: <strong>$cpmErrors</strong> | Log: $cpmLogPath</p>")
        if (($cpm.PSObject.Properties.Name -contains 'PluginTotal') -and ($cpm.PluginTotal -gt 0 -or $cpm.PluginUnhealthy -gt 0)) {
            $null = $sb.AppendLine("  <p>Plugins: <strong>$($cpm.PluginTotal)</strong> total, <strong>$($cpm.PluginUnhealthy)</strong> unhealthy</p>")
        }

        if ($null -ne $cpm.Errors -and @($cpm.Errors).Count -gt 0) {
            $null = $sb.AppendLine('  <table>')
            $null = $sb.AppendLine('    <tr><th>Timestamp</th><th>Severity</th><th>Code</th><th>Message</th></tr>')
            foreach ($err in $cpm.Errors) {
                $errTs   = $E::HtmlEncode($(if ($err.Timestamp) { $err.Timestamp } else { '' }))
                $errSev  = $E::HtmlEncode($(if ($err.Severity) { $err.Severity } else { 'Error' }))
                $errCode = $E::HtmlEncode($(if ($err.Code) { $err.Code } else { '-' }))
                $errMsg  = $E::HtmlEncode($(if ($err.Message) { $err.Message } else { '' }))
                $null = $sb.AppendLine("    <tr><td>$errTs</td><td>$errSev</td><td>$errCode</td><td>$errMsg</td></tr>")
            }
            $null = $sb.AppendLine('  </table>')
        }
    }
    $null = $sb.AppendLine('</div>')

    # 10. PSM Health Section
    $null = $sb.AppendLine('<div class="section">')
    $null = $sb.AppendLine('  <h2>PSM Health</h2>')
    if ($null -eq $psm) {
        $null = $sb.AppendLine('  <p>Collector not available.</p>')
    }
    elseif ($psm.Status -eq 'NotInstalled') {
        $null = $sb.AppendLine('  <p class="text-muted">PSM is not installed on this host &mdash; collector skipped.</p>')
    }
    else {
        $psmStatus = if ($psm.Status) { $psm.Status } else { 'Unknown' }
        $null = $sb.AppendLine("  <p>Status: $(Get-StatusBadgeHtml -Status $psmStatus)</p>")
        if ($psm.PSObject.Properties.Name -contains 'ConnComponentsTotal') {
            $recBadge = Get-StatusBadgeHtml -Status $(if ($psm.RecordingStatus) { $psm.RecordingStatus } else { 'OK' })
            $null = $sb.AppendLine("  <p>Connection components: <strong>$($psm.ConnComponentsTotal)</strong> total, <strong>$($psm.ConnComponentsInvalid)</strong> invalid | Recordings: $recBadge $($psm.RecordingFreeGB) GB free, $($psm.RecordingPendingCount) pending</p>")
        }

        # Service status
        if ($null -ne $psm.ServiceStatus) {
            $psmSvcName   = $E::HtmlEncode($(if ($psm.ServiceStatus.DisplayName) { $psm.ServiceStatus.DisplayName } else { $psm.ServiceStatus.Name }))
            $psmSvcStatus = if ($psm.ServiceStatus.Status) { $psm.ServiceStatus.Status } else { 'Unknown' }
            $null = $sb.AppendLine("  <p>Service: <strong>$psmSvcName</strong> - $(Get-StatusBadgeHtml -Status $psmSvcStatus)</p>")
        }

        # Shadow user errors
        $shadowCount = if ($null -ne $psm.ShadowUserErrors) { @($psm.ShadowUserErrors).Count } else { 0 }
        $sysErrCount = if ($null -ne $psm.SystemErrorCount) { $psm.SystemErrorCount } else { 0 }
        $null = $sb.AppendLine("  <p>System Errors: <strong>$sysErrCount</strong> | Shadow User Errors: <strong>$shadowCount</strong></p>")

        # Error categories summary
        if ($null -ne $psm.ErrorCategories) {
            $cats = $psm.ErrorCategories
            $null = $sb.AppendLine('  <h3>Error Categories</h3>')
            $null = $sb.AppendLine('  <div class="card-grid">')
            foreach ($catProp in ($cats.PSObject.Properties)) {
                $catName  = $E::HtmlEncode($catProp.Name)
                $catCount = $catProp.Value
                $catClass = if ($catCount -gt 0) { 'warning' } else { 'success' }
                $null = $sb.AppendLine("    <div class=`"card $catClass`"><div class=`"value`">$catCount</div><div class=`"label`">$catName</div></div>")
            }
            $null = $sb.AppendLine('  </div>')
        }

        # Categorized error table
        if ($null -ne $psm.CategorizedErrors -and @($psm.CategorizedErrors).Count -gt 0) {
            $null = $sb.AppendLine('  <h3>Recent Errors</h3>')
            $null = $sb.AppendLine('  <table>')
            $null = $sb.AppendLine('    <tr><th>Timestamp</th><th>Severity</th><th>Category</th><th>Message</th></tr>')
            foreach ($err in $psm.CategorizedErrors) {
                $errTs   = $E::HtmlEncode($(if ($err.Timestamp) { $err.Timestamp } else { '' }))
                $errSev  = $E::HtmlEncode($(if ($err.Severity) { $err.Severity } else { 'Error' }))
                $errCat  = $E::HtmlEncode($(if ($err.Category) { $err.Category } else { 'Unknown' }))
                $errMsg  = $E::HtmlEncode($(if ($err.Message) { $err.Message } else { '' }))
                $null = $sb.AppendLine("    <tr><td>$errTs</td><td>$errSev</td><td>$errCat</td><td>$errMsg</td></tr>")
            }
            $null = $sb.AppendLine('  </table>')
        }
    }
    $null = $sb.AppendLine('</div>')

    # 11. Connectivity Matrix
    $null = $sb.AppendLine('<div class="section">')
    $null = $sb.AppendLine('  <h2>Connectivity Matrix</h2>')
    if ($null -eq $conn -or @($conn).Count -eq 0) {
        $null = $sb.AppendLine('  <p>Collector not available or no connectivity targets configured.</p>')
    }
    else {
        $null = $sb.AppendLine('  <table>')
        $null = $sb.AppendLine('    <tr><th>Target</th><th class="num">Port</th><th>Reachable</th><th class="num">Latency (ms)</th></tr>')
        foreach ($c in $conn) {
            $target    = $E::HtmlEncode($c.Target)
            $port      = $c.Port
            $reachBadge = Get-StatusBadgeHtml -Status $(if ($c.Reachable) { 'Connected' } else { 'Unreachable' })
            $latency   = if ($null -ne $c.LatencyMs) { $c.LatencyMs } else { '-' }

            $null = $sb.AppendLine("    <tr><td>$target</td><td class=`"num`">$port</td><td>$reachBadge</td><td class=`"num`">$latency</td></tr>")
        }
        $null = $sb.AppendLine('  </table>')
    }
    $null = $sb.AppendLine('</div>')

    # 12. WebDriver Compatibility
    $null = $sb.AppendLine('<div class="section">')
    $null = $sb.AppendLine('  <h2>WebDriver Compatibility</h2>')
    if ($null -eq $wd -or @($wd).Count -eq 0) {
        $null = $sb.AppendLine('  <p>Collector not available or no browsers detected.</p>')
    }
    else {
        $null = $sb.AppendLine('  <table>')
        $null = $sb.AppendLine('    <tr><th>Browser</th><th>Version</th><th>Driver Version</th><th>Compatible</th><th>Hash Match</th></tr>')
        foreach ($w in $wd) {
            $browser    = $E::HtmlEncode($w.Browser)
            $bVersion   = $E::HtmlEncode($(if ($w.BrowserVersion) { $w.BrowserVersion } else { 'N/A' }))
            $dVersion   = $E::HtmlEncode($(if ($w.DriverVersion) { $w.DriverVersion } else { 'N/A' }))
            $compatBadge = Get-StatusBadgeHtml -Status $(if ($w.Compatible) { 'Compatible' } else { 'Incompatible' })
            $hashVal     = if ($null -ne $w.HashMatch) { if ($w.HashMatch) { 'Yes' } else { 'No' } } else { 'N/A' }
            $hashBadge   = Get-StatusBadgeHtml -Status $hashVal

            $null = $sb.AppendLine("    <tr><td>$browser</td><td>$bVersion</td><td>$dVersion</td><td>$compatBadge</td><td>$hashBadge</td></tr>")
        }
        $null = $sb.AppendLine('  </table>')
    }
    $null = $sb.AppendLine('</div>')

    # 12b. PVWA / IIS Health
    $null = $sb.AppendLine('<div class="section">')
    $null = $sb.AppendLine('  <h2>PVWA / IIS Health</h2>')
    if ($null -eq $pvwa) {
        $null = $sb.AppendLine('  <p>Collector not available.</p>')
    }
    elseif ($pvwa.Status -eq 'NotInstalled') {
        $null = $sb.AppendLine('  <p class="text-muted">PVWA is not installed on this host &mdash; collector skipped.</p>')
    }
    else {
        $pvwaBadge    = Get-StatusBadgeHtml -Status $pvwa.Status
        $fallbackNote = if ($pvwa.FallbackMode) { ' (basic checks &mdash; WebAdministration module unavailable)' } else { '' }
        $null = $sb.AppendLine("  <p>Status: $pvwaBadge <span class=`"text-muted fs-sm`">$fallbackNote</span></p>")
        $null = $sb.AppendLine('  <table>')
        $null = $sb.AppendLine('    <tr><th>IIS Service</th><th>App Pool</th><th class="num">Workers</th><th class="num">Memory MB</th><th class="num">Recycles 24h</th><th>Binding</th><th class="num">Log MB</th></tr>')
        $null = $sb.AppendLine("    <tr><td>$($E::HtmlEncode($pvwa.IISServiceStatus))</td><td>$($E::HtmlEncode($pvwa.AppPoolStatus))</td><td class=`"num`">$($pvwa.WorkerProcessCount)</td><td class=`"num`">$($pvwa.MemoryUsageMB)</td><td class=`"num`">$($pvwa.RecentRecycleCount)</td><td>$($E::HtmlEncode($pvwa.BindingStatus))</td><td class=`"num`">$($pvwa.LogFileSizeMB)</td></tr>")
        $null = $sb.AppendLine('  </table>')
    }
    $null = $sb.AppendLine('</div>')

    # 12c. CyberArk Log Scan
    $null = $sb.AppendLine('<div class="section">')
    $null = $sb.AppendLine('  <h2>CyberArk Log Scan</h2>')
    if ($null -eq $logscan) {
        $null = $sb.AppendLine('  <p>Collector not available.</p>')
    }
    elseif ($logscan.Status -eq 'NotInstalled') {
        $null = $sb.AppendLine('  <p class="text-muted">No CyberArk logs found on this host &mdash; scanner skipped.</p>')
    }
    else {
        $null = $sb.AppendLine("  <p>Status: $(Get-StatusBadgeHtml -Status $logscan.Status) | Errors: <strong>$($logscan.TotalErrors)</strong> | Warnings: <strong>$($logscan.TotalWarnings)</strong> <span class=`"text-muted fs-sm`">(recent tail)</span></p>")
        $null = $sb.AppendLine('  <table>')
        $null = $sb.AppendLine('    <tr><th>Source</th><th>Format</th><th>Present</th><th class="num">Errors</th><th class="num">Warnings</th><th>Path</th></tr>')
        foreach ($s in @($logscan.Sources)) {
            $foundTxt = if ($s.Found) { 'Yes' } else { 'no' }
            $sPath    = $E::HtmlEncode($(if ($s.Path) { $s.Path } else { '-' }))
            $null = $sb.AppendLine("    <tr><td>$($E::HtmlEncode($s.Name))</td><td>$($E::HtmlEncode($s.Format))</td><td>$foundTxt</td><td class=`"num`">$($s.ErrorCount)</td><td class=`"num`">$($s.WarnCount)</td><td>$sPath</td></tr>")
        }
        $null = $sb.AppendLine('  </table>')
    }
    $null = $sb.AppendLine('</div>')

    # 13. Capacity Forecast
    if ($null -ne $Forecasts -and @($Forecasts).Count -gt 0) {
        $null = $sb.AppendLine('<div class="section">')
        $null = $sb.AppendLine('  <h2>Capacity Forecast</h2>')
        $null = $sb.AppendLine('  <table>')
        $null = $sb.AppendLine('    <tr><th>Metric</th><th class="num">Current</th><th class="num">Threshold</th><th class="num">Growth/Day</th><th class="num">Days Until Limit</th><th>Trend</th><th>Recommendation</th></tr>')
        foreach ($fc in $Forecasts) {
            $fcName      = $E::HtmlEncode($fc.MetricName)
            $fcCurrent   = [math]::Round($fc.CurrentValue, 1)
            $fcThreshold = [math]::Round($fc.Threshold, 1)
            $fcGrowth    = [math]::Round($fc.GrowthRateDaily, 4)
            $fcDays      = if ($fc.DaysUntilLimit -eq [int]::MaxValue) { 'N/A' } else { $fc.DaysUntilLimit }

            $trendClass = switch ($fc.TrendDirection) {
                'Increasing' { 'status-warning' }
                'Decreasing' { 'status-ok' }
                default      { 'status-muted' }
            }
            $trendText  = $E::HtmlEncode($fc.TrendDirection)

            # Recommendation as rec-box
            $recText  = $E::HtmlEncode($fc.Recommendation)
            $recClass = if ($fc.Recommendation -like 'CRITICAL*') { 'critical' }
                        elseif ($fc.Recommendation -like 'URGENT*') { 'critical' }
                        elseif ($fc.Recommendation -like 'WARNING*') { 'warning' }
                        elseif ($fc.Recommendation -like 'INFO*') { 'info' }
                        else { 'healthy' }

            $null = $sb.AppendLine("    <tr><td>$fcName</td><td class=`"num`">$fcCurrent</td><td class=`"num`">$fcThreshold</td><td class=`"num`">$fcGrowth</td><td class=`"num`">$fcDays</td><td><span class=`"$trendClass`">$trendText</span></td><td><div class=`"rec-box $recClass`"><p>$recText</p></div></td></tr>")
        }
        $null = $sb.AppendLine('  </table>')
        $null = $sb.AppendLine('</div>')
    }

    # 14. Requirements Compliance Table
    if ($null -ne $RequirementEvals -and @($RequirementEvals).Count -gt 0) {
        $null = $sb.AppendLine('<div class="section">')
        $null = $sb.AppendLine('  <h2>Requirements Compliance</h2>')
        $null = $sb.AppendLine('  <table>')
        $null = $sb.AppendLine('    <tr><th>ID</th><th>Metric</th><th>Status</th><th class="num">Current</th><th class="num">Threshold</th><th>Direction</th></tr>')
        foreach ($reqEval in $RequirementEvals) {
            $reqIdStr    = $E::HtmlEncode($reqEval.RequirementId)
            $reqMetric   = $E::HtmlEncode($reqEval.MetricPath)
            $reqBadge    = Get-StatusBadgeHtml -Status $reqEval.Status
            $reqCurVal   = if ($null -ne $reqEval.CurrentValue) { $E::HtmlEncode("$($reqEval.CurrentValue)") } else { 'N/A' }
            # Show the configured limit for every row (including OK ones) so the
            # reader can see headroom -- not just the threshold that was crossed.
            $reqThrVal   = if ($null -ne $reqEval.ConfiguredThreshold -and "$($reqEval.ConfiguredThreshold)".Trim() -ne '') { $E::HtmlEncode("$($reqEval.ConfiguredThreshold)") }
                           elseif ($null -ne $reqEval.Threshold) { $E::HtmlEncode("$($reqEval.Threshold)") }
                           else { '--' }
            $reqDir      = $E::HtmlEncode($reqEval.Direction)
            $null = $sb.AppendLine("    <tr><td>$reqIdStr</td><td>$reqMetric</td><td>$reqBadge</td><td class=`"num`">$reqCurVal</td><td class=`"num`">$reqThrVal</td><td>$reqDir</td></tr>")
        }
        $null = $sb.AppendLine('  </table>')
        $null = $sb.AppendLine('</div>')
    }

    # 15. Trend Summary (7-day sparklines from PlatformState)
    if ($null -ne $PlatformState -and $null -ne $PlatformState['dailySummaries'] -and $PlatformState.dailySummaries.Count -gt 0) {
        $trendMetricsReport = @(
            @{ Key = 'cpuAverage'; Label = 'CPU Average %'; WarnTh = 80; CritTh = 95; HigherBad = $true }
            @{ Key = 'cpuPeak';    Label = 'CPU Peak %';    WarnTh = 80; CritTh = 95; HigherBad = $true }
            @{ Key = 'memoryUsed'; Label = 'Memory Used %'; WarnTh = 85; CritTh = 95; HigherBad = $true }
            @{ Key = 'diskC';      Label = 'Disk C: Used %'; WarnTh = 80; CritTh = 95; HigherBad = $true }
        )
        $hasTrend = $false
        foreach ($tmr in $trendMetricsReport) {
            $tData = Get-TrendData -State $PlatformState -MetricKey $tmr.Key -DayRange 7
            if ($null -ne $tData -and @($tData).Count -gt 0) { $hasTrend = $true; break }
        }
        if ($hasTrend) {
            $null = $sb.AppendLine('<div class="section">')
            $null = $sb.AppendLine('  <h2>7-Day Trend Summary</h2>')
            $null = $sb.AppendLine('  <table>')
            $null = $sb.AppendLine('    <tr><th>Metric</th><th>Sparkline</th><th class="num">Min</th><th class="num">Max</th><th class="num">Avg</th></tr>')
            foreach ($tmr in $trendMetricsReport) {
                $tData = Get-TrendData -State $PlatformState -MetricKey $tmr.Key -DayRange 7
                if ($null -ne $tData -and @($tData).Count -gt 0) {
                    $tVals = @($tData | ForEach-Object { $_.Avg })
                    $sparkHtml = Get-SparklineHtml -Values $tVals -WarningThreshold $tmr.WarnTh -CriticalThreshold $tmr.CritTh -HigherIsBad $tmr.HigherBad
                    $tMin = [math]::Round(($tData | ForEach-Object { $_.Min } | Measure-Object -Minimum).Minimum, 1)
                    $tMax = [math]::Round(($tData | ForEach-Object { $_.Max } | Measure-Object -Maximum).Maximum, 1)
                    $tAvg = [math]::Round(($tData | ForEach-Object { $_.Avg } | Measure-Object -Average).Average, 1)
                    $null = $sb.AppendLine("    <tr><td>$($E::HtmlEncode($tmr.Label))</td><td>$sparkHtml</td><td class=`"num`">$tMin</td><td class=`"num`">$tMax</td><td class=`"num`">$tAvg</td></tr>")
                } else {
                    $null = $sb.AppendLine("    <tr><td>$($E::HtmlEncode($tmr.Label))</td><td>--</td><td class=`"num`">--</td><td class=`"num`">--</td><td class=`"num`">--</td></tr>")
                }
            }
            $null = $sb.AppendLine('  </table>')
            $null = $sb.AppendLine('</div>')
        }
    }

    # 16. Action Items
    $null = $sb.AppendLine('<div class="section">')
    $null = $sb.AppendLine('  <h2>Action Items</h2>')
    if ($alerts.Count -eq 0) {
        $null = $sb.AppendLine('  <p>No action items. All systems operating within normal parameters.</p>')
    }
    else {
        # Sort: Critical first, then Warning
        $sortedAlerts = $alerts | Sort-Object @{ Expression = { if ($_.severity -eq 'Critical') { 0 } else { 1 } } }

        $null = $sb.AppendLine('  <div class="action-items">')
        foreach ($alert in $sortedAlerts) {
            $sevLower   = $alert.severity.ToLower()
            $sevBadge   = Get-StatusBadgeHtml -Status $alert.severity
            $alertMsg   = $E::HtmlEncode($alert.message)
            $alertSrc   = $E::HtmlEncode($(if ($alert.source) { $alert.source } else { '' }))
            $alertMet   = $E::HtmlEncode($(if ($alert.metricName) { $alert.metricName } else { '' }))

            $null = $sb.AppendLine("    <div class=`"action-item $sevLower`">")
            $null = $sb.AppendLine("      <div class=`"severity-badge`">$sevBadge</div>")
            $null = $sb.AppendLine('      <div class="action-item-text">')
            $null = $sb.AppendLine("        <div class=`"description`">$alertMsg</div>")
            $null = $sb.AppendLine("        <div class=`"recommendation`">Source: $alertSrc | Metric: $alertMet</div>")
            $null = $sb.AppendLine('      </div>')
            $null = $sb.AppendLine('    </div>')
        }
        $null = $sb.AppendLine('  </div>')
    }
    $null = $sb.AppendLine('</div>')

    # 15. Footer
    $correlId = if ($script:CorrelationID) { $E::HtmlEncode($script:CorrelationID) } else { 'N/A' }
    $null = $sb.AppendLine("<div class=`"footer`">Generated by $($E::HtmlEncode($script:ToolName)) v$($script:ToolVersion) | $timestamp | Correlation: $correlId</div>")

    $null = $sb.AppendLine('</div>') # close container
    $null = $sb.AppendLine('</body>')
    $null = $sb.AppendLine('</html>')

    return $sb.ToString()
}

#endregion

#region Console Dashboard

function Get-DashboardStatusColor {
    <#
    .SYNOPSIS
        Determine console color based on metric value and thresholds.
    .PARAMETER MetricName
        The metric type: CPU, Memory, or Sessions.
    .PARAMETER Value
        The numeric value to evaluate.
    .OUTPUTS
        [string] Console color name: Red, Yellow, or Green.
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [Parameter(Mandatory)]
        [ValidateSet('CPU', 'Memory', 'Sessions')]
        [string]$MetricName,

        [Parameter(Mandatory)]
        [double]$Value
    )

    $cfg = $script:Config
    switch ($MetricName) {
        'CPU' {
            # Higher is worse
            if ($Value -ge $cfg.thresholds.cpuCriticalPercent) { return 'Red' }
            if ($Value -ge $cfg.thresholds.cpuWarningPercent)  { return 'Yellow' }
            return 'Green'
        }
        'Memory' {
            # Value is MB available; lower is worse
            if ($Value -le 512)  { return 'Red' }
            if ($Value -le 1024) { return 'Yellow' }
            return 'Green'
        }
        'Sessions' {
            # Higher is worse
            if ($Value -ge 100) { return 'Red' }
            if ($Value -ge 75)  { return 'Yellow' }
            return 'Green'
        }
    }
    return 'Green'
}

function Write-DashboardHeader {
    <#
    .SYNOPSIS
        Render the dashboard header with timestamp.
    #>
    [CmdletBinding()]
    param(
        [Parameter()]
        [datetime]$Timestamp = (Get-Date),

        [Parameter()]
        [int]$Width = 80
    )

    $divider = '=' * $Width
    $formattedTime = $Timestamp.ToString('yyyy-MM-dd HH:mm:ss')

    Write-Host $divider -ForegroundColor Cyan
    $leftText  = '  CYBERARK PLATFORM MONITOR DASHBOARD'
    $rightText = "Last Update: $formattedTime"
    $spaces = $Width - $leftText.Length - $rightText.Length - 2
    if ($spaces -lt 1) { $spaces = 1 }

    Write-Host $leftText -NoNewline -ForegroundColor Cyan
    Write-Host (' ' * $spaces) -NoNewline
    Write-Host $rightText -ForegroundColor White
    Write-Host $divider -ForegroundColor Cyan
    Write-Host ''
}

function Write-DashboardTable {
    <#
    .SYNOPSIS
        Render the server status table from collection results.
        Maps fields directly from Invoke-MetricsCollection output.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [hashtable]$CollectionResults,

        [Parameter()]
        [int]$Width = 80
    )

    $sh   = $CollectionResults.SystemHealth
    $sr   = $CollectionResults.ServiceStatus
    $sc   = $CollectionResults.ServerCapacity
    $localAlerts = @($CollectionResults.Alerts)

    # --- Session Summary from ServerCapacity.NetworkConnections ---
    Write-Host '  SESSION SUMMARY' -ForegroundColor White
    Write-Host '  ---------------' -ForegroundColor Gray

    if ($null -ne $sc -and $null -ne $sc.NetworkConnections) {
        $connections = @($sc.NetworkConnections)
        $rdpCount   = 0
        $totalCount  = 0
        foreach ($nc in $connections) {
            $totalCount += $nc.Count
            if ($nc.Port -eq 3389) { $rdpCount += $nc.Count }
        }
        $summaryLine = "  Vault Connections: $(($connections | Where-Object { $_.Port -eq 1858 } | ForEach-Object { $_.Count }) -join ',')    RDP: $rdpCount    HTTPS: $(($connections | Where-Object { $_.Port -eq 443 } | ForEach-Object { $_.Count }) -join ',')    Total: $totalCount"
        Write-Host $summaryLine -ForegroundColor White
    }
    else {
        Write-Host '  No capacity data available' -ForegroundColor Yellow
    }
    Write-Host ''

    # --- Server Status ---
    Write-Host '  SERVER STATUS' -ForegroundColor White
    Write-Host '  -------------' -ForegroundColor Gray

    $headerFormat = '  {0,-20} {1,-8} {2,-12} {3,-11} {4,-10}'
    Write-Host ($headerFormat -f 'Metric', 'Value', 'Threshold', 'Status', 'Color') -ForegroundColor Gray
    Write-Host ($headerFormat -f ('-' * 20), ('-' * 8), ('-' * 12), ('-' * 11), ('-' * 10)) -ForegroundColor Gray

    # CPU
    if ($null -ne $sh -and $null -ne $sh.CPU) {
        $cpuVal   = [math]::Round($sh.CPU.Average, 1)
        $cpuColor = Get-DashboardStatusColor -MetricName 'CPU' -Value $cpuVal
        $cpuThresh = "$($script:Config.thresholds.cpuWarningPercent)/$($script:Config.thresholds.cpuCriticalPercent)%"
        Write-Host '  ' -NoNewline
        Write-Host ('{0,-20}' -f 'CPU Average') -NoNewline -ForegroundColor White
        Write-Host ('{0,-8}' -f "$cpuVal%") -NoNewline -ForegroundColor $cpuColor
        Write-Host ('{0,-12}' -f $cpuThresh) -NoNewline -ForegroundColor Gray
        Write-Host ('{0,-11}' -f $sh.CPU.Status) -NoNewline -ForegroundColor $cpuColor
        Write-Host "[$($cpuColor.ToUpper())]" -ForegroundColor $cpuColor
    }

    # Memory
    if ($null -ne $sh -and $null -ne $sh.Memory) {
        $memUsed  = [math]::Round($sh.Memory.UsedPercent, 1)
        $memAvailMB = [math]::Round($sh.Memory.AvailableGB * 1024, 0)
        $memColor = Get-DashboardStatusColor -MetricName 'Memory' -Value $memAvailMB
        $memThresh = "$($script:Config.thresholds.memoryWarningPercent)/$($script:Config.thresholds.memoryCriticalPercent)%"
        Write-Host '  ' -NoNewline
        Write-Host ('{0,-20}' -f 'Memory Used') -NoNewline -ForegroundColor White
        Write-Host ('{0,-8}' -f "$memUsed%") -NoNewline -ForegroundColor $memColor
        Write-Host ('{0,-12}' -f $memThresh) -NoNewline -ForegroundColor Gray
        Write-Host ('{0,-11}' -f $sh.Memory.Status) -NoNewline -ForegroundColor $memColor
        Write-Host "[$($memColor.ToUpper())]" -ForegroundColor $memColor
    }

    # Disks
    if ($null -ne $sh -and $null -ne $sh.Disks) {
        foreach ($disk in $sh.Disks) {
            $dPct   = [math]::Round($disk.UsedPercent, 1)
            $dColor = if ($dPct -ge $script:Config.thresholds.diskCriticalPercent) { 'Red' } elseif ($dPct -ge $script:Config.thresholds.diskWarningPercent) { 'Yellow' } else { 'Green' }
            $dThresh = "$($script:Config.thresholds.diskWarningPercent)/$($script:Config.thresholds.diskCriticalPercent)%"
            Write-Host '  ' -NoNewline
            Write-Host ('{0,-20}' -f "Disk $($disk.DriveLetter)") -NoNewline -ForegroundColor White
            Write-Host ('{0,-8}' -f "$dPct%") -NoNewline -ForegroundColor $dColor
            Write-Host ('{0,-12}' -f $dThresh) -NoNewline -ForegroundColor Gray
            Write-Host ('{0,-11}' -f $disk.Status) -NoNewline -ForegroundColor $dColor
            Write-Host "[$($dColor.ToUpper())]" -ForegroundColor $dColor
        }
    }

    # Services summary
    if ($null -ne $sr) {
        $svcColor = if ($sr.StoppedServices -gt 0) { 'Red' } elseif ($sr.DegradedServices -gt 0) { 'Yellow' } else { 'Green' }
        Write-Host '  ' -NoNewline
        Write-Host ('{0,-20}' -f 'Services') -NoNewline -ForegroundColor White
        Write-Host ('{0,-8}' -f "$($sr.HealthyServices)/$($sr.TotalServices)") -NoNewline -ForegroundColor $svcColor
        Write-Host ('{0,-12}' -f '-') -NoNewline -ForegroundColor Gray
        Write-Host ('{0,-11}' -f $sr.Status) -NoNewline -ForegroundColor $svcColor
        Write-Host "[$($svcColor.ToUpper())]" -ForegroundColor $svcColor
    }

    Write-Host ''

    # Alerts
    if ($localAlerts.Count -gt 0) {
        Write-Host '  ALERTS:' -ForegroundColor Red
        foreach ($a in $localAlerts) {
            $aColor = if ($a.severity -eq 'Critical') { 'Red' } else { 'Yellow' }
            $aText  = "[$($a.severity.ToUpper())] $($a.message)"
            Write-Host "  - $aText" -ForegroundColor $aColor
        }
        Write-Host ''
    }
}

function Show-Dashboard {
    <#
    .SYNOPSIS
        Main dashboard loop with refresh and user interaction.
    .DESCRIPTION
        Displays a real-time monitoring dashboard that refreshes at a configurable
        interval. Uses Clear-Host + Write-Host (Simple mode).
    .PARAMETER RefreshSeconds
        Seconds between refreshes. Default: 5.
    .PARAMETER SimulationMode
        Use mock data instead of real collectors.
    .PARAMETER MaxIterations
        Max refresh cycles. 0 = infinite (exit with Q key). Used for testing.
    #>
    [CmdletBinding()]
    param(
        [Parameter()]
        [int]$RefreshSeconds = 5,

        [Parameter()]
        [switch]$SimulationMode,

        [Parameter()]
        [int]$MaxIterations = 0
    )

    $stopRequested = $false
    $iteration     = 0

    try {
        while (-not $stopRequested) {
            try {
                # Clear-Host throws when the console is redirected/non-interactive;
                # isolate it so the dashboard still renders there.
                try { Clear-Host } catch { }

                # Get data
                if ($SimulationMode) {
                    # Build a collection-results-shaped hashtable from mock data
                    $mockSh   = Get-MockData -DataType 'SystemHealth'
                    $mockSr   = Get-MockData -DataType 'ServiceResiliency'
                    $mockSc   = Get-MockData -DataType 'ServerCapacity'
                    $mockConn = Get-MockData -DataType 'Connectivity'

                    $collectionResults = @{
                        CollectionMeta  = [ordered]@{ recordType = 'CollectionMeta'; timestamp = (Get-Date).ToUniversalTime().ToString('o'); serverName = $env:COMPUTERNAME; mode = 'Interactive'; overallStatus = 'OK'; alertCount = 0; errorCount = 0 }
                        SystemHealth    = $mockSh
                        ServiceStatus   = $mockSr
                        ServerCapacity  = $mockSc
                        Connectivity    = $mockConn
                        Alerts          = [System.Collections.ArrayList]::new()
                        Errors          = [System.Collections.ArrayList]::new()
                    }
                }
                else {
                    $collectionResults = Invoke-MetricsCollection
                }

                # Render
                Write-DashboardHeader -Timestamp (Get-Date) -Width 80
                Write-DashboardTable -CollectionResults $collectionResults -Width 80

                # Footer
                $divider = '=' * 80
                Write-Host "  Press 'Q' to quit | Refresh in ${RefreshSeconds}s" -ForegroundColor Gray
                Write-Host $divider -ForegroundColor Cyan
            }
            catch {
                Write-Host "Error rendering dashboard: $($_.Exception.Message)" -ForegroundColor Red
            }

            $iteration++

            # Check for max iterations (testing mode)
            if ($MaxIterations -gt 0 -and $iteration -ge $MaxIterations) {
                $stopRequested = $true
                break
            }

            # Wait for refresh interval, checking for Q key
            $waitStart = Get-Date
            while (((Get-Date) - $waitStart).TotalSeconds -lt $RefreshSeconds) {
                try {
                    if ([Console]::KeyAvailable) {
                        $key = [Console]::ReadKey($true)
                        if ($key.KeyChar -eq 'q' -or $key.KeyChar -eq 'Q') {
                            $stopRequested = $true
                            break
                        }
                    }
                }
                catch {
                    # [Console]::KeyAvailable throws in non-interactive consoles; skip
                }
                Start-Sleep -Milliseconds 100
            }
        }
    }
    catch {
        if ($_.Exception.Message -notlike '*pipeline*') {
            Write-Host "Dashboard interrupted: $($_.Exception.Message)" -ForegroundColor Red
        }
    }
    finally {
        Write-Host ''
        Write-Host 'Dashboard stopped.' -ForegroundColor Cyan
    }
}

#endregion

#region Scheduled Task Helper

function Show-ScheduledTaskHelp {
    <#
    .SYNOPSIS
        Outputs example commands for registering the monitor as a Windows scheduled task.
        Shows 3-tier task registration examples.
    #>
    [CmdletBinding()]
    param()

    $scriptPath = $PSCommandPath
    if (-not $scriptPath) { $scriptPath = '<path-to-script>\Invoke-CAPlatformMonitor.ps1' }

    Write-Host ''
    Write-Host '=== Scheduled Task Registration ===' -ForegroundColor Cyan
    Write-Host ''
    Write-Host '--- Tier-Based Tasks (Recommended) ---' -ForegroundColor White
    Write-Host ''
    Write-Host 'Three-tier monitoring with different collection frequencies:' -ForegroundColor Gray
    Write-Host ''
    Write-Host "  Hot  (1 min):  -Scheduled -Tier Hot   [CPU, Memory, Disk, Connections]" -ForegroundColor Gray
    Write-Host "  Warm (5 min):  -Scheduled -Tier Warm  [Services, Connectivity]" -ForegroundColor Gray
    Write-Host "  Cool (15 min): -Scheduled -Tier Cool  [CPM, PSM, Certs, WebDriver]" -ForegroundColor Gray
    Write-Host ''
    Write-Host 'Use -RegisterTasks to auto-create all three, or manually:' -ForegroundColor Gray
    Write-Host ''

    foreach ($tierInfo in @(
        @{ Name = 'Hot';  Interval = 1;  Desc = 'CPU/Memory/Disk' }
        @{ Name = 'Warm'; Interval = 5;  Desc = 'Services/Connectivity' }
        @{ Name = 'Cool'; Interval = 15; Desc = 'CPM/PSM/Certs/WebDriver' }
    )) {
        Write-Host "  # CyberArk Monitor - $($tierInfo.Name) (every $($tierInfo.Interval)m: $($tierInfo.Desc))" -ForegroundColor Yellow
        Write-Host "  `$action   = New-ScheduledTaskAction -Execute 'powershell.exe' ``" -ForegroundColor Gray
        Write-Host "                -Argument '-NoProfile -ExecutionPolicy Bypass -File `"$scriptPath`" -Scheduled -Tier $($tierInfo.Name)'" -ForegroundColor Gray
        Write-Host "  `$trigger  = New-ScheduledTaskTrigger -Once -At (Get-Date) ``" -ForegroundColor Gray
        Write-Host "                -RepetitionInterval (New-TimeSpan -Minutes $($tierInfo.Interval))" -ForegroundColor Gray
        Write-Host "  `$principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest" -ForegroundColor Gray
        Write-Host "  `$settings  = New-ScheduledTaskSettingsSet -StartWhenAvailable -DontStopOnIdleEnd -AllowStartIfOnBatteries" -ForegroundColor Gray
        Write-Host "  Register-ScheduledTask -TaskName 'CyberArk Monitor - $($tierInfo.Name)' ``" -ForegroundColor Gray
        Write-Host "      -Action `$action -Trigger `$trigger -Principal `$principal -Settings `$settings ``" -ForegroundColor Gray
        Write-Host "      -Description 'CyberArk Platform Monitor - $($tierInfo.Name) tier ($($tierInfo.Desc))'" -ForegroundColor Gray
        Write-Host ''
    }

    Write-Host '--- Legacy Single-Task Mode ---' -ForegroundColor White
    Write-Host ''
    Write-Host "  `$action  = New-ScheduledTaskAction -Execute 'powershell.exe' ``" -ForegroundColor Gray
    Write-Host "               -Argument '-NoProfile -ExecutionPolicy Bypass -File `"$scriptPath`" -Scheduled'" -ForegroundColor Gray
    Write-Host "  `$trigger = New-ScheduledTaskTrigger -Daily -At '06:00AM'" -ForegroundColor Gray
    Write-Host "  Register-ScheduledTask -TaskName 'CyberArk Platform Monitor' ``" -ForegroundColor Gray
    Write-Host "      -Action `$action -Trigger `$trigger ``" -ForegroundColor Gray
    Write-Host "      -Principal (New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest) ``" -ForegroundColor Gray
    Write-Host "      -Settings (New-ScheduledTaskSettingsSet -StartWhenAvailable -DontStopOnIdleEnd)" -ForegroundColor Gray
    Write-Host ''

    Write-Host 'Quick commands:' -ForegroundColor Yellow
    Write-Host "  -RegisterTasks     Create all 3 tier-based tasks automatically" -ForegroundColor Gray
    Write-Host "  -UnregisterTasks   Remove all 3 tier-based tasks" -ForegroundColor Gray
    Write-Host "  -TestAlert         Send a test email and exit" -ForegroundColor Gray
    Write-Host "  -DigestNow         Force daily digest email now" -ForegroundColor Gray
    Write-Host ''
    Write-Host 'Notes:' -ForegroundColor Yellow
    Write-Host '  - Exit code 0 = OK, 1 = Warnings, 2 = Critical' -ForegroundColor Gray
    Write-Host '  - Use -MetricsPath to control where JSONL files are written' -ForegroundColor Gray
    Write-Host '  - Use -LogPath to redirect log output' -ForegroundColor Gray
    Write-Host '  - Use -NoAlerts to suppress SMTP for a specific run' -ForegroundColor Gray
    Write-Host '  - JSONL files auto-rotate based on -RetentionDays (default: 30)' -ForegroundColor Gray
    Write-Host ''
}

function Register-MonitorTasks {
    <#
    .SYNOPSIS
        Registers ONE Windows scheduled task that runs a full -Scheduled collection
        (all tests) every scheduling.intervalMinutes (or -IntervalMinutes), repeating
        indefinitely as SYSTEM. Embeds the config/paths used at registration so the
        task runs exactly as invoked. Requires elevation.
    #>
    [CmdletBinding()]
    param([hashtable]$BoundParameters = @{})

    $scriptPath = $PSCommandPath
    if (-not $scriptPath) {
        Write-Log -Message 'Cannot determine script path for task registration' -Level Error -Color Red
        return
    }

    # Interval + task name: -IntervalMinutes > config.scheduling.* > defaults.
    $interval = 5
    $taskName = 'CyberArk Platform Monitor'
    $sch = $script:Config.scheduling
    if ($null -ne $sch) {
        $ci = if ($sch -is [hashtable]) { $sch['intervalMinutes'] } else { $sch.intervalMinutes }
        if ($null -ne $ci -and [int]$ci -gt 0) { $interval = [int]$ci }
        $tn = if ($sch -is [hashtable]) { $sch['taskName'] } else { $sch.taskName }
        if (-not [string]::IsNullOrWhiteSpace($tn)) { $taskName = $tn }
    }
    if ($BoundParameters.ContainsKey('IntervalMinutes') -and $IntervalMinutes -gt 0) { $interval = $IntervalMinutes }

    # Rebuild THIS invocation as the task action (absolute paths) so the task runs
    # the same config/paths from SYSTEM (whose cwd is C:\Windows\System32).
    $argParts = @('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$scriptPath`"",'-Scheduled')
    foreach ($p in @('ConfigPath','MetricsPath','LogPath','StatePath','RequirementsPath')) {
        if ($BoundParameters.ContainsKey($p)) {
            $val = Get-Variable -Name $p -ValueOnly -ErrorAction SilentlyContinue
            if (-not [string]::IsNullOrWhiteSpace($val)) {
                try { $val = [System.IO.Path]::GetFullPath($val) } catch { }
                $argParts += "-$p"; $argParts += "`"$val`""
            }
        }
    }
    foreach ($p in @('VaultAddress','PSMServers','FarmPeers','NoAlerts')) {
        if ($BoundParameters.ContainsKey($p)) {
            $v = Get-Variable -Name $p -ValueOnly -ErrorAction SilentlyContinue
            if ($v -is [switch]) { if ($v.IsPresent) { $argParts += "-$p" } }
            elseif ($v -is [System.Array]) {
                if ($v.Count -gt 0) {
                    # -File mode binds the value as ONE string, so the separator
                    # must match what the receiver re-splits on. FarmPeers uses
                    # ';' between peers (',' separates PORTS within one peer);
                    # VaultAddress/PSMServers re-split on ',' at consumption.
                    # Strip quote chars: they are never legal in hostnames but DO
                    # appear when a caller passed an array through -File itself.
                    $sep = if ($p -eq 'FarmPeers') { ';' } else { ',' }
                    $clean = @($v | ForEach-Object { "$_" -replace "['`"]", '' } | Where-Object { $_ })
                    $argParts += "-$p"; $argParts += "`"$($clean -join $sep)`""
                }
            }
            elseif (-not [string]::IsNullOrWhiteSpace("$v")) {
                $cleanVal = "$v" -replace '[''"]', ''
                $argParts += "-$p"; $argParts += "`"$cleanVal`""
            }
        }
    }
    $argument = $argParts -join ' '

    try {
        $action    = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument $argument
        $trigger   = New-ScheduledTaskTrigger -Once -At (Get-Date) `
            -RepetitionInterval (New-TimeSpan -Minutes $interval) `
            -RepetitionDuration (New-TimeSpan -Days 3650)
        $principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
        $settings  = New-ScheduledTaskSettingsSet -StartWhenAvailable -DontStopOnIdleEnd -AllowStartIfOnBatteries -MultipleInstances IgnoreNew

        # Remove any prior tier-based tasks (older 3-task layout) first.
        foreach ($old in @('CyberArk Monitor - Hot','CyberArk Monitor - Warm','CyberArk Monitor - Cool')) {
            if (Get-ScheduledTask -TaskName $old -ErrorAction SilentlyContinue) {
                try { Unregister-ScheduledTask -TaskName $old -Confirm:$false; Write-Log -Message "Removed legacy task: $old" -Level Info -Color Gray -LogOnly } catch { }
            }
        }

        Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger `
            -Principal $principal -Settings $settings `
            -Description "CyberArk Platform Monitor - full -Scheduled run every ${interval}m" -Force | Out-Null

        # Echo exactly what was created (so this step isn't a black box).
        $info = Get-ScheduledTaskInfo -TaskName $taskName -ErrorAction SilentlyContinue
        Write-Host ""
        Write-Host "Registered scheduled task:" -ForegroundColor Green
        Write-Host "  Name      : $taskName"
        Write-Host "  Runs      : powershell.exe $argument"
        Write-Host "  Interval  : every $interval minute(s), indefinitely, as SYSTEM (Highest), one instance at a time"
        if ($info -and $info.NextRunTime) { Write-Host "  Next run  : $($info.NextRunTime)" }
        Write-Host "  Manage    : Task Scheduler Library > '$taskName'   (remove with -UnregisterTasks)"
        Write-Host ""
        Write-Log -Message "Registered scheduled task '$taskName' (every ${interval}m): powershell.exe $argument" -Level Info -Color Green -LogOnly
    }
    catch {
        Write-Log -Message "Failed to register task '$taskName': $($_.Exception.Message)" -Level Error -Color Red
        Write-Host "Failed to register task '$taskName': $($_.Exception.Message)" -ForegroundColor Red
        Write-Host "  (Run in an elevated / Administrator PowerShell.)" -ForegroundColor Yellow
    }
}

function Unregister-MonitorTasks {
    <#
    .SYNOPSIS
        Removes the monitor scheduled task (single-task layout) plus any legacy
        tier-based tasks (Hot/Warm/Cool) from the older layout.
    #>
    [CmdletBinding()]
    param()

    $names = @('CyberArk Platform Monitor','CyberArk Monitor - Hot','CyberArk Monitor - Warm','CyberArk Monitor - Cool')
    $sch = $script:Config.scheduling
    if ($null -ne $sch) {
        $tn = if ($sch -is [hashtable]) { $sch['taskName'] } else { $sch.taskName }
        if (-not [string]::IsNullOrWhiteSpace($tn) -and $names -notcontains $tn) { $names = @($tn) + $names }
    }

    $removed = 0
    foreach ($taskName in $names) {
        try {
            if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
                Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
                Write-Host "Removed scheduled task: $taskName" -ForegroundColor Green
                Write-Log -Message "Removed scheduled task: $taskName" -Level Info -Color Green -LogOnly
                $removed++
            }
        }
        catch {
            Write-Log -Message "Failed to remove task '$taskName': $($_.Exception.Message)" -Level Warn -Color Yellow
        }
    }
    if ($removed -eq 0) { Write-Host "No CyberArk monitor tasks found to remove." -ForegroundColor Gray }
}

#endregion

#region Main Execution

# --- Bootstrap ---
$script:StartTime = Get-Date
$script:Config = Import-MonitorConfig -ExplicitPath $ConfigPath

# Config utilities: view / upgrade the on-disk config, then exit. Run BEFORE the
# CLI-override merge so they reflect the file + defaults, not runtime overrides.
if ($DumpConfig) {
    Write-Host ($script:Config | ConvertTo-Json -Depth 10)
    exit 0
}
if ($UpgradeConfig) {
    $target = if (-not [string]::IsNullOrWhiteSpace($script:ResolvedConfigPath)) { $script:ResolvedConfigPath }
              elseif ($PSBoundParameters.ContainsKey('ConfigPath') -and -not [string]::IsNullOrWhiteSpace($ConfigPath)) { $ConfigPath }
              else { Join-Path $PSScriptRoot 'ca-platform-monitor.json' }
    try {
        if (Test-Path $target) { try { Copy-Item $target "$target.bak" -Force -ErrorAction Stop } catch { } }
        [System.IO.File]::WriteAllText($target, ($script:Config | ConvertTo-Json -Depth 10), [System.Text.UTF8Encoding]::new($false))
        Write-Host "Config upgraded: $target" -ForegroundColor Green
        Write-Host "  Every current default key is now present; your existing values were preserved." -ForegroundColor Gray
        if (Test-Path "$target.bak") { Write-Host "  Previous file backed up to: $target.bak" -ForegroundColor Gray }
        exit 0
    }
    catch {
        Write-Host "Config upgrade failed: $($_.Exception.Message)" -ForegroundColor Red
        exit 1
    }
}

Merge-ConfigWithParams -Config $script:Config -BoundParameters $PSBoundParameters

# Record which Skip* flags the user explicitly passed on the CLI so tier
# dispatch (Get-SkipFlagsForTier) can reset the rest between tier runs.
$script:UserSkipFlags = @(
    @('SkipSystemHealth','SkipServices','SkipCertificates','SkipCapacity',
      'SkipCPM','SkipPSM','SkipConnectivity','SkipWebDrivers','SkipPVWA','SkipLogScan') |
        Where-Object { $PSBoundParameters.ContainsKey($_) }
)

$logDir = $script:Config.logging.path
if ([string]::IsNullOrWhiteSpace($logDir)) {
    $scriptDir = $PSScriptRoot
    if ([string]::IsNullOrWhiteSpace($scriptDir)) { $scriptDir = $PWD.Path }
    $logDir = Join-Path $scriptDir 'Logs'
}
Initialize-Logger -LogDir $logDir -Level $script:Config.logging.level -ConsoleOut $script:LogConsoleOut -MaxSizeMB $script:Config.logging.maxSizeMB

# Log the invocation early so every run's log records exactly what was run --
# mode, tier, and the switches/parameters passed on the command line.
$invokedParams = if ($PSBoundParameters.Count -gt 0) { ($PSBoundParameters.Keys | Sort-Object) -join ', ' } else { '(none)' }
Write-Log -Message "Run start: Mode=$($script:OperatingMode) Tier=$($script:CurrentTier) Params=[$invokedParams]" -Level Info -Color Gray -LogOnly

if ($script:IsFirstRun) {
    Show-FirstRunBanner -ConfigCreatedAt $script:FirstRunConfigPath
}

# Last-resort handler: any terminating error that escapes the mode dispatch is
# logged, state is saved best-effort (so alert cooldown/dedup survives), and the
# process exits 2 (Critical) instead of PowerShell's generic exit 1 -- a broken
# monitor must be loudly distinguishable from a healthy run.
trap {
    try {
        Write-Log -Message "FATAL unhandled error: $($_.Exception.Message) at $($_.InvocationInfo.PositionMessage)" -Level Error -Color Red
    } catch { }
    try {
        if ($null -ne $script:PlatformState) {
            Export-PlatformState -State $script:PlatformState -FilePath $resolvedStatePath
        }
    } catch { }
    exit 2
}

Write-Section -Title "$($script:ToolName) v$($script:ToolVersion) - $($script:OperatingMode) Mode"
Write-Log -Message "Server: $($env:COMPUTERNAME) | Correlation: $($script:CorrelationID)" -Level Info -Color Gray

# Resolve metrics path against $PSScriptRoot
$metricsPath = $script:Config.storage.metricsPath
if ([string]::IsNullOrWhiteSpace($metricsPath)) {
    $scriptDir   = $PSScriptRoot
    if ([string]::IsNullOrWhiteSpace($scriptDir)) { $scriptDir = $PWD.Path }
    $metricsPath = Join-Path $scriptDir 'Metrics'
    $script:Config.storage.metricsPath = $metricsPath
}

# Load requirements and state (use mock data if requested)
if ($UseMockData) {
    $script:Requirements = Get-MockData -DataType MockRequirements
    $script:PlatformState = Get-MockData -DataType MockPlatformState
} else {
    $script:Requirements = Import-MonitoringRequirements -ExplicitPath $RequirementsPath
    $script:PlatformState = Import-PlatformState -ExplicitPath $StatePath
}
# Zero requirements (e.g. an empty [] file) returns $null; normalize to an empty
# array so Send-AlertNotifications' [array] -Requirements param can bind it.
if ($null -eq $script:Requirements) { $script:Requirements = @() }

# Resolve state file path for saves
$resolvedStatePath = $StatePath
if ([string]::IsNullOrWhiteSpace($resolvedStatePath)) {
    $stateScriptDir = $PSScriptRoot
    if ([string]::IsNullOrWhiteSpace($stateScriptDir)) {
        $stateScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
    }
    if ([string]::IsNullOrWhiteSpace($stateScriptDir)) {
        $stateScriptDir = $PWD.Path
    }
    $resolvedStatePath = Join-Path $stateScriptDir 'platform-state.json'
}

# Early exits: task registration, test alert, digest
if ($RegisterTasks)   { Register-MonitorTasks -BoundParameters $PSBoundParameters; exit 0 }
if ($UnregisterTasks) { Unregister-MonitorTasks; exit 0 }
if ($TestAlert) {
    $testReq = (Get-DefaultRequirements)[0]
    $testBody = New-AlertEmailBody -Requirement $testReq -EvalResult ([PSCustomObject]@{
        RequirementId = 'TEST'
        Status        = 'Warning'
        CurrentValue  = 85
        Threshold     = 80
        Direction     = 'HigherIsBad'
        MetricPath    = 'CPU.Average'
    }) -State $script:PlatformState
    $sent = Send-MonitorEmail -To $script:Config.alerting.defaults.notifyTo -Subject "Test Alert from Platform Monitor - $($env:COMPUTERNAME)" -HtmlBody $testBody
    Write-Log -Message "Test alert $(if($sent){'sent successfully'}else{'FAILED'})" -Level Info -Color $(if($sent){'Green'}else{'Red'})
    exit $(if($sent){0}else{1})
}
if ($DigestNow) {
    Invoke-DailyDigest
    exit 0
}

# Set tier skip flags
if ($script:CurrentTier -ne 'All') {
    Get-SkipFlagsForTier -Tier $script:CurrentTier
}

# --- Helper: Write all JSONL records from collection results ---
function New-MetricSummaryRecord {
    <#
    .SYNOPSIS
        One flat, fixed-schema row summarizing a whole collection run -- written
        every run regardless of mode/tier, for easy columnar/time-series parsing
        (jq, Import-Csv-after-flatten, modstat, etc.). Fields for collectors that
        did not run this tier are $null. Never throws (caller wraps too).
    #>
    [CmdletBinding()]
    [OutputType([System.Collections.Specialized.OrderedDictionary])]
    param([hashtable]$Results)

    $meta    = $Results.CollectionMeta
    $sh      = $Results.SystemHealth
    $sr      = $Results.ServiceStatus
    $ch      = $Results.CertificateHealth
    $cpm     = $Results.CPMHealth
    $psm     = $Results.PSMHealth
    $pvwa    = $Results.PVWAHealth
    $logscan = $Results.LogScan
    $wd      = $Results.WebDriverHealth
    # @($null) is a ONE-element array -- filter nulls or a tier run without
    # Connectivity throws on $null.Reachable below (StrictMode).
    $connRan = ($null -ne $Results.Connectivity)
    $conn    = @($Results.Connectivity | Where-Object { $null -ne $_ })
    $alerts  = @($Results.Alerts)

    $prop = { param($obj, $name) if ($null -eq $obj) { return $null }
              $m = $obj.PSObject.Properties.Match($name); if ($m.Count -gt 0) { $m[0].Value } else { $null } }
    $cpu = & $prop $sh 'CPU'
    $mem = & $prop $sh 'Memory'
    $rdp = & $prop $sh 'RdpSessions'

    $worstDiskPct = $null
    $disks = & $prop $sh 'Disks'
    if ($null -ne $disks) {
        $wdisk = @($disks | Sort-Object UsedPercent -Descending | Select-Object -First 1)
        if ($wdisk.Count -gt 0) { $worstDiskPct = [math]::Round([double]$wdisk[0].UsedPercent, 2) }
    }

    # Farm peer states (only present on Connectivity rows flagged IsFarmPeer)
    $isPeer = { param($c) ($c.PSObject.Properties.Name -contains 'IsFarmPeer') -and $c.IsFarmPeer }
    $peersDown    = @($conn | Where-Object { (& $isPeer $_) -and $_.PeerState -eq 'Down' }).Count
    $peersSuspect = @($conn | Where-Object { (& $isPeer $_) -and $_.PeerState -eq 'Suspect' }).Count

    # WebDriver: incompatible pairs where a driver actually exists
    $wdIncompatible = $null
    if ($null -ne $wd) {
        $wdIncompatible = @(@($wd) | Where-Object {
            ($_.PSObject.Properties.Name -contains 'DriverExists') -and $_.DriverExists -and -not $_.Compatible
        }).Count
    }

    # Recency bucket rollups (from the unified Findings list) for modstat/columnar use.
    $findings = @($Results.Findings)
    $svcRestarts24h = 0; $svcCrashes7d = 0
    foreach ($f in $findings) {
        switch ("$($f['kind'])") {
            'ServiceRestart' { $svcRestarts24h += [int]$f['count24h'] }
            'ServiceCrash'   { $svcCrashes7d   += [int]$f['count7d'] }
        }
    }
    $findingsCritical = @($findings | Where-Object { "$($_['severity'])" -eq 'Critical' }).Count
    $findingsWarning  = @($findings | Where-Object { "$($_['severity'])" -eq 'Warning' }).Count
    $cpmRec = & $prop $cpm 'Recency'; $cpmErrors24h = if ($cpmRec) { [int]$cpmRec['count24h'] } else { $null }
    $psmRec = & $prop $psm 'Recency'; $psmErrors24h = if ($psmRec) { [int]$psmRec['count24h'] } else { $null }

    return [ordered]@{
        recordType        = 'MetricSummary'
        correlationId     = $script:CorrelationID
        timestamp         = (Get-Date).ToUniversalTime().ToString('o')
        host              = $(if ($meta -and $meta['serverName']) { $meta['serverName'] } else { $env:COMPUTERNAME })
        hostIp            = $script:HostIp
        mode              = $(if ($meta -and $meta['mode']) { $meta['mode'] } else { $script:OperatingMode })
        tier              = $(if ($meta -and $meta['tier']) { $meta['tier'] } else { $script:CurrentTier })
        overallStatus     = $(if ($meta -and $meta['overallStatus']) { $meta['overallStatus'] } else { 'Unknown' })
        alertCount        = $alerts.Count
        criticalCount     = @($alerts | Where-Object { $_.severity -eq 'Critical' }).Count
        warningCount      = @($alerts | Where-Object { $_.severity -eq 'Warning' }).Count
        cpuCurrent        = & $prop $cpu 'Current'
        cpuAvg            = & $prop $cpu 'Average'
        cpuPeak           = & $prop $cpu 'Peak'
        memPct            = & $prop $mem 'UsedPercent'
        worstDiskPct      = $worstDiskPct
        uptimeDays        = & $prop $sh 'UptimeDays'
        servicesHealthy   = & $prop $sr 'HealthyServices'
        servicesTotal     = & $prop $sr 'TotalServices'
        servicesStopped   = & $prop $sr 'StoppedServices'
        rdpActive         = & $prop $rdp 'Active'
        rdpDisconnected   = & $prop $rdp 'Disconnected'
        rdpShadowUsers    = & $prop $rdp 'ShadowUsers'
        rdpShadowDisc     = & $prop $rdp 'ShadowDisconnected'
        connectivityOk    = $(if ($connRan) { @($conn | Where-Object { $_.Reachable }).Count } else { $null })
        connectivityTotal = $(if ($connRan) { $conn.Count } else { $null })
        peersDown         = $(if ($connRan) { $peersDown } else { $null })
        peersSuspect      = $(if ($connRan) { $peersSuspect } else { $null })
        certStatus        = & $prop $ch 'Status'
        certExpiredCount  = & $prop $ch 'ExpiredCount'
        certCriticalCount = & $prop $ch 'CriticalCount'
        cpmStatus         = & $prop $cpm 'Status'
        cpmErrors         = & $prop $cpm 'ErrorCount'
        psmStatus         = & $prop $psm 'Status'
        psmSysErrors      = & $prop $psm 'SystemErrorCount'
        pvwaStatus        = & $prop $pvwa 'Status'
        logScanStatus     = & $prop $logscan 'Status'
        logScanErrors     = & $prop $logscan 'TotalErrors'
        svcRestarts24h    = $(if ($null -ne $sr)  { $svcRestarts24h } else { $null })
        svcCrashes7d      = $(if ($null -ne $sr)  { $svcCrashes7d }   else { $null })
        cpmErrors24h      = $cpmErrors24h
        psmErrors24h      = $psmErrors24h
        logErrors24h      = & $prop $logscan 'TotalErrors'
        findingsCritical  = $findingsCritical
        findingsWarning   = $findingsWarning
        webDriverIncompat = $wdIncompatible
        durationMs        = $(if ($meta -and $meta['durationMs']) { $meta['durationMs'] } else { $null })
    }
}

function Write-CollectionToJSONL {
    param(
        [Parameter(Mandatory)]
        [hashtable]$Results,
        [Parameter(Mandatory)]
        [string]$Dir
    )

    # Every record carries host + hostIp in the same positions so JSONL from
    # many servers can be concatenated and aggregated with no ambiguity.
    $newRec = {
        param([string]$type)
        [ordered]@{
            recordType    = $type
            correlationId = $script:CorrelationID
            timestamp     = (Get-Date).ToUniversalTime().ToString('o')
            host          = $env:COMPUTERNAME
            hostIp        = $script:HostIp
        }
    }

    $meta = & $newRec 'CollectionMeta'
    foreach ($k in @($Results.CollectionMeta.Keys)) {
        if (-not $meta.Contains($k)) { $meta[$k] = $Results.CollectionMeta[$k] }
    }
    Write-MetricRecord -MetricsDir $Dir -Record $meta

    # Flat one-row-per-run summary (fixed schema, every mode) for external parsing:
    # into the daily detail file AND the dedicated modstat-style outputs
    # (platform-summary.jsonl trend file + platform-status.json snapshot).
    try {
        $summaryRec = New-MetricSummaryRecord -Results $Results
        Write-MetricRecord -MetricsDir $Dir -Record $summaryRec
        Write-SummaryOutputs -MetricsDir $Dir -Summary $summaryRec
    }
    catch { Write-Log -Message "MetricSummary write failed: $($_.Exception.Message)" -Level Warn -Color Yellow -Component 'Metrics' }

    $recordTypes = @('SystemHealth','ServiceStatus','CertificateHealth','ServerCapacity','CPMHealth','PSMHealth','PVWAHealth','LogScan')
    foreach ($rt in $recordTypes) {
        if ($null -ne $Results[$rt]) {
            $rec = & $newRec $rt
            $Results[$rt].PSObject.Properties | ForEach-Object { if (-not $rec.Contains($_.Name)) { $rec[$_.Name] = $_.Value } }
            Write-MetricRecord -MetricsDir $Dir -Record $rec
        }
    }

    if ($Results.Connectivity) {
        foreach ($c in $Results.Connectivity) {
            $rec = & $newRec 'Connectivity'
            $c.PSObject.Properties | ForEach-Object { if (-not $rec.Contains($_.Name)) { $rec[$_.Name] = $_.Value } }
            Write-MetricRecord -MetricsDir $Dir -Record $rec
        }
    }

    if ($Results.WebDriverHealth) {
        foreach ($w in $Results.WebDriverHealth) {
            $rec = & $newRec 'WebDriverHealth'
            $w.PSObject.Properties | ForEach-Object { if (-not $rec.Contains($_.Name)) { $rec[$_.Name] = $_.Value } }
            Write-MetricRecord -MetricsDir $Dir -Record $rec
        }
    }

    foreach ($alert in $Results.Alerts) {
        $rec = & $newRec 'Alert'
        $alert.PSObject.Properties | ForEach-Object { if (-not $rec.Contains($_.Name)) { $rec[$_.Name] = $_.Value } }
        Write-MetricRecord -MetricsDir $Dir -Record $rec
    }

    # Recency findings -- one flat record per finding for external trending.
    if ($Results.Findings) {
        foreach ($f in $Results.Findings) {
            $rec = & $newRec 'Finding'
            foreach ($k in @($f.Keys)) { if (-not $rec.Contains($k)) { $rec[$k] = $f[$k] } }
            Write-MetricRecord -MetricsDir $Dir -Record $rec
        }
    }
}

# Retention days
$retDays = $script:Config.storage.retentionDays
if ($retDays -le 0) { $retDays = 30 }

# --- Mode Dispatch ---
switch ($script:OperatingMode) {

    'Interactive' {
        $dashRefresh = $script:Config.dashboard.refreshSeconds
        if ($PSBoundParameters.ContainsKey('RefreshSeconds')) { $dashRefresh = $RefreshSeconds }

        Show-Dashboard -RefreshSeconds $dashRefresh -SimulationMode:$DashboardSimulation -MaxIterations $DashboardIterations
        exit 0
    }

    'Report' {
        # Collect metrics
        $collectionResults = Invoke-MetricsCollection

        # Write JSONL
        Write-CollectionToJSONL -Results $collectionResults -Dir $metricsPath

        # Requirements evaluation
        $evals = @()
        if ($null -ne $script:Requirements -and @($script:Requirements).Count -gt 0) {
            try {
                $evals = @(Invoke-RequirementsEvaluation -Requirements $script:Requirements `
                    -CollectionResults $collectionResults -TierName $script:CurrentTier)
                Write-Log -Message "Requirements evaluation complete: $($evals.Count) requirement(s) checked" -Level Info -Color Gray
            }
            catch {
                Write-Log -Message "Requirements evaluation failed: $($_.Exception.Message)" -Level Warn -Color Yellow
            }
        }

        # Update daily summary and state
        Update-DailySummary -State $script:PlatformState -CollectionResults $collectionResults
        Export-PlatformState -State $script:PlatformState -FilePath $resolvedStatePath

        # Capacity forecasting
        $forecasts = @()
        if ($script:Config.reporting.includeForecasting) {
            try {
                $forecasts = @(Get-AllForecasts -MetricsDir $metricsPath -LookbackDays $ForecastDays)
                Write-Log -Message "Capacity forecasting complete: $($forecasts.Count) metric(s) analyzed" -Level Info -Color Gray
            }
            catch {
                Write-Log -Message "Capacity forecasting failed: $($_.Exception.Message)" -Level Warn -Color Yellow
            }
        }

        # Generate HTML report with requirements and state
        $html = New-PlatformHealthReport -CollectionResults $collectionResults -Forecasts $forecasts `
            -RequirementEvals $evals -PlatformState $script:PlatformState

        # Resolve output path
        $reportPath = $script:Config.reporting.outputPath
        if ([string]::IsNullOrWhiteSpace($reportPath)) {
            $scriptDir = $PSScriptRoot
            if ([string]::IsNullOrWhiteSpace($scriptDir)) { $scriptDir = $PWD.Path }
            $reportPath = Join-Path $scriptDir "PlatformHealthReport-$(Get-Date -Format 'yyyy-MM-dd_HHmmss').html"
        }
        elseif (Test-Path $reportPath -PathType Container) {
            $reportPath = Join-Path $reportPath "PlatformHealthReport-$(Get-Date -Format 'yyyy-MM-dd_HHmmss').html"
        }

        # Ensure parent directory exists
        $reportDir = Split-Path -Parent $reportPath
        if (-not [string]::IsNullOrWhiteSpace($reportDir) -and -not (Test-Path $reportDir)) {
            try { New-Item -Path $reportDir -ItemType Directory -Force | Out-Null } catch { }
        }

        # Write report
        try {
            $encoding = [System.Text.UTF8Encoding]::new($false)
            [System.IO.File]::WriteAllText($reportPath, $html, $encoding)
            Write-Log -Message "HTML report saved to: $reportPath" -Level Info -Color Green
        }
        catch {
            Write-Log -Message "Failed to write HTML report: $($_.Exception.Message)" -Level Error -Color Red
        }

        # Metrics rotation
        Invoke-MetricsRotation -MetricsDir $metricsPath -RetentionDays $retDays

        # Summary
        $overallStatus = $collectionResults.CollectionMeta['overallStatus']
        Write-Section -Title 'Collection Complete'
        Write-Log -Message "Overall Status: $overallStatus | Alerts: $($collectionResults.Alerts.Count) | Duration: $([math]::Round(((Get-Date) - $script:StartTime).TotalSeconds, 1))s" -Level Info -Color $(if ($overallStatus -eq 'OK') { 'Green' } elseif ($overallStatus -eq 'Warning') { 'Yellow' } else { 'Red' })
        Write-Log -Message "Metrics written to: $metricsPath" -Level Info -Color Gray
        Write-Log -Message "Report: $reportPath" -Level Info -Color Gray
        Write-Log -Message "Log file: $($script:LogFile)" -Level Info -Color Gray

        # Exit code based on overall status
        $script:ExitCode = switch ($overallStatus) {
            'Critical' { 2 }
            'Warning'  { 1 }
            default    { 0 }
        }
        exit $script:ExitCode
    }

    'Scheduled' {
        # Collect metrics (headless -- no console output)
        $collectionResults = Invoke-MetricsCollection

        # Write JSONL
        Write-CollectionToJSONL -Results $collectionResults -Dir $metricsPath

        # Requirements evaluation
        $evaluations = @()
        if ($null -ne $script:Requirements -and @($script:Requirements).Count -gt 0) {
            try {
                $evaluations = @(Invoke-RequirementsEvaluation -Requirements $script:Requirements `
                    -CollectionResults $collectionResults -TierName $script:CurrentTier)
            }
            catch {
                Write-Log -Message "Requirements evaluation failed: $($_.Exception.Message)" -Level Warn -Color Yellow -LogOnly
            }
        }

        # Alert state machine
        $notifyActions = @()
        if ($evaluations.Count -gt 0) {
            $notifyActions = @(Update-AlertState -State $script:PlatformState -Evaluations $evaluations `
                -Requirements $script:Requirements -AlertingConfig $script:Config.alerting)
        }

        # Daily summary rollup
        Update-DailySummary -State $script:PlatformState -CollectionResults $collectionResults

        # Self-heal: restart allowlisted services found unexpectedly stopped.
        # Remediation is independent of alerting.enabled (allowlist is the opt-in);
        # only the outcome email honors -NoAlerts.
        if ($null -ne $collectionResults.ServiceStatus) {
            $null = Invoke-ServiceAutoRestart -ServiceResult $collectionResults.ServiceStatus -State $script:PlatformState -NoAlerts:$NoAlerts
        }

        # SMTP notifications (before state save so lastNotifiedAt updates only on success)
        if (-not $NoAlerts -and $script:Config.alerting.enabled) {
            Send-AlertNotifications -Actions $notifyActions -State $script:PlatformState -Requirements $script:Requirements
            if (Test-DigestDue -State $script:PlatformState) {
                Invoke-DailyDigest
            }
        }

        # Update last collection timestamp
        $tierKey = $script:CurrentTier.ToLower()
        if ($tierKey -eq 'all') {
            $script:PlatformState.lastCollection['hot']  = (Get-Date).ToUniversalTime().ToString('o')
            $script:PlatformState.lastCollection['warm'] = (Get-Date).ToUniversalTime().ToString('o')
            $script:PlatformState.lastCollection['cool'] = (Get-Date).ToUniversalTime().ToString('o')
        } else {
            $script:PlatformState.lastCollection[$tierKey] = (Get-Date).ToUniversalTime().ToString('o')
        }

        # Save state
        Export-PlatformState -State $script:PlatformState -FilePath $resolvedStatePath

        # Metrics rotation
        Invoke-MetricsRotation -MetricsDir $metricsPath -RetentionDays $retDays

        # Capacity forecasting -- the poller runs this too, otherwise a days-long
        # -Scheduled poller never projects capacity (it would miss e.g. "memory
        # reaches 95% in 6 days" that only a manual -Report would surface). Log-only:
        # URGENT/CRITICAL projections are highlighted at Warn but do not change the
        # exit code (that stays driven by current-threshold Alerts).
        if ($script:Config.reporting.includeForecasting) {
            try {
                $schedForecasts = @(Get-AllForecasts -MetricsDir $metricsPath -LookbackDays $ForecastDays)
                $urgentF = @($schedForecasts | Where-Object { "$($_.Recommendation)" -match 'URGENT|CRITICAL' })
                Write-Log -Message "Capacity forecasting: $($schedForecasts.Count) metric(s) analyzed, $($urgentF.Count) urgent/critical" -Level Info -Color Gray -LogOnly
                foreach ($u in $urgentF) { Write-Log -Message "  FORECAST $($u.MetricName): $($u.Recommendation)" -Level Warn -Color Yellow -Component 'Forecast' }
            }
            catch { Write-Log -Message "Capacity forecasting failed (non-fatal): $($_.Exception.Message)" -Level Warn -Color Yellow -LogOnly }
        }

        # Summary log
        $overallStatus = $collectionResults.CollectionMeta['overallStatus']
        $dur = [math]::Round(((Get-Date) - $script:StartTime).TotalSeconds, 1)
        Write-Log -Message "Scheduled collection complete. Status: $overallStatus | Alerts: $($collectionResults.Alerts.Count) | Notifications: $($notifyActions.Count) | Duration: ${dur}s" -Level Info -Color Gray -LogOnly

        # Exit code based on overall status
        $script:ExitCode = switch ($overallStatus) {
            'Critical' { 2 }
            'Warning'  { 1 }
            default    { 0 }
        }

        # Concise console summary -- Scheduled mode suppresses per-collector chatter
        # (it's for schtasks), but a silent run is confusing when invoked by hand.
        $sumColor = switch ($overallStatus) { 'Critical' { 'Red' } 'Warning' { 'Yellow' } default { 'Green' } }
        Write-Host ""
        Write-Host "Scheduled run complete ($($script:CurrentTier) tier): $overallStatus" -ForegroundColor $sumColor
        Write-Host "  Alerts: $($collectionResults.Alerts.Count) | Notifications sent: $($notifyActions.Count) | Duration: ${dur}s"
        Write-Host "  Components: $($collectionResults.CollectionMeta.components -join ', ')" -ForegroundColor Gray
        Write-Host "  Log:     $($script:LogFile)" -ForegroundColor Gray
        Write-Host "  Metrics: $metricsPath" -ForegroundColor Gray
        Write-Host "  Exit code: $($script:ExitCode) (0=OK, 1=Warning, 2=Critical)" -ForegroundColor Gray
        Write-Host "  (This is a one-shot run. To create scheduled tasks use -RegisterTasks; to poll continuously use -Monitor.)" -ForegroundColor DarkGray

        exit $script:ExitCode
    }

    'Monitor' {
        # Continuous loop with per-tier timers
        $tierTimers = [ordered]@{}
        if ($script:CurrentTier -eq 'All') {
            foreach ($t in @('Hot','Warm','Cool')) {
                $tierIntervalCfg = $script:Config.tiers
                $tierDef = $null
                $tLower = $t.ToLower()
                if ($tierIntervalCfg -is [hashtable]) { $tierDef = $tierIntervalCfg[$tLower] }
                else { $tierDef = $tierIntervalCfg.$tLower }
                $intervalMin = 5
                if ($null -ne $tierDef) {
                    if ($tierDef -is [hashtable]) { $intervalMin = $tierDef['intervalMinutes'] }
                    else { $intervalMin = $tierDef.intervalMinutes }
                }
                $tierTimers[$t] = @{
                    interval = [TimeSpan]::FromMinutes($intervalMin)
                    lastRun  = [DateTime]::MinValue
                }
            }
        } else {
            $tLower = $script:CurrentTier.ToLower()
            $tierIntervalCfg = $script:Config.tiers
            $tierDef = $null
            if ($tierIntervalCfg -is [hashtable]) { $tierDef = $tierIntervalCfg[$tLower] }
            else { $tierDef = $tierIntervalCfg.$tLower }
            $intervalMin = 5
            if ($null -ne $tierDef) {
                if ($tierDef -is [hashtable]) { $intervalMin = $tierDef['intervalMinutes'] }
                else { $intervalMin = $tierDef.intervalMinutes }
            }
            $tierTimers[$script:CurrentTier] = @{
                interval = [TimeSpan]::FromMinutes($intervalMin)
                lastRun  = [DateTime]::MinValue
            }
        }

        $stopRequested = $false
        $lastRotationDate = (Get-Date).Date
        Invoke-MetricsRotation -MetricsDir $metricsPath -RetentionDays $retDays
        Write-Log -Message "Monitor mode started. Tiers: $($tierTimers.Keys -join ', '). Press Q to stop." -Level Info -Color Cyan

        while (-not $stopRequested) {
            $now = Get-Date

            # Rotate JSONL metrics once per day -- without this a long-running
            # Monitor process never applies retention and files grow unbounded.
            if ($now.Date -gt $lastRotationDate) {
                Invoke-MetricsRotation -MetricsDir $metricsPath -RetentionDays $retDays
                $lastRotationDate = $now.Date
            }
            foreach ($tierName in @($tierTimers.Keys)) {
                $timer = $tierTimers[$tierName]
                if (($now - $timer.lastRun) -ge $timer.interval) {
                    try {
                    Write-Log -Message "--- Running tier: $tierName ---" -Level Info -Color Cyan
                    $script:CurrentTier = $tierName
                    Get-SkipFlagsForTier -Tier $tierName

                    $results = Invoke-MetricsCollection
                    Write-CollectionToJSONL -Results $results -Dir $metricsPath

                    $evals = @()
                    if ($null -ne $script:Requirements -and @($script:Requirements).Count -gt 0) {
                        try {
                            $evals = @(Invoke-RequirementsEvaluation -Requirements $script:Requirements `
                                -CollectionResults $results -TierName $tierName)
                        }
                        catch {
                            Write-Log -Message "Requirements evaluation failed: $($_.Exception.Message)" -Level Warn -Color Yellow
                        }
                    }

                    $actions = @()
                    if ($evals.Count -gt 0) {
                        $actions = @(Update-AlertState -State $script:PlatformState -Evaluations $evals `
                            -Requirements $script:Requirements -AlertingConfig $script:Config.alerting)
                    }

                    Update-DailySummary -State $script:PlatformState -CollectionResults $results

                    # Self-heal: restart allowlisted services found unexpectedly stopped.
                    if ($null -ne $results.ServiceStatus) {
                        $null = Invoke-ServiceAutoRestart -ServiceResult $results.ServiceStatus -State $script:PlatformState -NoAlerts:$NoAlerts
                    }

                    if (-not $NoAlerts -and $script:Config.alerting.enabled) {
                        Send-AlertNotifications -Actions $actions -State $script:PlatformState -Requirements $script:Requirements
                        if (Test-DigestDue -State $script:PlatformState) {
                            Invoke-DailyDigest
                        }
                    }

                    # Update timer and state
                    $timer.lastRun = Get-Date
                    $script:PlatformState.lastCollection[$tierName.ToLower()] = (Get-Date).ToUniversalTime().ToString('o')

                    # Save state after each tier run
                    Export-PlatformState -State $script:PlatformState -FilePath $resolvedStatePath
                    }
                    catch {
                        # One tier failing must not kill the continuous loop.
                        # Stamp lastRun so the failed tier waits a full interval
                        # instead of hot-looping the failure every second.
                        $timer.lastRun = Get-Date
                        Write-Log -Message "Tier '$tierName' run failed (loop continues): $($_.Exception.Message)" -Level Error -Color Red
                    }
                }
            }

            # Q key exit check (non-blocking)
            try {
                if ([Console]::KeyAvailable) {
                    $key = [Console]::ReadKey($true)
                    if ($key.KeyChar -eq 'q' -or $key.KeyChar -eq 'Q') {
                        $stopRequested = $true
                    }
                }
            }
            catch {
                # KeyAvailable may throw in non-interactive environments -- ignore
            }

            if (-not $stopRequested) {
                Start-Sleep -Seconds 1
            }
        }

        Write-Log -Message 'Monitor mode stopped.' -Level Info -Color Cyan
        exit 0
    }
}

#endregion
