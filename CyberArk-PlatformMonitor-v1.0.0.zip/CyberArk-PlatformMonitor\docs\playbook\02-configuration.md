# Configuration

## Configuration File Reference

The configuration file `ca-platform-monitor.json` controls all aspects of collection, thresholds, storage, and alerting. It is auto-created with defaults on first run. Every setting has a sensible default and can be overridden by CLI parameters.

**Config search order** (first match wins):

1. `-ConfigPath` parameter (explicit)
2. `$PSScriptRoot\ca-platform-monitor.json` (same directory as the script)
3. `$env:USERPROFILE\.cyberark\ca-platform-monitor.json` (user profile)

### Server Section

Identifies the server and its role for reporting.

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `server.hostname` | string | `""` (auto-detected) | Override the hostname shown in reports |
| `server.environment` | string | `"Production"` | Label: Production, Staging, Lab, DR |
| `server.role` | string | `"Auto"` | Server role: Auto, Vault, CPM, PSM, PVWA, AllInOne |

### Collection Section

Controls how data is gathered from each source.

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `collection.cpuSampleCount` | int | `5` | Number of CPU samples to average |
| `collection.cpuSampleIntervalMs` | int | `1000` | Milliseconds between CPU samples |
| `collection.eventLogLookbackDays` | int | `30` | Days of event log history to scan for service restart counts |
| `collection.logTailLines` | int | `1000` | Number of lines to read from CPM/PSM logs |
| `collection.logLookbackMinutes` | int | `60` | Only count log errors within this window |
| `collection.cyberArkServices` | array | *(see below)* | List of Windows service names to monitor |
| `collection.shadowUserPrefixes` | array | `["PSMShadowUser", "PSM-"]` | Session usernames with these prefixes count as PSM shadow users in the RDP session snapshot |

Default service list:

```json
[
    "CyberArk Password Manager",
    "CyberArk Central Policy Manager Scanner",
    "CyberArk Privileged Session Manager",
    "CyberArk Application Password Provider",
    "PrivateArk Server",
    "PrivateArk Database",
    "CyberArk Vault Disaster Recovery",
    "CyberArk Event Notification Engine",
    "CyberArk Logic Container"
]
```

### Connectivity Section

Defines network targets for TCP connectivity checks.

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `connectivity.vaultAddress` | string | `""` | Vault server hostname or IP for port 1858 test |
| `connectivity.vaultPort` | int | `1858` | Vault port number |
| `connectivity.psmServers` | array | `[]` | Additional PSM server hostnames to test |
| `connectivity.timeoutSeconds` | int | `5` | TCP connection timeout |
| `connectivity.farmPeers` | array | `[]` | Other CyberArk farm servers this box watches (see below) |
| `connectivity.retryCount` | int | `2` | Attempts per target per check-in (absorbs transient errors) |
| `connectivity.retryDelaySeconds` | int | `3` | Delay between in-run retry attempts |
| `connectivity.peerDownGraceSeconds` | int | `150` | Grace window before a failing peer is confirmed Down |

#### Farm Peer Monitoring

Deploy the monitor to every server in the CyberArk farm and point each at its
peers -- every server then independently reports when another goes down, with
no central poller as a single point of failure.

Peer entries accept two forms:

```json
"farmPeers": [
    "vault01.corp.local:1858",
    "psm01.corp.local:3389",
    "pvwa01.corp.local:443,80",
    "cpm01.corp.local",
    { "host": "psm02.corp.local", "ports": [3389], "ping": true }
]
```

- `"host:port"` / `"host:port1,port2"` -- TCP checks on those ports
- `"host"` (bare) -- ICMP ping only
- Object form -- explicit `ports` array plus optional `"ping": true`
- On the CLI (scheduled tasks can't pass arrays): `-FarmPeers "psm01:3389;vault01:1858"`

**Down-grace behavior:** a failing peer target must fail **2+ consecutive
check-ins** *and* stay down past `peerDownGraceSeconds` (default 150s = 2.5
minutes) before the Critical `Farm Peer Down` alert fires and the exit code
goes to 2. Inside the window the target reports `Suspect` -- logged, visible in
the report, but not alerting -- so transient network errors and quick service
restarts never page anyone. Each check-in additionally retries the target
`retryCount` times before counting a failure. Recovery is logged and clears the
tracking state (persisted in `platform-state.json` under `peerStatus`).

With the Warm tier's default 5-minute cadence, a genuinely down peer is
confirmed on the second failed check-in (~5 minutes after first failure). Move
`Connectivity` into the Hot tier for ~2-3 minute detection.

### Thresholds Section

Warning and critical thresholds for all metric types.

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `thresholds.cpuWarningPercent` | int | `80` | CPU usage warning threshold |
| `thresholds.cpuCriticalPercent` | int | `95` | CPU usage critical threshold |
| `thresholds.memoryWarningPercent` | int | `85` | Memory usage warning threshold |
| `thresholds.memoryCriticalPercent` | int | `95` | Memory usage critical threshold |
| `thresholds.diskWarningPercent` | int | `80` | Disk usage warning threshold |
| `thresholds.diskCriticalPercent` | int | `95` | Disk usage critical threshold |
| `thresholds.certWarningDays` | int | `30` | Days before cert expiry triggers warning |
| `thresholds.certCriticalDays` | int | `7` | Days before cert expiry triggers critical |
| `thresholds.serviceRestartWarning` | int | `5` | Service restart count warning threshold |
| `thresholds.serviceRestartCritical` | int | `10` | Service restart count critical threshold |
| `thresholds.cpmErrorWarning` | int | `1` | CPM error count warning threshold |
| `thresholds.cpmErrorCritical` | int | `10` | CPM error count critical threshold |
| `thresholds.psmSystemErrorWarning` | int | `1` | PSM system error count warning threshold |
| `thresholds.psmSystemErrorCritical` | int | `10` | PSM system error count critical threshold |
| `thresholds.rdpDisconnectedWarning` | int | `0` (disabled) | Warning when this many disconnected RDP sessions accumulate (orphaned-logon indicator) |

> **Tip**: All threshold parameters can be overridden from the command line. For example: `-CpuWarningPercent 70 -CpuCriticalPercent 90`

### Recency Framework

Findings — **service** restarts/crashes/start-failures and **log** errors (CPM, PSM, LogScan) — are bucketed into time windows and **alerts fire on the recent window, not the all-time total**. A service that flapped last week but has been stable since reads Healthy again; a log with old errors that have aged out no longer alarms. The buckets (24h / 7d / 30d + last-seen) are always reported so the history stays visible.

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `recency.dayHours` | int | `24` | Size of the "24h" bucket (hours) |
| `recency.weekHours` | int | `168` | Size of the "7d" bucket |
| `recency.monthHours` | int | `720` | Size of the "30d" bucket (and the widest query window) |
| `recency.alertWindowHours` | int | `24` | Which bucket drives restart / log-error alerts. `24`→24h, `168`→7d, `720`→30d |
| `recency.crashLookbackDays` | int | `7` | Window in which a single unexpected termination (event 7031/7034) or start failure (7000/7009) alarms |

Effect on thresholds: `serviceRestartWarning/Critical`, `cpmErrorWarning/Critical`, `psmSystemErrorWarning/Critical`, and `logScan.warnCount/criticalCount` now count events **in the alert window** (24h by default) rather than the whole history.

What each collector reports (in the HTML "Recent Findings" section, per-service/per-source columns, `Finding` JSONL records, and the flat `MetricSummary` fields `svcRestarts24h`, `svcCrashes7d`, `cpmErrors24h`, `psmErrors24h`, `logErrors24h`, `findingsCritical`, `findingsWarning`):
- **Services**: `Restarts`, `Stops`, `Crashes` (7031/7034), `StartFailures` (7000/7009), each with 24h/7d/30d + last-seen. A service is Degraded on a recent crash/start-failure **or** recent restart count over threshold — not on stale churn.
- **CPM / PSM**: error timestamps (already parsed) bucketed; `ErrorCount`/`SystemErrorCount` are now the recent-window count (`ErrorCountTotal`/`SystemErrorCountTotal` keep the 30d total).
- **LogScan**: per-source timestamp extraction with a per-format leading-timestamp regex. Override per source with `timestampRegex` / `timestampFormat`. A source whose lines have no parseable timestamp falls back to a raw tail count (logged at Debug) so it never silently stops alerting.

### Storage Section

Controls JSONL metrics file location and retention.

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `storage.metricsPath` | string | `""` (defaults to `$PSScriptRoot\Metrics`) | Directory for JSONL files |
| `storage.retentionDays` | int | `30` | Auto-delete JSONL files older than this |

Every run writes three surfaces into `metricsPath`:

| File | Style | Use for |
|------|-------|---------|
| `platform-metrics-YYYY-MM-DD.jsonl` | detail: ~13 typed records per run (per collector, per connectivity target, per alert) | deep dives, forecasting input |
| `platform-summary.jsonl` | **trend file**: one flat line per run, identical fixed schema in every mode/tier (nulls where a collector didn't run) | Nagios/modstat-style trending — point your parser here, no filtering needed |
| `platform-status.json` | **current snapshot**: same flat record, atomically overwritten each run | "state right now" polling (Zabbix/Telegraf/exec checks, humans) |

```powershell
# Trend report from the summary file (fixed columns, any mix of runs):
Get-Content Metrics\platform-summary.jsonl | ForEach-Object { $_ | ConvertFrom-Json } |
  Select-Object timestamp, overallStatus, cpuAvg, memPct, worstDiskPct, peersDown |
  Export-Csv trend.csv -NoTypeInformation
```

### Reporting Section

Controls HTML report generation.

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `reporting.outputPath` | string | `""` (defaults to `$PSScriptRoot`) | Directory or file path for HTML reports. Pass a path ending in `.html` for an exact filename; a directory (must already exist) gets a timestamped file |
| `reporting.title` | string | `"CyberArk Platform Health Report"` | Report title text |
| `reporting.includeForecasting` | bool | `true` | Include capacity forecasting section |
| `reporting.forecastMinSpanHours` | int | `24` | Minimum span of collected history before a capacity forecast is produced. Below this, each metric shows `N/A` with an INFO note. Prevents extrapolating a daily growth rate from a few minutes of jitter (which manufactures false "URGENT" projections) |

### Logging Section

Controls the log file output.

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `logging.level` | string | `"Info"` | Log verbosity: Debug, Info, Warn, Error |
| `logging.path` | string | `""` (defaults to `$PSScriptRoot\Logs`) | Directory for log files |
| `logging.maxSizeMB` | int | `50` | Rotate log files larger than this |

### Dashboard Section

Controls the interactive dashboard.

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `dashboard.refreshSeconds` | int | `5` | Dashboard refresh interval in seconds |

## Service Baseline Configuration

The service baseline system learns expected service states and alerts when they change unexpectedly. This is particularly useful for CPM failover scenarios.

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `serviceBaseline.stabilizationMinutes` | int | `30` | How long a new state must persist before the baseline auto-adapts |
| `serviceBaseline.autoAdapt` | bool | `true` | Automatically update baseline when a service stabilizes in a new state |
| `serviceBaseline.expectedStates` | object | `{}` | Pre-declare expected states per service name |
| `serviceBaseline.additionalServices` | array | `[]` | Non-CyberArk services to include in monitoring |
| `serviceBaseline.autoRestart` | bool | `true` | **Self-heal master kill switch.** Set `false` to disable auto-restart entirely (inert while the allowlist below is empty regardless) |
| `serviceBaseline.autoRestartServices` | array | `[]` | **Required allowlist.** Empty (the default) = self-heal **inactive** (nothing is restarted; the run logs why). Only the named services are ever auto-restarted — an explicit, change-controlled opt-in per service |
| `serviceBaseline.autoRestartExclude` | array | `[]` | Allowlisted services that must **never** be auto-restarted (belt-and-suspenders alongside `expectedStates`) |
| `serviceBaseline.maxRestartsPerDay` | int | `3` | Per-service cap on restart attempts per calendar day, to stop a crash-looping service from being restarted (and paged) endlessly |

### Pre-declared Expected States

For passive/DR servers where services are intentionally stopped, declare the expected state in config rather than waiting for auto-baseline:

```json
{
    "serviceBaseline": {
        "expectedStates": {
            "CyberArk Password Manager": "Stopped",
            "CyberArk Central Policy Manager Scanner": "Stopped"
        },
        "additionalServices": [
            "W3SVC",
            "CyberArkScheduledTasksService"
        ]
    }
}
```

### Baseline Behavior

1. **First observation**: If no baseline exists for a service, the tool records the current state. If a config-declared expectedState exists, it uses that instead.
2. **State change**: When a service departs from its baseline state, the tool logs a warning and marks the transition timestamp.
3. **Stabilization**: If the new state persists for `stabilizationMinutes` (default: 30) and `autoAdapt` is true, the baseline is updated to the new state.
4. **Manual baseline**: Running with `-Baseline` forces the tool to re-learn all services using their current states immediately.

### Service Self-Heal (Auto-Restart)

Detection alone doesn't fix an outage. Self-heal is **strictly opt-in per service**: `autoRestartServices` is a required allowlist, and only a service that was **Running and then unexpectedly Stopped** (baseline-aware) is restarted. Automatic remediation on privileged infrastructure must be a deliberate per-service decision — an empty list silently restarting a Vault/DR/CPM that an admin stopped for maintenance is an incident generator, not a feature. This runs only in **Scheduled** and **Monitor** modes — never in read-only **Report** mode.

```json
{
    "serviceBaseline": {
        "autoRestart": true,
        "additionalServices": ["Spooler"],
        "autoRestartServices": ["Spooler"],
        "autoRestartExclude": [],
        "expectedStates": { "CyberArk Vault Disaster Recovery": "Stopped" },
        "maxRestartsPerDay": 3
    },
    "alerting": {
        "enabled": true,
        "smtp": { "server": "smtp.corp.local", "port": 25, "from": "cyberark-monitor@corp.local" },
        "defaults": { "notifyTo": ["pam-oncall@corp.local"] }
    }
}
```

Behavior on each run:

1. **Scope** — only services named in `autoRestartServices` are eligible. An empty allowlist = self-heal inactive (the run logs which stopped services it left alone). `autoRestart: false` is the master kill switch.
2. **Unexpected-stop only** — the service must be an allowlisted service whose baseline was `Running` and is now `Stopped` (a genuine outage). A service declared `Stopped` in `expectedStates` or listed in `autoRestartExclude` is never touched, and a service pinned Stopped by the adaptive baseline is left alone.
3. **Restart** — for each eligible Stopped service, `Start-Service` is issued and the tool waits up to 20 seconds for `Running`; further attempts follow an escalating backoff until it recovers.
4. **Daily cap** — each attempt increments a per-service counter in `platform-state.json` (`serviceRestarts`); once `maxRestartsPerDay` is reached the service is left alone (and a "cap reached" email is sent) until the next calendar day. This prevents restart storms on a crash-looping service.
5. **Notification** — every attempt emails the outcome (**success**, **failure**, or **cap reached**) to `alerting.defaults.notifyTo`. The restart itself happens regardless of `alerting.enabled`; only the email honors `-NoAlerts` and SMTP configuration.

> Auto-restart is remediation, not just alerting — treat `autoRestartServices` as a change-controlled list of services that are genuinely safe to restart in place. Services with complex dependencies or ordering requirements should be left off the allowlist.

## PVWA / IIS Health

Local health of the PVWA web layer (no REST/auth) via IIS. The collector auto-skips (Status `NotInstalled`) on a host with no PVWA, so it is safe to leave enabled everywhere. Runs in the Cool tier by default; disable per-run with `-SkipPVWA`.

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `pvwaHealth.appPoolName` | string | `"PasswordVault"` | IIS application pool to inspect (state, worker processes, recycle events) |
| `pvwaHealth.siteName` | string | `"PasswordVault"` | IIS website for HTTPS-binding and log-size checks |
| `pvwaHealth.installPath` | string | `"C:\inetpub\wwwroot\PasswordVault"` | Filesystem marker used (with the registry key) to decide PVWA is present |
| `pvwaHealth.registryPath` | string | `HKLM:\SOFTWARE\Wow6432Node\CyberArk\CyberArk Password Vault Web Access` | Registry marker for PVWA presence |
| `pvwaHealth.iisServiceName` | string | `"W3SVC"` | IIS service checked for Running state |
| `pvwaHealth.recycleWarnCount` | int | `3` | More than this many app-pool recycles in the last 24h → Warning |
| `pvwaHealth.memoryWarnMB` | int | `4096` | Total `w3wp` working set above this (MB) → Warning (0 disables) |

Data sources: `Get-Service W3SVC`, `IIS:\AppPools\<name>` state (WebAdministration), `w3wp` worker count + `WorkingSet64`, System-log event IDs **5074/5075** (app-pool recycles, filtered to the pool), the site's HTTPS binding, and IIS log-directory size. When the `WebAdministration` module isn't present the collector falls back to a service-only check (`FallbackMode`). Status maps: OK / Warning (transitional pool, excess recycles, high memory) / Critical (IIS or app pool down).

## CPM / PSM Local Sub-Checks

The CPM and PSM collectors run extra local, no-API sub-checks (only when the component is present — they inherit the collector's `NotInstalled` gate).

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `cpmHealth.pluginsPath` | string | `""` (auto) | CPM plugin folder. Auto: `InstallPath\bin\Plugins` (registry) → default. Reports plugin count and flags zero-byte (corrupt) plugins → Warning |
| `psmHealth.componentsPath` | string | `""` (auto) | PSM Components folder. Parses each `*.ini` connection component and checks the referenced `ClientApp`/`BrowserPath` executable exists → Warning on any missing |
| `psmHealth.recordingsPath` | string | `""` (auto) | PSM recordings folder. Auto: `InstallLocation\Recordings` → default. Reports free space + pending-upload count + oldest-pending age |
| `psmHealth.recordingWarnGB` | int | `10` | Recordings-volume free space at/below this → Warning |
| `psmHealth.recordingCriticalGB` | int | `2` | Recordings-volume free space at/below this → Critical |

These surface in the CPM/PSM report sections and JSONL records (`PluginTotal`/`PluginUnhealthy`, `ConnComponentsTotal`/`ConnComponentsInvalid`, `RecordingStatus`/`RecordingFreeGB`/`RecordingPendingCount`).

## CyberArk Log Scan

A generic, local error-code scanner across CyberArk log formats — Vault `ITALog` (`ITATS…E/W`), CPM (`CACPM…E/W`), Connector Manager `BLServiceApp.log` (`BLSERVICE…E/W`), and PVWA `log4net`. For each configured source whose file exists it tails the last `tailLines` lines and counts ERROR/WARN severities (CyberArk error codes are authoritative; otherwise a bracketed/pipe/thread-delimited level token). A source with no file present is skipped; if **no** source file exists the collector reports `NotInstalled`. Disable per-run with `-SkipLogScan`.

> These are **recent-tail counts** — a lightweight signal, not a strict time-windowed analysis. For deep correlation/anomaly analytics use the `CA.LogAnalysis` module.

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `logScan.tailLines` | int | `1000` | Lines to read from the end of each log |
| `logScan.warnCount` | int | `1` | Total errors (across sources) at/above this → Warning |
| `logScan.criticalCount` | int | `25` | Errors in a **single** source at/above this → Critical |
| `logScan.sources` | array | Vault / ConnectorManager / PVWA | Each `{ name, format, paths[] }`; the first existing path is scanned. Add sources or edit `paths` for your install layout |

Report/JSONL expose per-source `{Name, Format, Found, ErrorCount, WarnCount, Path}` plus `TotalErrors`/`TotalWarnings`.

## Collection Tiers

Tiers group collectors by how frequently they need to run. Each tier is defined in the `tiers` section of the config.

```json
{
    "tiers": {
        "hot":  { "intervalMinutes": 1,  "collectors": ["SystemHealth", "ServerCapacity"] },
        "warm": { "intervalMinutes": 5,  "collectors": ["ServiceStatus", "Connectivity"] },
        "cool": { "intervalMinutes": 15, "collectors": ["CPMHealth", "PSMHealth", "CertificateHealth", "WebDriverHealth"] }
    }
}
```

| Tier | Default Interval | Collectors | Rationale |
|------|-----------------|------------|-----------|
| Hot | 1 minute | SystemHealth, ServerCapacity | CPU/memory spikes and connection surges happen fast |
| Warm | 5 minutes | ServiceStatus, Connectivity | Service flaps and network drops are medium-speed events |
| Cool | 15 minutes | CPMHealth, PSMHealth, CertificateHealth, WebDriverHealth | Log parsing and certificate checks are slow-moving |

### Customizing Tier Assignments

You can move collectors between tiers by editing the `collectors` arrays. For example, to check services every minute instead of every 5 minutes:

```json
{
    "tiers": {
        "hot":  { "intervalMinutes": 1,  "collectors": ["SystemHealth", "ServerCapacity", "ServiceStatus"] },
        "warm": { "intervalMinutes": 5,  "collectors": ["Connectivity"] },
        "cool": { "intervalMinutes": 15, "collectors": ["CPMHealth", "PSMHealth", "CertificateHealth", "WebDriverHealth"] }
    }
}
```

> **Caution**: Moving log-parsing collectors (CPMHealth, PSMHealth) to the Hot tier will increase I/O load. The `logTailLines` and `logLookbackMinutes` settings help limit the impact, but keep these in Cool tier for production servers.

## Threshold Tuning

Thresholds are evaluated in two places:

1. **Per-collector thresholds** (in `thresholds` section) -- used by the collectors themselves to generate alert records.
2. **Per-requirement thresholds** (in `monitoring-requirements.json`) -- used by the requirements evaluation engine with the alert state machine.

When both exist, requirements take precedence for alerting purposes. The collector thresholds still drive the health status badges in the HTML report.

### Tuning for High-Load Environments

For CyberArk environments with high account counts (50,000+), you may need to raise CPM-related thresholds:

```json
{
    "thresholds": {
        "cpuWarningPercent": 85,
        "cpuCriticalPercent": 98,
        "cpmErrorWarning": 5,
        "cpmErrorCritical": 25
    }
}
```

## Monitoring Requirements

The `monitoring-requirements.json` file maps business SLA requirements to technical checks. It is auto-created with 5 default requirements on first run.

**Requirements search order** (first match wins):

1. `-RequirementsPath` parameter (explicit)
2. `$PSScriptRoot\monitoring-requirements.json`
3. `$env:USERPROFILE\.cyberark\monitoring-requirements.json`

### Default Requirements

| ID | Name | Collector | Metric | Tier | Direction | Warn | Crit |
|----|------|-----------|--------|------|-----------|------|------|
| REQ-001 | CPU Utilization | SystemHealth | CPU.Average | Hot | HigherIsBad | 80 | 95 |
| REQ-002 | Memory Utilization | SystemHealth | Memory.UsedPercent | Hot | HigherIsBad | 85 | 95 |
| REQ-003 | Vault Service Running | ServiceStatus | Services.Status | Warm | Equals:Running | -- | NotRunning |
| REQ-004 | Vault Connectivity | Connectivity | Reachable | Warm | Equals:True | -- | False |
| REQ-005 | Certificate Expiry | CertificateHealth | MinDaysToExpiry | Cool | LowerIsBad | 30 | 7 |

### Requirement Schema

Each requirement object has the following fields:

```json
{
    "id": "REQ-006",
    "name": "Disk Space - C Drive",
    "description": "C: drive must not exceed warning/critical thresholds",
    "enabled": true,
    "collector": "SystemHealth",
    "metricPath": "Disks.UsedPercent",
    "filter": { "field": "DriveLetter", "value": "C:" },
    "direction": "HigherIsBad",
    "warningThreshold": 80,
    "criticalThreshold": 95,
    "tier": "Hot",
    "sla": "Disk usage below 80% on all drives",
    "runbookUrl": "https://wiki.corp.local/runbooks/disk-cleanup",
    "notification": {
        "notifyTo": ["infra-team@corp.local"],
        "escalateTo": ["pam-lead@corp.local"]
    }
}
```

| Field | Type | Description |
|-------|------|-------------|
| `id` | string | Unique identifier (convention: REQ-NNN) |
| `name` | string | Human-readable name |
| `description` | string | What this requirement checks |
| `enabled` | bool | Set to false to disable without deleting |
| `collector` | string | Which collector provides the data |
| `metricPath` | string | Dot-path to the metric value within collector output |
| `filter` | object/null | Optional filter for array data (field + value) |
| `direction` | string | `HigherIsBad`, `LowerIsBad`, or `Equals` |
| `warningThreshold` | number/null | Warning level |
| `criticalThreshold` | number/string | Critical level (string for Equals direction) |
| `tier` | string | Which tier this requirement belongs to |
| `sla` | string | Business SLA text (shown in reports and alert emails) |
| `runbookUrl` | string | Link to the relevant runbook (shown as button in alert emails) |
| `notification.notifyTo` | array | Email addresses for alerts |
| `notification.escalateTo` | array | Email addresses for escalations |

### Metric Path Syntax

The `metricPath` field supports three patterns:

- **Dot notation**: `CPU.Average` navigates `$result.CPU.Average`
- **Filtered array**: `Services.Status` with filter `{"field": "ServiceName", "value": "PrivateArk Server"}` finds the matching array element
- **Computed**: `MinDaysToExpiry` computes the minimum `DaysUntilExpiry` across all certificates

## SMTP Alerting Configuration

SMTP alerting is disabled by default. To enable it, set `alerting.enabled` to `true` and configure the SMTP server.

```json
{
    "alerting": {
        "enabled": true,
        "smtp": {
            "server": "smtp.corp.local",
            "port": 25,
            "from": "cyberark-monitor@corp.local",
            "useTls": false
        },
        "rules": {
            "cooldownMinutes": 30,
            "escalateAfterMinutes": 60,
            "suppressDuplicateMinutes": 15,
            "maxNotificationsPerAlert": 10
        },
        "digest": {
            "enabled": true,
            "time": "07:00",
            "recipients": ["pam-team@corp.local"],
            "sendOnlyIfIssues": false
        },
        "defaults": {
            "notifyTo": ["pam-oncall@corp.local"],
            "escalateTo": ["pam-lead@corp.local"]
        }
    }
}
```

> **Note**: SMTP uses `System.Net.Mail.SmtpClient` with a 10-second timeout. Port 25 with no authentication is the default. Set `useTls` to `true` for STARTTLS on port 587.

> **Anonymous SMTP only**: the sender does **not** authenticate (no username/password). It targets an internal relay/smarthost that accepts mail from the host by IP — the usual pattern on CyberArk component servers. Authenticated public relays (Gmail, SendGrid, Mailtrap, Brevo, etc.) will **not** work without adding credential support.
>
> **Testing without a real relay**: point `smtp.server` at a local mail *catcher* that accepts anonymous mail and shows you the message. Zero-install option with Python 3.10/3.11:
> ```
> python -m smtpd -c DebuggingServer -n localhost:2525   # prints received mail to the console
> ```
> Then set `smtp.server` = `127.0.0.1`, `smtp.port` = `2525`, `useTls` = `false` and trigger `-TestAlert` or a self-heal. (GUI catchers: Papercut SMTP or smtp4dev give a web inbox.) `Send-MonitorEmail` never throws — a failed send is logged as `[Warn] SMTP send failed: ...` and returns false; `-TestAlert` exits `1` on failure.

## Scheduling & Continuous Operation

The default run is **one-shot** (`-Report`). To run it repeatedly you have three options:

- **Scheduled task (recommended for servers):** `-RegisterTasks` (run once, elevated) creates **one** Windows Task Scheduler job that runs a full `-Scheduled` collection (all tests) every `scheduling.intervalMinutes`, indefinitely, as SYSTEM. It **embeds the config/paths you passed at registration** (absolute), so the task runs exactly as you invoked it, and it prints the task name, command, interval, and next run time. Remove with `-UnregisterTasks`.
- **Continuous foreground poller:** `-Monitor` stays running and self-times each tier (Hot 1m / Warm 5m / Cool 15m); `Q` to quit.
- **Single manual run:** `-Scheduled` (headless, exit 0/1/2) or `-Report` (HTML).

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `scheduling.intervalMinutes` | int | `5` | Repeat interval for the `-RegisterTasks` task (override per-registration with `-IntervalMinutes`) |
| `scheduling.taskName` | string | `"CyberArk Platform Monitor"` | Scheduled-task name |

```powershell
# install: every 3 minutes, using this config/paths, as SYSTEM
.\Invoke-CAPlatformMonitor.ps1 -RegisterTasks -IntervalMinutes 3 -ConfigPath C:\CA\config.json -MetricsPath C:\CA\metrics -LogPath C:\CA\logs
.\Invoke-CAPlatformMonitor.ps1 -UnregisterTasks      # remove it
```

## Metrics Output (JSONL)

Metrics are append-only NDJSON at `Metrics\platform-metrics-YYYY-MM-DD.jsonl` — one JSON object per line, keyed by `recordType` (`CollectionMeta`, `SystemHealth`, `ServiceStatus`, `CPMHealth`, `PSMHealth`, `PVWAHealth`, `LogScan`, `Connectivity`, `WebDriverHealth`, `Alert`). The **format is identical across `-Report`/`-Scheduled`/`-Monitor`**; only which records appear varies by tier.

Each run also writes one flat, fixed-schema **`MetricSummary`** row for easy columnar/time-series parsing:

```json
{"recordType":"MetricSummary","timestamp":"...","host":"HIVE","mode":"Scheduled","tier":"All","overallStatus":"Critical","alertCount":3,"criticalCount":1,"warningCount":2,"cpuCurrent":7.6,"cpuAvg":7.5,"cpuPeak":8.5,"memPct":53.7,"worstDiskPct":97.8,"uptimeDays":200.5,"servicesHealthy":9,"servicesTotal":9,"servicesStopped":0,"connectivityOk":1,"connectivityTotal":1,"durationMs":53243}
```

Parse just those with: `Get-Content *.jsonl | %{ $_|ConvertFrom-Json } | ? recordType -eq 'MetricSummary'`.

## Path Configuration

All paths in the config file are resolved relative to the script directory (`$PSScriptRoot`), not the current working directory. This is critical for scheduled task execution where the working directory may be `C:\Windows\System32`.

| Config Key | Default Resolution | CLI Override |
|------------|-------------------|-------------|
| `storage.metricsPath` | `$PSScriptRoot\Metrics` | `-MetricsPath` |
| `reporting.outputPath` | `$PSScriptRoot\` | `-OutputPath` |
| `logging.path` | `$PSScriptRoot\Logs` | `-LogPath` |

Example with explicit paths:

```json
{
    "storage": { "metricsPath": "D:\\CyberArkMonitor\\Metrics" },
    "reporting": { "outputPath": "D:\\CyberArkMonitor\\Reports" },
    "logging": { "path": "D:\\CyberArkMonitor\\Logs" }
}
```
