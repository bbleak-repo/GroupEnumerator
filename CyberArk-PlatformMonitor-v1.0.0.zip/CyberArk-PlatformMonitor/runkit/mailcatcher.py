import smtpd, asyncore, sys, os

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'captured-mail.txt')
# start clean
open(OUT, 'w').close()

class Catcher(smtpd.SMTPServer):
    def process_message(self, peer, mailfrom, rcpttos, data, **kw):
        if isinstance(data, bytes):
            data = data.decode('utf-8', 'replace')
        with open(OUT, 'a', encoding='utf-8') as f:
            f.write('========== CAPTURED MESSAGE ==========\n')
            f.write('MAIL FROM: %s\n' % mailfrom)
            f.write('RCPT TO:   %s\n' % ', '.join(rcpttos))
            f.write(data)
            f.write('\n\n')
        print('captured message from %s to %s' % (mailfrom, rcpttos), flush=True)
        return None

server = Catcher(('127.0.0.1', 2525), None)
print('mailcatcher listening on 127.0.0.1:2525 -> %s' % OUT, flush=True)
asyncore.loop()
