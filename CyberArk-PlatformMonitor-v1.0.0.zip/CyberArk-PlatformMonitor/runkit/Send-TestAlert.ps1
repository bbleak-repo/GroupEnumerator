# Sends a test alert email through the configured SMTP (127.0.0.1:2525).
# Start-MailCatcher.ps1 must be running in another window first.
$ErrorActionPreference = 'Stop'
$here   = $PSScriptRoot
$script = Join-Path (Split-Path $here -Parent) 'Invoke-CAPlatformMonitor.ps1'
$out    = Join-Path $here 'out'
New-Item -ItemType Directory -Force -Path $out | Out-Null

& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $script -TestAlert `
    -ConfigPath       (Join-Path $here 'config.json') `
    -RequirementsPath (Join-Path $here 'monitoring-requirements.json') `
    -LogPath          (Join-Path $out 'logs') `
    -StatePath        (Join-Path $out 'state.json')

Write-Host "`nExit code: $LASTEXITCODE  (0 = sent OK to the catcher; 1 = send failed)"
Write-Host "Check captured-mail.txt for the message."
