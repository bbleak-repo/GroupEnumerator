# One-shot health report using the run-kit config. Writes everything under .\out
# and opens the HTML report. (Report mode does NOT send email -- use
# Send-TestAlert.ps1 or Demo-SelfHeal.ps1 for the mail path.)
$ErrorActionPreference = 'Stop'
$here   = $PSScriptRoot
$script = Join-Path (Split-Path $here -Parent) 'Invoke-CAPlatformMonitor.ps1'
$out    = Join-Path $here 'out'
New-Item -ItemType Directory -Force -Path $out | Out-Null
$report = Join-Path $out 'PlatformHealthReport.html'

& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $script -Report `
    -ConfigPath       (Join-Path $here 'config.json') `
    -RequirementsPath (Join-Path $here 'monitoring-requirements.json') `
    -OutputPath       $report `
    -MetricsPath      (Join-Path $out 'metrics') `
    -LogPath          (Join-Path $out 'logs') `
    -StatePath        (Join-Path $out 'state.json')

Write-Host "`nExit code: $LASTEXITCODE  (0=OK, 1=Warning, 2=Critical -- 2 is expected: C: is full)"
if (Test-Path $report) { Start-Process $report }
