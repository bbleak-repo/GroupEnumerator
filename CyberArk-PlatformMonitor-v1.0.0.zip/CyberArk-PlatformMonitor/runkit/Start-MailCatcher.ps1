# Starts a local SMTP catcher on 127.0.0.1:2525 that writes every received
# message to captured-mail.txt (next to this script). Leave this window open.
# Ctrl+C to stop. Requires Python 3.10/3.11 (uses the built-in smtpd module).
$ErrorActionPreference = 'Stop'
$py = 'C:\Program Files\Python310\python.exe'
if (-not (Test-Path $py)) { $py = (Get-Command python -ErrorAction Stop).Source }
$catcher = Join-Path $PSScriptRoot 'mailcatcher.py'
Write-Host "Mail catcher listening on 127.0.0.1:2525"
Write-Host "Captured mail -> $(Join-Path $PSScriptRoot 'captured-mail.txt')"
Write-Host "(leave this window open; Ctrl+C to stop)`n"
& $py -u $catcher
