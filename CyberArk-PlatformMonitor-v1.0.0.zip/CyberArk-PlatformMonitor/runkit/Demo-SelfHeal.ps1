# Self-heal demo: stops Print Spooler, runs a Scheduled (Warm-tier) collection,
# which detects the unexpected stop, RESTARTS Spooler, and emails the outcome.
# Start-MailCatcher.ps1 must be running in another window first. Run as Administrator.
$ErrorActionPreference = 'Stop'
$here   = $PSScriptRoot
$script = Join-Path (Split-Path $here -Parent) 'Invoke-CAPlatformMonitor.ps1'
$out    = Join-Path $here 'out'
New-Item -ItemType Directory -Force -Path $out | Out-Null

$common = @(
    '-NoProfile','-ExecutionPolicy','Bypass','-File',$script,'-Scheduled','-Tier','Warm',
    '-ConfigPath',(Join-Path $here 'config.json'),
    '-RequirementsPath',(Join-Path $here 'monitoring-requirements.json'),
    '-MetricsPath',(Join-Path $out 'metrics'),
    '-LogPath',(Join-Path $out 'logs'),
    '-StatePath',(Join-Path $out 'state.json')
)

Write-Host "1) Baseline run (learns Spooler = Running)..."
Start-Process powershell.exe -ArgumentList $common -Wait -WindowStyle Hidden

Write-Host "2) Stopping Print Spooler..."
Stop-Service Spooler -Force
(Get-Service Spooler).WaitForStatus('Stopped','00:00:20')
Write-Host ("   Spooler is now: {0}" -f (Get-Service Spooler).Status)

Write-Host "3) Monitoring run -> should auto-restart Spooler + email the outcome..."
Start-Process powershell.exe -ArgumentList $common -Wait -WindowStyle Hidden

Write-Host ("   Spooler is now: {0}" -f (Get-Service Spooler).Status)
Write-Host "`nDone. Check captured-mail.txt for the '[Self-Heal] Spooler restart SUCCESS' email,"
Write-Host "and out\logs for the [AutoRestart] lines. (config caps at 2 restarts/day.)"
