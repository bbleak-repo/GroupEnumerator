# Platform Monitor — local run kit

Configs + a local mail catcher for exercising the monitor on any Windows box.
Everything points at the sibling script `..\Invoke-CAPlatformMonitor.ps1`
(resolved relative to this folder) and writes all output under `.\out\`
(gitignored), so nothing here touches the repo or requires CyberArk to be
installed.

## Files
- `config.json` — 9 real Windows services, connectivity to `127.0.0.1:135`,
  SMTP → `127.0.0.1:2525`, self-heal allowlist `Spooler` (cap 2/day).
  Change `alerting.defaults.notifyTo` to your address (the catcher captures any
  recipient regardless).
- `monitoring-requirements.json` — default SLA requirements.
- `mailcatcher.py` — local SMTP sink on `127.0.0.1:2525` → `captured-mail.txt`.
- `Start-MailCatcher.ps1`, `Run-Report.ps1`, `Run-Monitor.ps1`, `Send-TestAlert.ps1`, `Demo-SelfHeal.ps1`.

## One-shot vs continuous vs scheduled

The default (`-Report`) runs **once and exits** — that's by design (it's what a
scheduled task calls). To keep it running and polling, you have two options:

- **Continuous foreground poller** — `.\Run-Monitor.ps1` (wraps `-Monitor`).
  Stays running, polls Hot every 1 min / Warm 5 min / Cool 15 min; press **Q** to stop.
- **Windows Task Scheduler** — from the script's own folder, run once as admin:
  `..\Invoke-CAPlatformMonitor.ps1 -RegisterTasks`. That installs three SYSTEM
  tasks (Hot/Warm/Cool) that each call `-Scheduled -Tier <t>` on a repeating
  interval. Remove them with `-UnregisterTasks`.

## Quick start (run PowerShell **as Administrator**)

```powershell
cd <repo>\Tools\runkit
.\Start-MailCatcher.ps1     # window 1 — leave open (listens on 127.0.0.1:2525)
```
```powershell
cd <repo>\Tools\runkit      # window 2
.\Run-Report.ps1           # full health report (opens the HTML)
.\Send-TestAlert.ps1       # delivers a test email -> captured-mail.txt
.\Demo-SelfHeal.ps1        # stops Spooler -> auto-restart + "[Self-Heal] SUCCESS" email
```

On a non-CyberArk host the report is expected to show **Critical** only if a
disk is genuinely full; the CPM/PSM/PVWA/WebDriver/LogScan collectors report
"not installed on this host (skipped)".

## Notes
- Catcher port is **2525** (matches `config.json`). For MailHog (1025) or
  Papercut (25), change `alerting.smtp.port` to match.
- `Send-MonitorEmail` uses **anonymous** SMTP (no auth) — a local catcher or an
  internal relay works; Gmail/SendGrid/Mailtrap (auth required) will not.
- Run the script directly any time: `..\Invoke-CAPlatformMonitor.ps1 -Help`.
- `out\` and `captured-mail.txt` are gitignored (runtime artifacts).
