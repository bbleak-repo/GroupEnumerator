# CONTINUOUS monitor: stays running and polls each tier on its own interval
# (Hot 1m / Warm 5m / Cool 15m). Press Q in this window to stop. Output under .\out.
# This is the "launch it and let it poll" mode (vs Run-Report.ps1 which runs once).
$ErrorActionPreference = 'Stop'
$here   = $PSScriptRoot
$script = Join-Path (Split-Path $here -Parent) 'Invoke-CAPlatformMonitor.ps1'
$out    = Join-Path $here 'out'
New-Item -ItemType Directory -Force -Path $out | Out-Null

& powershell.exe -NoProfile -ExecutionPolicy Bypass -File $script -Monitor `
    -ConfigPath       (Join-Path $here 'config.json') `
    -RequirementsPath (Join-Path $here 'monitoring-requirements.json') `
    -MetricsPath      (Join-Path $out 'metrics') `
    -LogPath          (Join-Path $out 'logs') `
    -StatePath        (Join-Path $out 'state.json')
