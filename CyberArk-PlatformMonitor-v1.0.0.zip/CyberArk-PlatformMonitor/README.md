# CyberArk Platform Monitor &mdash; standalone bundle

Single-file, zero-dependency PowerShell 5.1 tool for **local** CyberArk platform
health. No CyberArk REST API, no authentication &mdash; it reads only local Windows
sources (services, event logs, registry, certificate stores, log files, perf
counters, TCP ports, filesystem). Runs harmlessly on plain Windows servers too:
each CyberArk-specific collector auto-detects its component and cleanly skips
(`NotInstalled`) when absent.

## Contents
| Path | What it is |
|------|-----------|
| `Invoke-CAPlatformMonitor.ps1` | The tool (this is all you need to deploy). |
| `platform-monitor-features.html` | One-page feature overview (open in a browser). |
| `PlatformMonitor.md` | Developer architecture reference. |
| `docs/playbook/` | Operator playbook (markdown + `PLATFORM-MONITOR-PLAYBOOK.html`). |
| `runkit/` | Ready-to-run configs + a local mail catcher + helper scripts. |

## Quick start
```powershell
# full option list
.\Invoke-CAPlatformMonitor.ps1 -h

# one-shot HTML health report (default)
.\Invoke-CAPlatformMonitor.ps1

# run it forever on a schedule (elevated): one task, all tests, every N minutes
.\Invoke-CAPlatformMonitor.ps1 -RegisterTasks -IntervalMinutes 5
.\Invoke-CAPlatformMonitor.ps1 -UnregisterTasks      # remove it
```

## Try the demos (in `runkit\`, run as Administrator)
```powershell
cd runkit
.\Start-MailCatcher.ps1     # window 1 - local SMTP sink on 127.0.0.1:2525
.\Run-Report.ps1           # window 2 - HTML report (opens it)
.\Send-TestAlert.ps1       # delivers a test email -> captured-mail.txt
.\Demo-SelfHeal.ps1        # stops Spooler -> auto-restart + "[Self-Heal] SUCCESS" email
.\Run-Monitor.ps1          # continuous poller (Q to quit)
```

## What it produces
- **HTML report** (`-Report`) &mdash; health gauge, KPI cards, per-collector tables, trends, forecasts, action items.
- **JSONL metrics** &mdash; `platform-metrics-YYYY-MM-DD.jsonl` (detail; zipped in place after 7 days, ~22:1), plus `platform-daily.jsonl` (**one flat row per day**, kept forever &mdash; the long-horizon trend source), `platform-summary.jsonl` (append-only per-run trend) and `platform-status.json` (current-state snapshot) for Nagios/Zabbix/`modstat`-style pollers.
- **Trend report** (`-TrendReport` / `-TrendCsv -TrendDays N`) &mdash; day-over-day and month-over-month HTML (status calendar, charts with min/max bands and thresholds, capacity forecasts) or CSV, straight from the daily rollup. Read-only; no collectors run.
- **Daily log** &mdash; `CA-PlatformMonitor-YYYY-MM-DD.log`, rolls at 10 MB and zips.
- **Email** &mdash; anonymous SMTP alerts, escalation, recovery, daily digest, and service self-heal notices.

See `docs/playbook/PLATFORM-MONITOR-PLAYBOOK.html` for the full operator guide.

_Built from CyberArkToolbox @ main 6a5b26a (v1.0.0)._
