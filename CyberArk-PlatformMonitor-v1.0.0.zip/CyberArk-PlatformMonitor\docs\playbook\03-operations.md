# Operations

## Report Mode

Report mode is the default operating mode. It runs all (or tier-filtered) collectors once, writes JSONL records, evaluates requirements, updates the state file, and produces a self-contained HTML report.

### Basic Usage

```powershell
# Default: report with all collectors
.\Invoke-CAPlatformMonitor.ps1

# Explicit report flag
.\Invoke-CAPlatformMonitor.ps1 -Report

# Skip slow collectors for a quick check
.\Invoke-CAPlatformMonitor.ps1 -Report -SkipCapacity -SkipWebDrivers

# Override thresholds for this run
.\Invoke-CAPlatformMonitor.ps1 -Report -CpuWarningPercent 70 -DiskCriticalPercent 90

# Custom output path
.\Invoke-CAPlatformMonitor.ps1 -Report -OutputPath "D:\Reports"

# Test on non-Windows with mock data
.\Invoke-CAPlatformMonitor.ps1 -Report -UseMockData
```

### Output Files

Report mode produces:

- **HTML report**: `PlatformHealthReport-YYYY-MM-DD_HHmmss.html` in the output directory
- **JSONL records**: Appended to `Metrics\platform-metrics-YYYY-MM-DD.jsonl`
- **State file**: `platform-state.json` updated with daily summaries
- **Log file**: `Logs\CA-PlatformMonitor-YYYY-MM-DD_HHmmss.log`

### Exit Codes

Report mode exits with a code reflecting the worst health status:

| Exit Code | Meaning |
|-----------|---------|
| 0 | All healthy |
| 1 | Warnings detected |
| 2 | Critical conditions detected |

## Scheduled Mode

Scheduled mode is designed for headless execution via Windows Task Scheduler. It suppresses console output (logs only), writes JSONL, evaluates requirements, processes the alert state machine, sends SMTP notifications, and exits with 0/1/2.

### Basic Usage

```powershell
# All collectors (backward compatible)
.\Invoke-CAPlatformMonitor.ps1 -Scheduled

# Tier-specific (recommended with 3-task deployment)
.\Invoke-CAPlatformMonitor.ps1 -Scheduled -Tier Hot
.\Invoke-CAPlatformMonitor.ps1 -Scheduled -Tier Warm
.\Invoke-CAPlatformMonitor.ps1 -Scheduled -Tier Cool

# Suppress alerting for a maintenance window
.\Invoke-CAPlatformMonitor.ps1 -Scheduled -NoAlerts

# With explicit vault address
.\Invoke-CAPlatformMonitor.ps1 -Scheduled -VaultAddress "vault01.corp.local"
```

### Scheduled Mode Pipeline

Each scheduled execution follows this pipeline:

1. Load config, requirements, and state
2. Set tier skip flags (if `-Tier` specified)
3. Run collectors for the active tier
4. Write JSONL records
5. Evaluate requirements against collection results
6. Process alert state machine (new alerts, reminders, escalations, recoveries)
7. Update daily summary rollup in state
8. Send SMTP notifications (unless `-NoAlerts`)
9. Check if daily digest is due (time + not already sent today)
10. Update last collection timestamp in state
11. Save state file (atomic write with mutex)
12. Rotate old JSONL files beyond retention days
13. Exit with 0/1/2

> **Important**: SMTP sends happen BEFORE the state save. If the send succeeds, `lastNotifiedAt` is updated in state. If the send fails, the alert will be retried on the next cycle.

## Interactive Mode

Interactive mode displays a live console dashboard with color-coded health status. It refreshes at a configurable interval and can be exited by pressing Q.

```powershell
# Default 5-second refresh
.\Invoke-CAPlatformMonitor.ps1 -Interactive

# Custom refresh interval
.\Invoke-CAPlatformMonitor.ps1 -Interactive -RefreshSeconds 10

# Simulation mode for non-Windows testing
.\Invoke-CAPlatformMonitor.ps1 -Interactive -DashboardSimulation
```

The dashboard displays:

- Server identification and uptime
- CPU/memory/disk gauges with threshold coloring
- Service status list (Running = green, Stopped = red, other = yellow)
- Connectivity check results
- Recent alerts summary
- Last refresh timestamp

Press **Q** to exit the dashboard cleanly.

> **Note**: Interactive mode writes JSONL records on each refresh cycle. Use `-SkipCapacity` if performance counter collection is too slow for your desired refresh rate.

## Monitor Mode

Monitor mode is the fourth operating mode, intended for continuous monitoring with automatic tier timer management. It runs in a loop, executing each tier's collectors when their interval elapses.

```powershell
# Monitor all tiers with their configured intervals
.\Invoke-CAPlatformMonitor.ps1 -Monitor

# Monitor a single tier only
.\Invoke-CAPlatformMonitor.ps1 -Monitor -Tier Hot

# Monitor with mock data for testing
.\Invoke-CAPlatformMonitor.ps1 -Monitor -UseMockData
```

Monitor mode manages per-tier timers internally:

- Hot tier fires every 1 minute
- Warm tier fires every 5 minutes
- Cool tier fires every 15 minutes

Each tier's collectors run independently when due. The loop checks every 100ms for key input (Q to exit) and timer expiry.

> **Tip**: Monitor mode is useful for testing the full pipeline (collection, requirements evaluation, alerting, state updates) in a single interactive session before deploying as scheduled tasks.

## Understanding the HTML Report

The HTML report is a self-contained file with embedded CSS. It includes these sections:

### Health Score

A single overall score (OK / Warning / Critical) based on the worst status across all collectors. Displayed as a color-coded badge at the top of the report.

### KPI Cards

Four summary cards showing:

- **Overall Status** -- worst case across all checks
- **Services** -- count of healthy vs total services
- **Certificates** -- count of expiring/expired certs
- **Alerts** -- number of active alerts

### System Health Section

CPU, memory, and disk details with utilization gauges. Shows current, average, and peak values.

### Service Status Table

All monitored CyberArk services with:

- Service name and status
- Start type (Automatic, Manual, Disabled)
- Restart count (from event log)
- MTTR (Mean Time To Recovery)
- Availability percentage
- Uptime hours

### Certificate Health Table

All CyberArk-related certificates from LocalMachine stores with expiry dates, risk levels, and days until expiry.

### Connectivity Results

TCP port check results for Vault and PSM servers with latency.

### Requirements Compliance Table

Each monitoring requirement with its current value, threshold, SLA text, and status badge. Includes 7-day sparkline trends when state data is available.

### Capacity Forecast

Linear regression forecasting for CPU, memory, and disk metrics. Shows projected days until each metric reaches its critical threshold based on historical trends.

### Trend Summary

Sparkline charts from daily summaries showing min/max/avg per metric over the past 7 days.

## Understanding JSONL Files

JSONL files contain one JSON record per line. Each record has a `recordType` field that identifies the data type.

| Record Type | Contents |
|------------|----------|
| `CollectionMeta` | Timestamp, server, tier, duration, overall status |
| `SystemHealth` | CPU, memory, disk, uptime, installed components |
| `ServiceStatus` | Service names, statuses, restart counts, MTTR |
| `CertificateHealth` | Certificate subjects, expiry dates, risk levels |
| `ServerCapacity` | Performance counters, disk I/O, connections |
| `CPMHealth` | Error count, error details, log path |
| `PSMHealth` | Service status, vault connectivity, error categories |
| `Connectivity` | Host, port, reachable, latency |
| `WebDriverHealth` | Browser, driver versions, compatibility |
| `Alert` | Severity, source, metric, threshold, timestamp |

### Querying JSONL with PowerShell

```powershell
# Read all records from today
$records = Get-Content "Metrics\platform-metrics-$(Get-Date -Format 'yyyy-MM-dd').jsonl" |
    ForEach-Object { $_ | ConvertFrom-Json }

# Filter for CPU data only
$cpuRecords = $records | Where-Object { $_.recordType -eq 'SystemHealth' }

# Get today's peak CPU
$peakCpu = $cpuRecords | ForEach-Object { $_.CPU.Average } |
    Measure-Object -Maximum | Select-Object -ExpandProperty Maximum

# Count alerts by severity
$records | Where-Object { $_.recordType -eq 'Alert' } |
    Group-Object severity | Select-Object Name, Count
```

### File Retention

JSONL files are automatically rotated when they exceed the `retentionDays` setting (default: 30 days). Rotation runs at the end of each collection cycle. Files are deleted based on their `LastWriteTime`.

> **Caution**: With Hot tier running at 1-minute intervals, each day generates approximately 2,000 JSONL records. At roughly 1-2 KB per record, daily file sizes are typically 2-4 MB.

## Understanding the State File

The `platform-state.json` file maintains rolling trends, active alerts, and alert history. It is updated atomically (write .tmp, rename) with cross-process mutex protection.

### State File Structure

```json
{
    "schemaVersion": "1.0",
    "lastModified": "2026-07-08T14:30:00.000Z",
    "lastCollection": {
        "hot": "2026-07-08T14:30:00.000Z",
        "warm": "2026-07-08T14:28:00.000Z",
        "cool": "2026-07-08T14:15:00.000Z"
    },
    "dailySummaries": {
        "2026-07-08": {
            "cpuAverage": { "min": 12.3, "max": 78.4, "avg": 34.2, "sum": 3420, "count": 100, "peakAt": "..." },
            "memoryUsed": { "min": 45.0, "max": 62.3, "avg": 52.1, "sum": 5210, "count": 100, "peakAt": "..." },
            "diskC": { "min": 48.0, "max": 50.2, "avg": 49.1, "sum": 4910, "count": 100, "peakAt": "..." }
        }
    },
    "activeAlerts": {},
    "alertHistory": [],
    "peaks": {
        "cpuAverage": { "value": 94.2, "timestamp": "2026-07-05T03:15:00.000Z" },
        "memoryUsed": { "value": 88.7, "timestamp": "2026-07-06T11:20:00.000Z" }
    },
    "digestLastSent": "2026-07-08T07:00:00.000Z",
    "serviceBaseline": {}
}
```

### Daily Summaries

Each metric in a daily summary tracks min, max, average, sum, count, and the timestamp of the peak. The rollup is incremental -- the tool updates these values on each collection without re-reading JSONL files.

Daily summaries are pruned to the `retentionDays` setting. Pruning runs after each daily summary update.

### Peaks

All-time peak records within the lifetime of the state file. Updated whenever a daily max exceeds the current peak. Peaks are never pruned.

### Querying the State File

```powershell
# Read the state
$state = Get-Content "platform-state.json" | ConvertFrom-Json

# Get peak CPU ever recorded
$state.peaks.cpuAverage

# Get last 7 days of CPU averages
$state.dailySummaries.PSObject.Properties |
    Sort-Object Name -Descending |
    Select-Object -First 7 |
    ForEach-Object { "$($_.Name): avg=$($_.Value.cpuAverage.avg)%, peak=$($_.Value.cpuAverage.max)%" }

# Check active alerts
$state.activeAlerts.PSObject.Properties | ForEach-Object {
    "$($_.Name): severity=$($_.Value.severity), since=$($_.Value.firstSeen)"
}
```

## Service Baseline in Practice

The service baseline system handles several real-world scenarios automatically.

### First Run

On the first run, the tool has no baseline. It records the current state of every discovered CyberArk service. If the config declares `expectedStates`, those are used instead of the observed state.

### CPM Failover Scenario

When a passive CPM is promoted to active:

1. Services change from Stopped to Running.
2. The baseline flags this as unexpected (warning logged).
3. If the new state persists for `stabilizationMinutes` (default: 30), the baseline auto-adapts.
4. No further alerts about these services.

### DR Activation

When a DR vault is activated, its services change from Stopped to Running. The same stabilization logic applies. To skip the stabilization wait during a planned DR test:

```powershell
.\Invoke-CAPlatformMonitor.ps1 -Baseline
```

This immediately re-baselines all services to their current state.

### Manual Baseline After Upgrade

After a CyberArk upgrade where service configurations may have changed:

```powershell
.\Invoke-CAPlatformMonitor.ps1 -Baseline
```

> **Best Practice**: Always run `-Baseline` after CyberArk upgrades, DR tests, or planned CPM failovers to prevent false alerts during the stabilization window.
