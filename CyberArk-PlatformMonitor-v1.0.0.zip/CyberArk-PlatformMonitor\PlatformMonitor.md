# Invoke-CAPlatformMonitor.ps1 — Developer Architecture Reference

> Purpose: everything a developer needs to navigate, modify, and extend the
> Platform Monitor **without re-reading the 8,600-line source**. Line numbers
> below are anchors as of v1.0.0 (2026-07-08 hardening pass); they drift with
> edits, so prefer navigating by `#region` name or function name — both are
> stable identifiers.

---

## 1. Why one monolithic file (and how it stays modular anyway)

The tool is a **single, zero-dependency PowerShell 5.1 script** on purpose:

- **Scheduled-task deployment.** The unit of deployment is one file copied to
  any CPM/PSM/PVWA/Vault host. `schtasks`/`Register-ScheduledTask` points at one
  path; there is no module install, no `$env:PSModulePath` state, no relative
  `Import-Module` that breaks when the task runs as `SYSTEM` with `C:\Windows\
  System32` as CWD. Every dot-sourcing/module split reintroduces a second file
  that can be missing, stale, or blocked by execution policy on a hardened host.
- **Hardened-host reality.** CyberArk component servers are locked down: no
  internet, no PSGallery, often AppLocker. "Copy one .ps1, register three
  tasks" survives all of that.
- **Version atomicity.** One file = one version. A monolith can never have a
  mixed-version module skew after a partial upgrade.

Modularity is preserved *inside* the file instead of across files:

- **31 `#region` blocks** act as the module boundaries (map in §2). Each region
  has one responsibility and a small public surface.
- **Collectors are a uniform plug-in contract** (§6): independent functions
  with isolated try/catch, a common result envelope, and a mock fallback.
- Regions only talk to each other through function calls and two shared
  script-scope singletons: `$script:Config` and `$script:PlatformState`.

If you ever *must* split it: the region boundaries below are the module cut
lines, and the Collection Orchestrator (§7) is the only place that knows about
all collectors.

---

## 2. File map (region → responsibility → key functions)

| Line~ | Region | Responsibility | Key functions |
|---|---|---|---|
| 263 | Help / First-Run Banner | CLI help text, first-run guidance | `Show-Help`, `Show-FirstRunBanner` |
| 344 | Strict Mode and Globals | `Set-StrictMode Latest`, `$ErrorActionPreference='Stop'`, script singletons, mode/tier resolution | — |
| 376 | Platform Detection | Windows check (mock data elsewhere) | `Test-IsWindowsPlatform` |
| 400 | Configuration | Defaults, JSON load + deep merge, CLI overrides | `Get-DefaultConfig`, `Import-MonitorConfig`, `Merge-JsonObjectIntoHashtable`, `Merge-ConfigWithParams` |
| 721 | Monitoring Requirements | SLA requirement objects (JSON) | `Get-DefaultRequirements`, `Import-MonitoringRequirements` |
| 915 | Platform State | Persistent cross-run state file, mutex, atomic writes | `Get-EmptyState`, `Import-PlatformState`, `Get-PSPropertySafe`, `Export-PlatformState` |
| 1238 | Tier Management | Hot/Warm/Cool collector sets, skip-flag mechanics | `Get-TierCollectors`, `Get-SkipFlagsForTier`, `Test-TierDue` |
| 1404 | Structured Logger | Leveled file+console logging, rotation | `Initialize-Logger`, `Write-Log`, `Write-Finding`, `Write-Section` |
| 1559 | JSONL Storage Engine | Append-only daily metrics files, retention | `Write-MetricRecord`, `Read-MetricRecords`, `Invoke-MetricsRotation` |
| 1701 | Threshold / Alert Engine | **Stateless** per-run threshold alerts | `Test-Threshold`, `New-Alert`, `Get-OverallHealthStatus` |
| 1816 | Requirements Evaluation Engine | Resolve metric paths, evaluate SLA requirements | `Resolve-MetricValue`, `Resolve-PropertyPath`, `Test-RequirementThreshold`, `Invoke-RequirementsEvaluation` |
| 2180 | Alert State Machine | **Stateful** alert lifecycle: dedup, cooldown, escalation, recovery, history | `Get-AlertKey`, `Update-AlertState`, `Move-AlertToHistory` |
| 2477 | Daily Summary Rollup | Incremental min/max/avg/sum/count per metric per day; peaks; trends | `Update-DailySummary`, `Invoke-DailySummaryPrune`, `Get-TrendData`, `Get-SparklineHtml` |
| 2822 | SMTP Email Engine | Never-throw email send + HTML bodies + digest | `Send-MonitorEmail`, `New-AlertEmailBody`, `New-RecoveryEmailBody`, `New-DigestEmailBody`, `Send-AlertNotifications`, `Test-DigestDue`, `Invoke-DailyDigest` |
| 3506 | Mock Data Generator | Realistic fixtures for all collectors + state | `Get-MockData` |
| 3898 | Installed Components Detection | Registry+service discovery of CyberArk components | `Get-InstalledComponents` |
| 3998 | System Health Collection | CPU/mem/disk/uptime via CIM + counters | `Collect-SystemHealth` |
| 4162 | Service Resiliency | Service status, adaptive baseline, restart/MTTR/availability | `Update-ServiceBaseline`, `Collect-ServiceResiliency` |
| 4562 | Certificate Health | CyberArk certs in LocalMachine stores, expiry risk | `Collect-CertificateHealth` |
| 4692 | Server Capacity | Perf counters, disk I/O, port connection counts | `Collect-ServerCapacity` |
| 4859 | CPM Health | `pm_error.log` tail-parse with patterns | `Get-CPMLogPath`, `Test-CPMLogEntry`, `Read-CPMErrors`, `Collect-CPMHealth` |
| 5068 | PSM Health | Service + `PSMConsole.log` shadow-user & categorized errors | `Get-PSMLogPath`, `Read-PSMShadowUserErrors`, `Get-PSMErrorCategory`, `Read-PSMCategorizedErrors`, `Collect-PSMHealth` |
| 5428 | Connectivity Tests | TCP/ICMP checks, retries, **farm peer grace machine** | `Test-PortConnectivity`, `Test-PingConnectivity`, `ConvertTo-FarmPeerSpec`, `Update-PeerStatus`, `Collect-Connectivity` |
| 5909 | WebDriver Health | Browser vs driver version compat, x86/x64 hash sync | `Get-BrowserInfo`, `Get-WebDriverInfo`, `Test-BrowserDriverCompatibility`, `Compare-WebDriverHash`, `Collect-WebDriverHealth` |
| ~6172 | PVWA Health | Local PVWA/IIS health (W3SVC, app pool, w3wp, recycles, binding) | `Collect-PVWAHealth` (uses `Test-CAComponentPresent`) |
| ~6260 | CyberArk Log Scan | Generic error-code scan across Vault ITALog / CPM CACPM / Connector-Mgr BLSERVICE / PVWA log4net; per-source, gated on file existence | `Get-CALogSeverityCounts`, `Collect-CALogScan` |
| 6179 | Collection Orchestrator | Runs enabled collectors, isolates failures, builds Alerts/Errors | `Invoke-MetricsCollection` |
| 6484 | Capacity Forecasting | Linear regression over JSONL history | `Get-CapacityForecast`, `Get-AllForecasts` |
| 6728 | Embedded CSS | Dark-theme design system (shared with Toolbox v4 reports) | `Get-ReportCSS` |
| 7179 | HTML Report Generator | StringBuilder report: gauge, KPI cards, tables, forecasts | `Get-StatusBadgeHtml`, `Get-BarHtml`, `New-PlatformHealthReport` |
| 7759 | Console Dashboard | Live NOC view (Simple mode: Clear-Host + Write-Host) | `Show-Dashboard`, `Write-DashboardTable`, `Write-DashboardHeader` |
| 8063 | Scheduled Task Helper | 3-tier schtask registration/removal + examples | `Register-MonitorTasks`, `Unregister-MonitorTasks`, `Show-ScheduledTaskHelp` |
| 8204 | Main Execution | Bootstrap, trap, early-exit flags, mode dispatch | `Write-CollectionToJSONL` + inline mode blocks |

---

## 3. Execution flow

```
param(...)                          # ~80 CLI parameters
  │
Help? ──> Show-Help, exit 0
  │
Set-StrictMode Latest; EAP=Stop     # region: Strict Mode and Globals
resolve $script:OperatingMode       # Monitor > Interactive > Scheduled > Report
resolve $script:CurrentTier         # -Tier or 'All'
Scheduled mode? -> console output suppressed (log only)
  │
[all function definitions]          # regions 263–8203; nothing executes
  │
=== Main Execution (region @ 8204) ===
$script:Config       = Import-MonitorConfig -ExplicitPath $ConfigPath
Merge-ConfigWithParams -Config ... -BoundParameters $PSBoundParameters
$script:UserSkipFlags = Skip* params the user explicitly passed   # for tier reset
Initialize-Logger
trap { log FATAL; best-effort Export-PlatformState; exit 2 }      # last resort
$script:Requirements  = Import-MonitoringRequirements  (or mock)
$script:PlatformState = Import-PlatformState           (or mock)
resolve $resolvedStatePath
  │
early exits: -RegisterTasks / -UnregisterTasks / -TestAlert / -DigestNow
  │
Get-SkipFlagsForTier (if -Tier given)
  │
switch ($script:OperatingMode)
  Interactive → Show-Dashboard (loop; -DashboardIterations caps for tests) → exit 0
  Report      → collect → JSONL → evaluate reqs → daily summary → save state
                → forecasts → HTML report → rotation → exit 0/1/2
  Scheduled   → collect → JSONL → evaluate reqs → Update-AlertState
                → daily summary → Send-AlertNotifications + digest (if enabled)
                → stamp lastCollection[tier] → save state → rotation → exit 0/1/2
  Monitor     → per-tier timers loop (1s tick): due tier → collect/evaluate/
                notify/save (per-tier try/catch keeps loop alive) → daily JSONL
                rotation on date change → Q key exits
```

**Exit codes** (Report/Scheduled): `0` OK, `1` Warning, `2` Critical — derived
from `CollectionMeta.overallStatus` (worst severity across `Alerts`). The
script-scope `trap` makes *any* unhandled failure exit `2`, so a broken monitor
is loudly distinguishable from a healthy run. `-TestAlert` exits `1` on send
failure.

---

## 4. Shared singletons and data files

### Script-scope singletons

| Variable | Set at | Meaning |
|---|---|---|
| `$script:Config` | bootstrap | merged config **hashtable** (nested hashtables; JSON leaves may be PSCustomObject — see §9) |
| `$script:PlatformState` | bootstrap | ordered hashtable, mutated in place by alert/baseline/peer/summary code, persisted via `Export-PlatformState` |
| `$script:Requirements` | bootstrap | array of requirement objects |
| `$script:OperatingMode`, `$script:CurrentTier` | globals region | mode dispatch; `CurrentTier` is *mutated per tier* inside Monitor mode |
| `$script:UserSkipFlags` | bootstrap | names of Skip* params the user passed — tier dispatch never resets these |
| `$script:LogFile`, `$script:LogLevelInt`, `$script:LogConsoleOut` | logger | logging sink state |
| `$script:CorrelationID` | globals | GUID stamped into every log/record/report of one run |

### On-disk files (all colocated with the script by default; every path overridable)

| File | Writer | Purpose |
|---|---|---|
| `ca-platform-monitor.json` | auto-created first run (at `-ConfigPath` if given) | config; **never overwritten once it exists**, even if corrupt |
| `monitoring-requirements.json` | auto-created first run | SLA requirements; same never-overwrite rule |
| `platform-state.json` | `Export-PlatformState` after each collection | cross-run state (schema below) |
| `Metrics\platform-metrics-YYYY-MM-DD.jsonl` | `Write-MetricRecord` | append-only DETAIL records; one JSON object per line; ~13/run (per-collector + per-target + alerts); retention via `Invoke-MetricsRotation` |
| `Metrics\platform-summary.jsonl` | `Write-SummaryOutputs` | **the trend file** (Nagios/modstat analog): ONE append-only file, ONE flat `MetricSummary` line per run, identical 35-field schema regardless of mode/tier (nulls where a collector didn't run). No date globbing, no type filtering — point a parser here. Age-trimmed in place by `Invoke-MetricsRotation` |
| `Metrics\platform-status.json` | `Write-SummaryOutputs` | **current-state snapshot** (Apache mod_status analog): the same flat record, pretty-printed, atomically overwritten every run. Any poller reads one small fixed-schema file for "state right now" |
| `Logs\CA-PlatformMonitor-<ts>.log` | `Write-Log` | human log, size-based rotation (`logging.maxSizeMB`) |
| `PlatformHealthReport-<ts>.html` | Report mode | self-contained dark-theme report (CSS embedded) |

Trend-parse example (fixed columns, works across any mix of tier/full runs):

```powershell
Get-Content Metrics\platform-summary.jsonl | ForEach-Object { $_ | ConvertFrom-Json } |
  Select-Object timestamp, tier, overallStatus, cpuAvg, memPct, worstDiskPct,
                servicesStopped, connectivityOk, peersDown, cpmErrors, logScanErrors |
  Export-Csv trend.csv -NoTypeInformation      # or Format-Table / jq -s
```

### `platform-state.json` schema (written depth-10)

```jsonc
{
  "schemaVersion": "1.0",
  "lastModified": "<UTC ISO>",
  "lastCollection": { "hot": "<UTC ISO>", "warm": null, "cool": null },
  "dailySummaries": {                     // pruned to storage.retentionDays
    "2026-07-08": {                       // LOCAL calendar day (intentional)
      "cpuAverage":   { "min": 1, "max": 9, "avg": 4.2, "sum": 42, "count": 10, "peakAt": "<UTC ISO>" },
      "memoryUsed":   { ... }, "diskC": { ... }, "connections1858": { ... }
    }
  },
  "activeAlerts": {                       // key = "<reqId>::<metricPath>"
    "REQ-001::CPU.Average": {
      "requirementId": "REQ-001", "severity": "Warning|Critical",
      "firstSeen": "...", "lastSeen": "...", "lastValue": 85,
      "occurrences": 12, "lastNotifiedAt": "...", "notificationsSent": 2,
      "escalated": false
    }
  },
  "alertHistory": [ /* resolved alerts, FIFO-capped at 500 */ ],
  "peaks": { "cpuAverage": { "value": 94.2, "timestamp": "..." } },
  "digestLastSent": "<UTC ISO>",
  "serviceBaseline": {                    // adaptive expected service states
    "CyberArk Password Manager": {
      "expectedState": "Running", "baselinedAt": "...",
      "stateChangedAt": null, "previousState": null, "notes": "..."
    }
  },
  "peerStatus": {                         // farm peer grace tracking (§6.7)
    "psm02.corp.local:3389": {
      "firstFailedAt": null, "lastOkAt": "...",
      "consecutiveFailures": 0, "confirmedDown": false, "lastError": null
    }
  }
}
```

**Concurrency:** reads *and* writes take the named mutex
`Global\CyberArkPlatformMonitorState` (10s timeout → skip save, never block a
collection). Writes go `.tmp` → `File.Replace` (falls back to delete+move on
volumes that reject Replace). Known accepted limitation: the mutex is not held
across a whole read-modify-write, so overlapping tier tasks can lose one
tier's in-memory update — sections are mostly disjoint, and holding the lock
through multi-second collections would starve the other tiers.

### JSONL record types

`CollectionMeta` (one per run: mode, tier, components, overallStatus,
alertCount, durationMs, correlationId) • `SystemHealth` • `ServiceStatus` •
`CertificateHealth` • `ServerCapacity` • `CPMHealth` • `PSMHealth` •
`PVWAHealth` • `LogScan` • `Connectivity` (one line per target) •
`WebDriverHealth` (one per browser) • `Alert` (stateless collection alerts) •
`MetricSummary` (one flat fixed-schema row per run via `New-MetricSummaryRecord`,
written every mode -- for columnar/time-series parsing). All timestamps UTC ISO-8601.
`Read-MetricRecords -RecordType X -LookbackDays N` is the only reader
(forecasting uses `SystemHealth` records).

`MetricSummary` fields (fixed schema; `$null` when that collector didn't run in
the tier): identity (`recordType, correlationId, timestamp, host, mode, tier`),
run outcome (`overallStatus, alertCount, criticalCount, warningCount,
durationMs`), system (`cpuCurrent, cpuAvg, cpuPeak, memPct, worstDiskPct,
uptimeDays`), services (`servicesHealthy, servicesTotal, servicesStopped`),
network (`connectivityOk, connectivityTotal, peersDown, peersSuspect`),
components (`certStatus, certExpiredCount, certCriticalCount, cpmStatus,
cpmErrors, psmStatus, psmSysErrors, pvwaStatus, logScanStatus, logScanErrors,
webDriverIncompat`). The same record is duplicated into the daily detail file,
appended to `platform-summary.jsonl`, and snapshotted to `platform-status.json`
by `Write-SummaryOutputs`. Treat the schema as append-only: add new fields at
the end, never rename or remove (external parsers depend on it).

---

## 5. Configuration subsystem

- `Get-DefaultConfig` is the **single source of truth for the schema** — every
  key exists there with a sane default. Add new config keys here first.
- `Import-MonitorConfig` search order: `-ConfigPath` → script dir → 
  `%USERPROFILE%\.cyberark\`. JSON is merged **recursively** into the defaults
  hashtable (`Merge-JsonObjectIntoHashtable`), so a user config specifying only
  `alerting.smtp.server` keeps every other smtp default. Sections stay
  hashtables after merge; **JSON-only leaves can be PSCustomObject** (§9).
- Auto-creation of the default file happens **only when no config file exists
  anywhere**, and lands at `-ConfigPath` when one was given. Parse failures
  fall back to in-memory defaults with a warning; the broken file is preserved.
- `Merge-ConfigWithParams` applies CLI overrides. It **must receive the
  script's `$PSBoundParameters`** via `-BoundParameters` — inside a function,
  `$PSBoundParameters` only reflects that function's own parameters (this was
  the historical bug that silently disabled every CLI override).
- Config section highlights: `server`, `collection` (sample counts, service
  list), `connectivity` (vault/psm/farmPeers/retry/grace), `thresholds`,
  `serviceBaseline` (stabilizationMinutes, autoAdapt, expectedStates,
  autoRestartServices, maxRestartsPerDay),
  `storage`, `reporting` (+`forecastMinSpanHours`), `dashboard`, `logging`, `cpmHealth`/`psmHealth`
  (log discovery: registry → config → default path), `webDriver`, `pvwaHealth`
  (appPoolName/siteName/installPath/registryPath/recycleWarnCount), `logScan`
  (sources[]{name,format,paths}, warn/criticalCount), `scheduling`
  (intervalMinutes, taskName -- drives the single `-RegisterTasks` task), `tiers`,
  `alerting` (smtp / rules / digest / defaults).

---

## 6. The two alerting layers (do not conflate them)

### Layer 1 — stateless collection alerts (region: Threshold / Alert Engine)

Produced *during* `Invoke-MetricsCollection` by `Test-Threshold` /
`New-Alert`. They live only in `$results.Alerts` for that run, drive the
exit code and the report's Action Items, and are written to JSONL as `Alert`
records. No memory, no cooldown, no emails.

`Test-Threshold` is null-tolerant by contract: `$null`/non-numeric input
returns `$null` (no alert) rather than throwing — a typed `[double]` parameter
would abort the caller's whole try block at the call site.

### Layer 2 — stateful requirement alerts (regions: Requirements Evaluation + Alert State Machine)

Only runs in **Scheduled** and **Monitor** modes (Report evaluates but does not
notify). Pipeline:

```
requirements (JSON) ──Invoke-RequirementsEvaluation──> evaluations
        │  (Resolve-MetricValue navigates collector output:
        │   dot paths, array filters {field,value}, computed MinDaysToExpiry)
        ▼
Update-AlertState (state machine, mutates state.activeAlerts)
  eval Unknown  → SKIP ENTIRELY (never opens, never recovers — a transient
                  collection failure must not close a real alert)
  eval OK       → if active: Move-AlertToHistory + Recovery notification
  eval firing   → new: create entry + NewAlert notification
                  existing: bump occurrences/lastSeen; Warning→Critical upgrade;
                  time-based Escalation (escalateAfterMinutes, once);
                  Reminder when cooldownMinutes elapsed and
                  notificationsSent < maxNotificationsPerAlert
        ▼
Send-AlertNotifications
  recipients: requirement.notification.notifyTo/escalateTo
              → fallback alerting.defaults.*
  updates lastNotifiedAt/notificationsSent ONLY on successful send
```

Requirement schema (`monitoring-requirements.json`): `id`, `name`, `enabled`,
`collector`, `metricPath`, `filter` (`{field, value}` for array collectors),
`direction` (`HigherIsBad`|`LowerIsBad`|`Equals`), `warningThreshold`,
`criticalThreshold` (the *expected string* for `Equals`), `tier`, `sla`,
`runbookUrl`, `notification{notifyTo[],escalateTo[]}`.

### SMTP contract

`Send-MonitorEmail` **never throws**: no server configured, empty/null
recipients, or send failure → `Write-Log` Warn + `return $false`. This is what
keeps every mode functional on hosts with no SMTP (test-verified). The digest
(`Test-DigestDue`) fires at the first poll **at or after** the configured local
time, guarded by a sent-today check that converts the stored UTC
`digestLastSent` back to local date.

---

## 7. Collectors — the plug-in contract

Eight collectors, all invoked (or skipped) by `Invoke-MetricsCollection`.
Contract every collector honors:

1. **Mock/platform gate first:** `if ($UseMockData -or -not (Test-IsWindowsPlatform)) { return Get-MockData -DataType '<X>' }`.
2. **Own try/catch:** a real-collection failure returns an *error-shaped
   result* (`Status='Error'`, `ErrorMessage=...`) with the same property set —
   never throws to the orchestrator.
3. **Complete envelope:** every return path carries the same properties
   (StrictMode: consumers read fields unconditionally). Common fields:
   `Status`, `CheckedAt` (UTC ISO), `ServerName`, `CorrelationID`, `Duration`,
   `IsMockData`, `ErrorMessage`.
4. The orchestrator *additionally* wraps each call in try/catch (belt +
   suspenders) and records failures in `$results.Errors`.

| Collector | Source | Output shape (essentials) | Status values |
|---|---|---|---|
| `Collect-SystemHealth` | `Win32_OperatingSystem`, `Win32_LogicalDisk`, `Win32_ComputerSystem`, CPU counter (isolated: counter failure → zeros, not Error) | `CPU{Current,Average,Peak,Status}`, `Memory{TotalGB,AvailableGB,UsedPercent,Status}`, `Disks[]{DriveLetter,SizeGB,FreeGB,UsedPercent,Status}`, `InstalledComponents[]`, `UptimeDays` | OK/Warning/Critical/Error |
| `Collect-ServiceResiliency` | `Get-Service` over `collection.cyberArkServices` (+`serviceBaseline.additionalServices`), PID via `Win32_Service.ProcessId` (ServiceController has **no** Id), event 7036 for restarts/MTTR (English-text matching — known i18n limitation), adaptive baseline (§7.1) | `Services[]{ServiceName,Status,PID,MemoryMB,RestartCount,MTTR,AvailabilityPercent,IsExpectedState,BaselineState,BaselineTransition}` + counts | OK/Warning/Critical/Error — only **unexpected** stops are Critical |
| `Collect-CertificateHealth` | `Cert:\LocalMachine\My` + `\Root`, keyword match on Subject/Issuer (CyberArk/Privilege/Vault/DVCA/PrivateArk/PVWA/PSM/CPM) | `Certificates[]{Subject,Thumbprint,DaysUntilExpiry,RiskLevel,Store}` + counts | OK/Warning/Critical/Error |
| `Collect-ServerCapacity` | 4 perf counters (combined call; on failure falls back per-counter so one broken counter doesn't kill the rest), `Get-NetTCPConnection` on 1858/443/3389 | `CPU{...,HeadroomPercent}`, `Memory{...}`, `DiskIO{ReadBytesPerSec,WriteBytesPerSec,QueueLength}`, `NetworkConnections[]{Port,Count}` | OK/Warning/Critical/Error |
| `Collect-CPMHealth` | tail of `pm_error.log` (path: registry → config → default), regex `errorPatterns` minus `ignorePatterns` (each guarded — bad user regex is skipped, not fatal), lookback window; unparseable-timestamp lines are **excluded** (stamping "now" would re-alert forever). Sub-check `Get-CPMPluginHealth`: inventory `bin\Plugins` (`*.dll`/`*.exe`), flag zero-byte plugins → Warning | `Errors[]`, `ErrorCount`, `LogPath`, `LogPathSource`, `PluginTotal`, `PluginUnhealthy` | Healthy/Unhealthy/Error/**NotInstalled** |
| `Collect-PSMHealth` | PSM service status + `PSMConsole.log` tail: shadow-user patterns and Browser/RDP/SSH/User/Unknown categorization (`Get-PSMErrorCategory`); system errors (Browser+RDP+SSH) drive health, User errors are noise. Sub-checks: `Get-PSMConnectionComponentHealth` (parse `Components\*.ini`, verify `ClientApp`/`BrowserPath` exe exists) and `Get-PSMRecordingHealth` (Recordings free space + pending-upload backlog) | `ServiceStatus`, `ShadowUserErrors[]`, `SystemErrorCount`, `UserErrorCount`, `ErrorCategories`, `ConnComponentsTotal/Invalid`, `RecordingStatus/FreeGB/PendingCount` | Healthy/Unhealthy/Error/**NotInstalled** |
| `Collect-Connectivity` | TCP (`TcpClient.ConnectAsync` + wait, always disposed) and ICMP (`Ping`), in-run retries; vault + psmServers + `-ConnectivityPorts` + **farm peers** (§7.2) | array of `{Target,Port,Reachable,LatencyMs,Status,Description,Error,Attempts}`; peers add `IsFarmPeer`, `PeerState` | per-target Connected/Unreachable/Suspect/Down |
| `Collect-WebDriverHealth` | browser exe (registry App Paths → known paths) vs driver in PSM `Components\` — major-version compat (or strict), x86 vs `Components\64` SHA256 sync check. Skips (returns `@()`) when no PSM Components store exists | array per browser `{Browser,Compatible,BrowserVersion,DriverVersion,DriverExists,HashMatch,NeedsSync,Message}` | boolean-ish; orchestrator maps to Warning alerts |
| `Collect-PVWAHealth` | `W3SVC` service; `IIS:\AppPools\PasswordVault` state (WebAdministration); `w3wp` worker count + `WorkingSet64`; System event IDs 5074/5075 (app-pool recycles, 24h, filtered to pool); site HTTPS binding; IIS log-dir size. Gated on PVWA-specific markers (`pvwaHealth.registryPath`/`installPath`); `FallbackMode` = service-only when WebAdministration absent | `IISServiceStatus`, `AppPoolStatus`, `WorkerProcessCount`, `MemoryUsageMB`, `RecentRecycleCount`, `BindingStatus`, `LogFileSizeMB`, `FallbackMode` | OK/Warning/Critical/Error/**NotInstalled** |

### 7.1 Adaptive service baseline (`Update-ServiceBaseline`)

Distinguishes *expected* stops (passive CPM node, DR vault) from failures.
Per service in `state.serviceBaseline`:

- First observation → baseline = current state (or `serviceBaseline.
  expectedStates` from config wins); no alert.
- Observed ≠ baseline → `StateChange` (unexpected → counts toward Critical),
  stamps `stateChangedAt`.
- Still changed after `stabilizationMinutes` (default 30) with `autoAdapt` →
  baseline flips to the new state (`Stabilized`), alarm clears.
- `-Baseline` CLI switch force-relearns everything (`Baselined` transition —
  deliberately not reported as an anomaly).
- All timestamp math in UTC (`.ToUniversalTime()` after every `Parse` —
  mixing kinds inflates elapsed time by the UTC offset).

**Self-heal (`Invoke-ServiceAutoRestart`, Scheduled/Monitor only):** with
`serviceBaseline.autoRestart` true (default), any *monitored* service found
Stopped is restarted -- tracking a service is the opt-in; `autoRestartServices`
is an optional narrowing filter (empty = all monitored) and `autoRestartExclude`
/ `expectedStates=Stopped` exempt DR/passive nodes. The tool `Start-Service`s it,
waits up to 20s for Running, and emails the outcome (success / failure / cap-reached) to
`alerting.defaults.notifyTo`. A per-service per-day counter in
`state.serviceRestarts` enforces `maxRestartsPerDay` (default 3) against flap
storms. Report mode never restarts (read-only). The restart runs regardless of
`alerting.enabled`; only the outcome email honors `-NoAlerts`/SMTP config.

### 7.2 Farm peer monitoring (`ConvertTo-FarmPeerSpec` → checks → `Update-PeerStatus`)

Each server watches its peers so the farm needs no central poller:

- **Spec forms:** `"host"` (ICMP), `"host:3389"`, `"host:443,80"`, object
  `{host, ports[], ping}`. CLI single-string form uses `;` between peers
  (schtasks can't pass arrays): `-FarmPeers "psm01:3389;vault01:1858"`.
- **In-run retries:** `connectivity.retryCount` attempts (default 2),
  `retryDelaySeconds` apart — transient blips never even count as a failure.
- **Grace state machine** (per target key `host:port` / `host:icmp`, persisted
  in `state.peerStatus`):

```
           success                    failure
  ┌────────────────────┐   ┌──────────────────────────────┐
  OK ◄─────────────── Suspect ── (consecutiveFailures ≥ 2  ──► Down
  ▲   (within grace:    ▲         AND elapsed ≥ grace       │ Critical
  │    log only,        │         peerDownGraceSeconds,     │ 'Farm Peer Down'
  │    NO alert,        │         default 150s)             │ alert, exit 2
  │    exit stays 0)    └──── failure (still in grace) ─────┘
  └── 'Recovered' logged; state reset ◄── success while Down
```

- The orchestrator alerts **only** on `PeerState -eq 'Down'`; Suspect peers
  appear as a WARN finding and in the report matrix (badge `Suspect`).
- Detection latency = check cadence × 2 bounded below by grace: with the Warm
  tier's 5-minute cadence, confirmation lands on the second failed check-in;
  move `Connectivity` to the Hot tier for ~2–3 minute detection.

---

## 8. Tiers, modes, and the skip-flag mechanism

- `tiers` config: `hot` (1m: SystemHealth, ServerCapacity), `warm` (5m:
  ServiceStatus, Connectivity), `cool` (15m: CPMHealth, PSMHealth,
  CertificateHealth, WebDriverHealth, PVWAHealth, LogScan). Names in `Get-TierCollectors
  $allCollectors` are the canonical collector IDs.
- **Skip-flag mechanism:** the orchestrator's guards are `if ($tierCollectors
  -contains 'X' -and -not $SkipX)`. `Get-SkipFlagsForTier` makes them
  tier-aware by setting script-scope `$SkipX` variables: `$true` for
  collectors outside the tier, **reset to `$false`** for collectors inside it
  *unless* the user passed that Skip switch on the CLI
  (`$script:UserSkipFlags`). The reset matters: without it, Monitor mode's
  first tier latched its skips and every later tier collected nothing.
- **Monitor mode** keeps per-tier timers (`lastRun` + interval), ticks every
  1s, runs due tiers sequentially in-process, per-tier try/catch (a failed
  tier stamps `lastRun` so it waits a full interval instead of hot-looping),
  daily JSONL rotation on date change, `Q` to quit (KeyAvailable guarded for
  non-interactive hosts).
- **Scheduled mode** is the one-shot equivalent driven by three registered
  schtasks (`Register-MonitorTasks`: SYSTEM, Highest, once + repetition
  interval). `Test-TierDue` exists for state-based due checks but the schtask
  cadence is the primary scheduler.

---

## 9. Coding invariants (the rules that 24 bugs taught us)

The script runs `Set-StrictMode -Version Latest` + `$ErrorActionPreference =
'Stop'`. **Every rule below exists because its violation was a real, observed
bug in this file.** Follow them for all new code:

1. **Never dot-access a property that might not exist** on a
   `ConvertFrom-Json` object — StrictMode throws `PropertyNotFoundStrict`.
   Use `Get-PSPropertySafe -Object $o -Name 'key'` (returns `$null` when
   absent). Hashtables are safe to index; PSCustomObjects are not.
2. **Hashtable vs PSCustomObject duality:** config/state sections created in
   code are hashtables; anything round-tripped through JSON is PSCustomObject.
   Any code that can receive either must branch (`$x -is [hashtable]`) or use
   `Get-PSPropertySafe`. This pattern is everywhere — keep it.
3. **`return @()` unrolls to `$null`** at the call site. Any caller that will
   read `.Count` (or index) must wrap: `$x = @(Some-Function ...)`.
4. **Never wrap an assignment in parentheses inside `$()`** —
   `$(($v = ...); ...)` EMITS the assigned value *and* the block result,
   silently producing arrays (this corrupted state files). Use
   `$($v = ...; if ...)`.
5. **UTC discipline:** persist UTC ISO-8601 (`(Get-Date).ToUniversalTime().
   ToString('o')`); after `[datetime]::Parse` of a stored value, call
   `.ToUniversalTime()` before subtracting from a UTC now. `dailySummaries`
   date keys are deliberately LOCAL calendar days; `Test-DigestDue` converts
   stored UTC to local before comparing days.
6. **Automatic variables are off-limits:** `$pid`, `$error`, `$matches`,
   `$input`, `$host`, `$sender`, `$profile` — assignment either throws
   (`$pid`) or shadows something PowerShell owns. `ServiceController` has no
   `.Id`; get service PIDs from `Win32_Service.ProcessId`.
7. **`if` is a statement, not an expression, inside `( )`.** As a cmdlet
   argument use `$(if (...) {...} else {...})` — plain parentheses make the
   parser look for a command named `if` (runtime error only).
8. **`$PSBoundParameters` is per-function.** To test script-level parameters
   inside a helper, pass the script's `$PSBoundParameters` in.
9. **Isolation contract:** collector failures must degrade, not propagate —
   own try/catch, error-shaped result with the full property set, per-metric
   isolation where possible (counters retry individually; one bad user regex
   is skipped; `Test-Threshold` swallows nulls).
10. **Never throw from the email path**; return `$true/$false` and log.
11. **Never overwrite user-owned files** (`ca-platform-monitor.json`,
    `monitoring-requirements.json`): auto-create only when nothing exists;
    on parse failure run with defaults and leave the file for the admin.
12. **External resources always disposed in `finally`** (TcpClient — including
    the still-running ConnectAsync on timeout; Ping; StreamReader/Writer;
    SmtpClient/MailMessage; Mutex release+dispose).
13. **Unknown ≠ OK, Unknown ≠ firing** in the alert state machine: an
    unevaluable metric changes nothing.
14. **PS 5.1 only:** no ternary, no `??`/`?.`, no pwsh-only cmdlet params.
    Culture-pin every `ParseExact` with `InvariantCulture`.
15. **Exit through the trap or an explicit `exit 0/1/2`** — never let an
    exception produce PowerShell's generic exit 1.
16. **State sub-objects are `OrderedDictionary`, not `[hashtable]`.** Anything
    restored by `Import-PlatformState` is built with `[ordered]@{}`, whose type
    is `System.Collections.Specialized.OrderedDictionary` — an `IDictionary`
    but **not** `[hashtable]`. Reading it with `$x -is [hashtable]` (falling
    back to `Get-PSPropertySafe`, which only reads *PSObject* properties) returns
    `$null` silently. Test `-is [System.Collections.IDictionary]` and index by
    key. (This reset the self-heal daily counter to 1 on every run until fixed.)

Known accepted limitations (documented, not bugs to "fix" casually):
event-7036 restart detection matches English message text (non-English SCM
locales report 0 restarts / 100% availability); CPM/PSM log reads rely on
default encoding detection; the state read-modify-write across concurrent
tiers is not fully transactional (see §4).

---

## 10. Extension recipes

### Add a new collector
1. Write `Collect-Xyz` following the §7 contract (mock gate, try/catch,
   complete envelope). Add a `Get-MockData -DataType 'Xyz'` fixture.
2. Register the name in `Get-TierCollectors`' `$allCollectors`, a tier's
   `collectors` list in `Get-DefaultConfig`, and the skip map in
   `Get-SkipFlagsForTier` (+ a `-SkipXyz` CLI switch if wanted).
3. Add an orchestrator block in `Invoke-MetricsCollection` (copy an existing
   one: guard, collect, `CollectionMeta.components +=`, threshold alerts,
   `Write-Finding`).
4. Emit JSONL in `Write-CollectionToJSONL` (add to `$recordTypes` if
   single-object, or a per-item loop if array).
5. Optional: report section in `New-PlatformHealthReport`, dashboard row,
   metric extraction in `Update-DailySummary`, requirement support in
   `Resolve-MetricValue`.

### Add a config key
Default in `Get-DefaultConfig` → (CLI param? add to `param()`, doc-comment,
`Merge-ConfigWithParams`, `Show-Help`) → consume via `$script:Config.section.key`
with rule-2 duality in mind → document in
`docs/playbook-platform-monitor/02-configuration.md`.

### Add a requirement metric path
`Resolve-MetricValue` handles: plain dot paths, `Connectivity` + filter,
`ServiceStatus` + filter, computed `MinDaysToExpiry`. New computed paths get an
explicit branch there; keep `Resolve-PropertyPath` generic.

---

## 11. Smoke-testing (isolated, no repo pollution)

```powershell
$pm = 'D:\some\sandbox'   # everything lands here, nothing beside the script
$common = @('-OutputPath',"$pm\reports",'-MetricsPath',"$pm\metrics",
            '-LogPath',"$pm\logs",'-ConfigPath',"$pm\ca-platform-monitor.json",
            '-StatePath',"$pm\platform-state.json",
            '-RequirementsPath',"$pm\monitoring-requirements.json")

.\Invoke-CAPlatformMonitor.ps1 -Report -UseMockData @common      # exit 2 expected (mock has 1 unreachable)
.\Invoke-CAPlatformMonitor.ps1 -Report @common                   # real one-shot
.\Invoke-CAPlatformMonitor.ps1 -Scheduled -Tier Hot @common      # headless, exit 0/1/2
.\Invoke-CAPlatformMonitor.ps1 -Interactive -DashboardSimulation -DashboardIterations 2 @common
.\Invoke-CAPlatformMonitor.ps1 -TestAlert @common                # no SMTP → logged failure, exit 1
.\Invoke-CAPlatformMonitor.ps1 -Scheduled @common `
    -FarmPeers "127.0.0.1:135;localhost" -PeerGraceSeconds 5     # peer machine exercise
```

Mock mode (`-UseMockData`) swaps in fixtures for all collectors *and* a
populated `MockPlatformState` (7 days of summaries, one active alert, history,
peaks) — enough to render every report/email section without a live host.
The parse gate for CI: `[System.Management.Automation.Language.Parser]::
ParseFile($path, [ref]$null, [ref]$errs)` must report zero errors, and
`Invoke-ScriptAnalyzer -Severity Error` must be clean.

---

## 12. Related files

- `docs/playbook-platform-monitor/00-overview.md` … `05-troubleshooting.md` —
  operator-facing playbook (deployment, configuration reference, operations,
  alerting, troubleshooting) + generated `PLATFORM-MONITOR-PLAYBOOK.html`.
- `Tools/Invoke-CALogAnalyzer*.ps1`, `Modules/CA.LogAnalysis/` — the log
  analysis siblings shipped in the same commit; independent of this tool.
- `Modules/CA.Monitoring/` — the *framework* monitoring module (GUI/dashboard
  stack). The Platform Monitor deliberately does not import it (§1).
