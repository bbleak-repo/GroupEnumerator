# CyberArk Platform Monitor -- Overview

## What This Tool Is

The CyberArk Platform Monitor (`Invoke-CAPlatformMonitor.ps1`) is a standalone, zero-dependency PowerShell script that monitors CyberArk infrastructure health from the local server. It does not make any CyberArk REST API calls and requires no authentication tokens. Everything it checks is local: WMI/CIM counters, Windows services, event logs, certificate stores, registry keys, log files, and TCP connectivity.

Key characteristics:

- **Single file** -- one `.ps1` file, no modules to install
- **Zero dependencies** -- uses only built-in PowerShell 5.1 cmdlets and .NET classes
- **Local only** -- reads from the server it runs on; no remote management plane
- **Safe on any Windows box** -- each CyberArk-specific collector auto-detects its component and reports *NotInstalled* (skips, no false alarms) when it isn't present
- **Mostly non-destructive** -- read-only collection by default; the one action is opt-in service **self-heal** (auto-restart of allowlisted services)
- **Cross-platform testing** -- `-UseMockData` flag generates realistic data on macOS/Linux

The tool is designed to be deployed alongside CyberArk components on each server in the estate: Vault, CPM, PSM, PVWA, and all-in-one lab environments -- and runs harmlessly on plain Windows servers too.

## What It Monitors

The monitor uses ten independent collectors. Each runs in isolation with its own try/catch boundary -- if one fails, the others still execute -- and each CyberArk-specific collector cleanly skips (`NotInstalled`) on a host where that component isn't present.

| Collector | What It Checks | Data Source |
|-----------|---------------|-------------|
| SystemHealth | CPU average/peak, memory, disk space (worst disk surfaced), uptime, installed CyberArk components | WMI/CIM (`Get-CimInstance`) |
| ServiceStatus | Service health, restart counts, MTTR, availability, adaptive baseline, optional **self-heal** restart | `Get-Service` + Windows Event Log |
| CertificateHealth | Certificate expiry for CyberArk-related certs in LocalMachine stores | `Cert:\LocalMachine\*` |
| ServerCapacity | Performance counters (CPU headroom, disk I/O, queue length), connection counts by port | `Get-Counter` + `Get-NetTCPConnection` |
| CPMHealth | CPM `pm_error.log` parsing + error counts, and **plugin inventory** (`bin\Plugins`) | Registry + file system |
| PSMHealth | PSM service + `PSMConsole.log` (shadow-user/categorized errors), **connection-component `.ini` validation**, **recording-storage backlog** | Service + files |
| Connectivity | TCP/ICMP to Vault (1858), PSM (3389), extra ports, and **farm peers** with a down-grace state machine | `System.Net.Sockets.TcpClient` / `Ping` |
| WebDriverHealth | Browser vs PSM-driver version compatibility and x86/x64 hash sync | Registry + file system |
| PVWAHealth | W3SVC, `PasswordVault` app-pool, `w3wp` memory, recycle events (5074/5075), HTTPS binding, IIS log size | Services + IIS + event log |
| LogScan | Error-code counts across Vault `ITALog`, CPM `CACPM`, Connector Mgr `BLSERVICE`, PVWA log4net | Local log files |

## Operating Modes

The tool supports four operating modes, each suited to a different use case.

| Mode | Flag | Use Case | Output |
|------|------|----------|--------|
| Report | `-Report` (default) | One-shot health check | HTML report + JSONL record |
| Scheduled | `-Scheduled` | Headless schtask execution | JSONL append + log file, exit code 0/1/2 |
| Interactive | `-Interactive` | Live console dashboard | Color-coded terminal display, optional JSONL |
| Monitor | `-Monitor` | Continuous loop with tier timers | JSONL + state updates, press Q to exit |

> **Tip**: Report mode is the default. Running the script with no flags produces an HTML report in the script directory.

To run it **recurring**, either register a scheduled task -- `-RegisterTasks` installs a single Windows task that runs a full `-Scheduled` collection every `scheduling.intervalMinutes` (embedding your config/paths, as SYSTEM, indefinitely; remove with `-UnregisterTasks`) -- or keep a process up with `-Monitor`. Help for all options is `-h` / `-Help` / `-?`.

## The Three-File System

The monitor uses three JSON files to separate concerns:

| File | Purpose | Who Edits It |
|------|---------|-------------|
| `ca-platform-monitor.json` | Configuration: thresholds, targets, log paths, tier definitions, SMTP settings | Admin |
| `monitoring-requirements.json` | Business SLA requirements mapped to technical checks with thresholds and notification routing | Admin |
| `platform-state.json` | Rolling trend data, active alerts, alert history, all-time peaks | Tool (never hand-edit) |

All three files are auto-created with sensible defaults on first run. The config and requirements files are intended for customization. The state file is managed exclusively by the tool.

## Storage Architecture

The monitor writes several persistent surfaces:

**JSONL (raw metrics)**. One file per day, `platform-metrics-YYYY-MM-DD.jsonl`. Each run appends one compressed JSON line per collector (plus per connectivity target and per alert). Raw audit trail; process with any text tool (`Get-Content`, `jq`, Splunk). Auto-rotated by `retentionDays` (default 30).

**Trend + status files (for external monitoring)**. Every run also writes one flat, fixed-schema summary record to two dedicated, mode-independent files:

- `platform-summary.jsonl` -- append-only, **one line per run, identical schema every time** (nulls where a collector didn't run). Point a trend/`modstat`/Nagios parser here -- no date globbing, no record-type filtering.
- `platform-status.json` -- the same flat record as a **current snapshot**, atomically overwritten each run (a Nagios `status.dat` / Apache `mod_status` analog) for "state right now" polling by Zabbix/Telegraf/exec checks.

**State file (trends & alerts)**. A single `platform-state.json` maintaining per-day min/max/avg/sum/count per metric (incremental rollup -- answer "peak CPU last month?" without parsing 30 files), plus active alerts, alert history (capped 500), all-time peaks, service baselines, and self-heal counters.

> **Important**: The state file uses atomic writes (.tmp + rename) and a global named mutex (`Global\CyberArkPlatformMonitorState`) for cross-process synchronization when multiple scheduled tasks overlap.

## Prerequisites

- **PowerShell 5.1** or later (Windows PowerShell). PowerShell 7 (Core) is also supported.
- **Local administrator** access on the target server (required for performance counters, event logs, and service queries).
- **No external modules** -- the script uses only built-in cmdlets and .NET Framework classes.
- **Network access** (optional) -- only needed for connectivity checks and SMTP alerting.
- **Windows Server** 2012 R2 or later. The script also runs on Windows 10/11 for testing.

> **Note**: The tool can run on macOS or Linux with the `-UseMockData` flag for testing and report development. All Windows-specific calls are gated behind platform detection.
